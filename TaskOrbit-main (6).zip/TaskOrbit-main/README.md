# Welcome to TaskOrbit 👋

## Get started

1. Download TaskOrbit from github

2. Make sure that when extracting the folder, there are no spaces inside the folder name

3. Open TaskOrbit inside visual studio code

4. Open a terminal and enter command

    ```bash
   npm install --legacy-peer-deps
   ```

5. Enter command

   ```bash
   cd ios
   ```

6. Enter command

   ```bash
   pod install
   ```

7. On the left side go to: node_modules>@expo>env>build>env.js, open the copy-paste.jsx file from the root folder and copy-paste that code inside the env.js file (MAKE SURE TO COMMAND + S THE CODE TO SAVE!)

8. Open finder, open the project folder>ios and open: TaskOrbit.xcworkspace. Make sure to open .xcworkspace not .TaskOrbit.xcodeproj

9. Go to the **Signing & Capabilities** tab inside the project settings and give your project a bundle identifier (com.app.TaskOrbit)

10. At the top select your iOS device

11. At the top of your screen inside your macbooks navigation bar click: Product>Scheme>Edit Scheme and set the build configuration to Release

12. Click start in the top left and wait for everything to compile

