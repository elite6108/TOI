import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import {
    getReactNativePersistence,
    initializeAuth,
} from 'firebase/auth';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Platform } from 'react-native';
import { getFirestore } from 'firebase/firestore';
import { getStorage, ref } from 'firebase/storage';
import { getDatabase } from 'firebase/database';
import Constants from 'expo-constants';

const firebaseConfig = {
    apiKey: Constants.expoConfig.extra.firebase.apiKey,
    authDomain: Constants.expoConfig.extra.firebase.authDomain,
    projectId: Constants.expoConfig.extra.firebase.projectId,
    storageBucket: Constants.expoConfig.extra.firebase.storageBucket,
    messagingSenderId: Constants.expoConfig.extra.firebase.messagingSenderId,
    appId: Constants.expoConfig.extra.firebase.appId,
};

const app = initializeApp(firebaseConfig);

let auth;
if (Platform.OS === 'android' || Platform.OS === 'ios') {
    auth = initializeAuth(app, {
        persistence: getReactNativePersistence(AsyncStorage),
    });
} else {
    auth = getAuth(app);
}

const firestore = getFirestore(app);
const storage = getStorage(app);
const storageRef = ref(storage);
const database = getDatabase(app);

export { auth, firestore, storage, storageRef, database };
