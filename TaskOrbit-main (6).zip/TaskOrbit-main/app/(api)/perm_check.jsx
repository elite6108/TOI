
import React, { useState, useEffect } from 'react';
import { auth, firestore } from './firebase';
import { doc, getDoc } from 'firebase/firestore';

const PermissionChecker = ({ permissionId }) => {
  const [hasPermission, setHasPermission] = useState(null);

  useEffect(() => {
    const checkPermission = async () => {
      try {
        const userId = auth.currentUser.uid;

        const userDoc = await getDoc(doc(firestore, 'Users', userId));
        const userData = userDoc.exists ? userDoc.data() : null;

        if (!userData) {
          setHasPermission(false);
          return;
        }

        if (userData.hasSuperAdmin) {
          setHasPermission(true);
          return;
        }

        const businessId = userData.businessId;
        const userRoles = userData.assignedRoles || [];

        const businessDoc = await getDoc(doc(firestore, 'Businesses', businessId));
        const businessData = businessDoc.exists ? businessDoc.data() : null;

        if (!businessData) {
          setHasPermission(false);
          return;
        }

        const businessRoles = businessData.roles || [];

        let permissionGranted = false;
        for (const userRole of userRoles) {
          const role = businessRoles.find(role => role.name === userRole);
          if (role && role.permissions.includes(permissionId)) {
            permissionGranted = true;
            break;
          }
        }

        setHasPermission(permissionGranted);
      } catch (error) {
        console.error("Error checking permission:", error);
        setHasPermission(false);
      }
    };

    checkPermission();
  }, [permissionId]);

  //console.info(`User does ${hasPermission} have permission to ${permissionId}`);
  return hasPermission;
};

export default PermissionChecker;
