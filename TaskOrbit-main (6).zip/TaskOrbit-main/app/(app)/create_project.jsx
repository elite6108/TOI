import React, { useState, useEffect, useRef } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  TextInput,
  Modal,
  Platform,
  PermissionsAndroid,
  ScrollView,
  KeyboardAvoidingView,
  Image
} from "react-native";
import { useNavigation, useRoute } from "@react-navigation/native";
import MapView, { Marker } from "react-native-maps";
import Icon from "react-native-vector-icons/Ionicons";
import MaterialIcon from "react-native-vector-icons/MaterialIcons";
import Geolocation from "react-native-geolocation-service";
import { GooglePlacesAutocomplete } from "react-native-google-places-autocomplete";
import {
  collection,
  doc,
  getDoc,
  updateDoc,
  query,
  where,
  getDocs,
} from "firebase/firestore";
import { auth, firestore } from "../(api)/firebase";
import DropDownPicker from "react-native-dropdown-picker";
import Constants from "expo-constants";
import Geocoder from "react-native-geocoding";
import DateTimePicker from "@react-native-community/datetimepicker";
import { LinearGradient } from "expo-linear-gradient";
import randn from "randn";

Geocoder.init(Constants.expoConfig.extra.google.apiKey);

const CreateProjectScreen = () => {
  const navigation = useNavigation();
  const route = useRoute();
  const { businessId } = route.params;

  const [reportTitle, setReportTitle] = useState("");
  const [reportDescription, setReportDescription] = useState("");

  const [employees, setEmployees] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [roles, setRoles] = useState([]);
  const [selectedEmployees, setSelectedEmployees] = useState([]);
  const [openEmployees, setOpenEmployees] = useState(false);
  const [selectedApproval, setSelectedApproval] = useState([]);
  const [openApproval, setOpenApproval] = useState(false);
  const [locationChoiceModalVisible, setLocationChoiceModalVisible] =
    useState(false);
  const [mapModalVisible, setMapModalVisible] = useState(false);
  const [selectedLocation, setSelectedLocation] = useState(null);
  const [initialRegion, setInitialRegion] = useState(null);
  const [businessLocation, setBusinessLocation] = useState("");
  const [fullStreetName, setFullStreetName] = useState("");
  const [searchText, setSearchText] = useState("");
  const [priority, setPriority] = useState(null);
  const [openPriority, setOpenPriority] = useState(false);
  const [clientType, setClientType] = useState(null);
  const [openClientType, setOpenClientType] = useState(false);
  const [clientName, setClientName] = useState("");
  const [clientPhone, setClientPhone] = useState("");
  const [taskLists, setTaskLists] = useState([]);
  const [selectedTaskList, setSelectedTaskList] = useState(null);
  const [taskListModalVisible, setTaskListModalVisible] = useState(false);
  const [searchResults, setSearchResults] = useState([]);
const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [priorityItems, setPriorityItems] = useState([
    { label: "Not Urgent", value: "low" },
    { label: "Urgent", value: "medium" },
    { label: "Very Urgent", value: "high" },
  ]);
  const [tools, setTools] = useState("");
  const [dueDate, setDueDate] = useState(new Date());
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [estimatedHours, setEstimatedHours] = useState(0);
  const [estimatedMinutes, setEstimatedMinutes] = useState(0);
  const mapRef = useRef(null);

  const createProject = async (businessDocRef,estimatedTime,taskData,taskId) =>{

    try {
      const projectData = {
        projectSettings: {
          title: reportTitle,
          description: reportDescription,
          ...(taskData && {
            projectTasks:taskData,
            taskId: taskId
          }), // Add taskId only if it exists
          location: `${selectedLocation ? selectedLocation : businessLocation}`,
          priority: priority,
          tools: tools,
          assigned_employees: selectedEmployees,
          dateTime: dueDate,
          estimated_time: estimatedTime,
          approval_required: selectedApproval,
          status: "Open",
          clientType: clientType,
          customerDetails:
              clientType === "customer"
                  ? { name: clientName, phone: clientPhone }
                  : null,
        },
      };


      await updateDoc(businessDocRef, {
        [`project.${reportTitle}`]: projectData,
      });

      if (clientType === "customer") {
        await updateDoc(businessDocRef, {
          [`customers.${clientName}`]: {
            name: clientName,
            phone: clientPhone,
            projects: [
              {
                reportTitle: reportTitle,
                reportDescription: reportDescription,
                dueDate: dueDate,
              },
            ],
          },
        });
      }

      alert("Project confirmed and saved successfully.");
      navigation.goBack();
    } catch (error) {
      console.error("Error saving project:", error);
      alert("Failed to save project. Please try again.");
    }

  }

  const handleConfirmProject = async () => {
    if (
      !reportTitle ||
      !reportDescription ||
      !priority ||
      selectedEmployees.length === 0
    ) {
      console.log(selectedLocation);
      alert("Please fill out all required fields.");
      return;
    }

    if (clientType === "customer" && (!clientName || !clientPhone)) {
      alert("Please provide customer name and phone number.");
      return;
    }

    const estimatedTime = `${estimatedHours}h ${estimatedMinutes}m`;
    let taskName =null;
    const businessDocRef = doc(firestore, "Businesses", businessId);
    if (selectedTaskList){
      const id = randn();
      const {label,taskDetails}= selectedTaskList
      taskName= label;

      const selectedTask = JSON.parse(JSON.stringify(taskDetails));
      delete selectedTask?.status;
      delete selectedTask?.id;
      selectedTask?.taskItems?.forEach(task => {
        delete task?.id;
        delete task?.value;
        //delete task?.status;
      });

      const taskItemObj = {
        taskName: selectedTask?.taskName,
        taskListSettings: {
          ...selectedTask.taskListSettings,
        },
        taskItems: selectedTask.taskItems?.map(task => ({
          ...task,
          id: randn(),
          status: task.type === 'Subtitle' ? 'Closed' : 'Open',
        })),
      }

      const taskData= {
        [`${id}`]: taskItemObj
      }

       createProject(businessDocRef,estimatedTime,taskData,id)

    } else{
      createProject(businessDocRef,estimatedTime)
    }
  };

  const fetchTaskLists = async () => {
    try {
      const businessDoc = await getDoc(
        doc(firestore, "Businesses", businessId)
      );
      if (businessDoc.exists()) {
        const tasksData = businessDoc.data().tasks || {};
        //console.log('taskdata---', JSON.stringify(tasksData));
        const taskListTitles = Object.keys(tasksData).map(id => {
          const taskDetails = tasksData[id];

          // Modify taskItems: Set status to "Open" and delete 'value'
          taskDetails.taskItems = taskDetails.taskItems.map(item => {
            item.status =  item.title === 'Subtitle' ? 'Closed' : 'Open';  // Set status to "Open"
            delete item.value;    // Delete value property
            return item;
          });

          return {
            id:id,
            label: tasksData[id].taskName,
            value: tasksData[id].taskName,
            taskDetails: taskDetails
          };
        });

        /*const taskListTitles = Object.keys(tasksData).map((title) => ({
          label: title,
          value: title,
          taskDetails:tasksData[title]
        }));*/
        setTaskLists(taskListTitles);
      } else {
        console.log("No task lists found for this business!");
      }
    } catch (error) {
      console.error("Error fetching task lists:", error);
    }
  };

  useEffect(() => {
    fetchTaskLists();
  }, [businessId]);

  useEffect(() => {
    const requestLocationPermission = async () => {
      if (Platform.OS === "android") {
        try {
          const granted = await PermissionsAndroid.request(
            PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
            {
              title: "Location Permission",
              message: "This app requires access to your location.",
              buttonPositive: "OK",
              buttonNegative: "Cancel",
            }
          );
          if (granted === PermissionsAndroid.RESULTS.GRANTED) {
            getCurrentLocation();
          }
        } catch (err) {
          console.warn(err);
        }
      } else {
        Geolocation.requestAuthorization("whenInUse")
          .then((status) => {
            if (status === "granted") {
              getCurrentLocation();
            }
          })
          .catch((error) => console.log("Location permission error:", error));
      }
    };

    const getCurrentLocation = () => {
      Geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setInitialRegion({
            latitude,
            longitude,
            latitudeDelta: 0.0922,
            longitudeDelta: 0.0421,
          });
        },
        (error) => {
          console.error(error);
        },
        { enableHighAccuracy: true, timeout: 15000, maximumAge: 10000 }
      );
    };

    requestLocationPermission();
  }, []);

  useEffect(() => {
    const fetchEmployees = async () => {
      if (businessId) {
        try {
          const q = query(
            collection(firestore, "Users"),
            where("businessId", "==", businessId)
          );
          const querySnapshot = await getDocs(q);
          const employeeList = querySnapshot.docs.map((doc) => ({
            id: doc.id,
            ...doc.data(),
          }));

          employeeList.sort((a, b) => a.fullName.localeCompare(b.fullName));
          console.log(employeeList);
          setEmployees(employeeList);
        } catch (error) {
          console.error("Error fetching employees: ", error);
        }
      }
    };

    fetchEmployees();
  }, [businessId]);

  useEffect(() => {
    const fetchCustomers = async () => {
      const businessDoc = await getDoc(
        doc(firestore, "Businesses", businessId)
      );
      if (businessDoc.exists()) {
        setCustomers(businessDoc.data().customers || {});
        console.log(`Customers: ${customers}`);
      }
    };
    fetchCustomers();
  }, []);

  useEffect(() => {
    const fetchRoles = async () => {
      if (businessId) {
        try {
          const businessDoc = await getDoc(
            doc(firestore, "Businesses", businessId)
          );
          if (businessDoc.exists()) {
            const businessRoles = businessDoc.data().roles;
            setRoles(
              businessRoles.map((role) => ({
                label: role.name,
                value: role.name,
              }))
            );
          } else {
            console.log("No roles found for this business!");
          }
        } catch (error) {
          console.error("Error fetching roles: ", error);
        }
      }
    };

    fetchRoles();
  }, [businessId]);

  useEffect(() => {
    if (mapModalVisible) {
      handleFocusPress();
    }
  }, [mapModalVisible]);

  useEffect(() => {
    if (selectedLocation) {
      handleFocusPress();
    }
  }, [selectedLocation]);

  const handleFocusPress = () => {
    if (selectedLocation) {
      const zoomLevel = 0.005;
      mapRef.current.animateToRegion(
        {
          latitude: selectedLocation.latitude,
          longitude: selectedLocation.longitude,
          latitudeDelta: zoomLevel,
          longitudeDelta: zoomLevel,
        },
        1000
      );
    }
  };

  useEffect(() => {
  const fetchBusinessLocation = async () => {
    try {
      const businessDoc = await getDoc(
        doc(firestore, "Businesses", businessId)
      );
      if (businessDoc.exists()) {
        const businessData = businessDoc.data();
        const address = businessData.businessAddress;
        setBusinessLocation(address);
        console.log(businessLocation);
      } else {
        console.log("Business not found");
      }
    } catch (error) {
      console.error("Error fetching business location:", error);
    }
  };

  fetchBusinessLocation();
}, [businessLocation]);

  const handleSelectLocation = () => {
    setLocationChoiceModalVisible(true);
  };

  const handleDateChange = (event, selectedDate) => {
    const currentDate = selectedDate || dueDate;
    setShowDatePicker(Platform.OS === "ios" ? true : false);
    setDueDate(currentDate);
    setShowDatePicker(false);
  };

  const handleUseBusinessLocation = async () => {
    setLocationChoiceModalVisible(false);
  };

  const handleUseCustomerAddress = () => {
    setLocationChoiceModalVisible(false);
    setMapModalVisible(true);
  };

  const confirmLocation = () => {
    setMapModalVisible(false);
    console.log("Selected Location:", selectedLocation);
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <KeyboardAvoidingView
        style={styles.safeArea}
        behavior={Platform.OS === "ios" ? "padding" : "height"}
      >
                            <Image
                              source={require('../../assets/images/taskorbit.png')}
                              style={styles.icon}
                            />
        <ScrollView contentContainerStyle={styles.scrollContent}>
          {roles ? (
            <View style={styles.formField}>
              <Text style={styles.label}>Approval Required</Text>
              <DropDownPicker
                zIndex={10}
                open={openApproval}
                value={selectedApproval}
                items={roles}
                setOpen={setOpenApproval}
                setValue={setSelectedApproval}
                multiple={true}
                placeholder="Select Roles"
                containerStyle={{ height: 40 }}
                style={styles.dropdown}
                dropDownStyle={{ backgroundColor: "white" }}
                labelStyle={{ color: "black" }}
              />
            </View>
          ) : null}

          <View style={styles.formField}>
            <Text style={styles.label}>
              Estimated Time (hh : mm)<Text style={styles.required}>*</Text>
            </Text>
            <View style={styles.estimatedTimeContainer}>
              <TextInput
                style={styles.inputSmall}
                placeholder="Hours"
                placeholderTextColor="#999"
                keyboardType="numeric"
                value={String(estimatedHours)}
                onChangeText={(text) => setEstimatedHours(Number(text))}
              />
              <Text style={styles.estimatedTimeSeparator}>:</Text>
              <TextInput
                style={styles.inputSmall}
                placeholder="Minutes"
                placeholderTextColor="#999"
                keyboardType="numeric"
                value={String(estimatedMinutes)}
                onChangeText={(text) => setEstimatedMinutes(Number(text))}
              />
            </View>
          </View>

          <View style={styles.formField}>
            <Text style={styles.label}>
              Due Date<Text style={styles.required}>*</Text>
            </Text>
            <TouchableOpacity
              onPress={() => setShowDatePicker(true)}
              style={styles.input}
            >
              <Text style={styles.inputText}>
                {dueDate ? dueDate.toDateString() : "Select Due Date"}
              </Text>
            </TouchableOpacity>
          </View>

          {showDatePicker && (
            <DateTimePicker
              value={dueDate}
              mode="date"
              display="default"
              onChange={handleDateChange}
            />
          )}

          {employees ? (
            <View style={styles.formField}>
              <Text style={styles.label}>
                Assign Employees<Text style={styles.required}>*</Text>
              </Text>
              <DropDownPicker
                zIndex={10}
                open={openEmployees}
                value={selectedEmployees}
                items={employees.map((emp) => ({
                  label: emp.fullName,
                  value: emp.id,
                }))}
                setOpen={setOpenEmployees}
                setValue={setSelectedEmployees}
                multiple={true}
                placeholder="Select Employees"
                containerStyle={{ height: 40 }}
                style={styles.dropdown}
                dropDownStyle={{ backgroundColor: "white" }}
                labelStyle={{ color: "black" }}
              />
            </View>
          ) : null}

          <View style={styles.formField}>
            <Text style={styles.label}>Tools</Text>
            <TextInput
              style={styles.input}
              placeholder="Enter tools needed"
              placeholderTextColor="#999"
              value={tools}
              onChangeText={setTools}
            />
          </View>

          <View style={styles.formField}>
            <Text style={styles.label}>Priority</Text>
            <View style={{ zIndex: 100 }}>
              <DropDownPicker
                open={openPriority}
                value={priority}
                items={priorityItems}
                setOpen={setOpenPriority}
                setValue={setPriority}
                placeholder="Select Priority"
                dropDownContainerStyle={{
                  backgroundColor: "white",
                }}
                style={styles.dropdown}
                dropDownStyle={{ backgroundColor: "white" }}
                labelStyle={{ color: "black" }}
              />
            </View>
          </View>

          <View style={styles.formField}>
            <Text style={styles.label}>
              Client Type<Text style={styles.required}>*</Text>
            </Text>
            <DropDownPicker
              open={openClientType}
              value={clientType}
              items={[
                { label: "Customer", value: "customer" },
                { label: "In house", value: "in-house" },
              ]}
              setOpen={setOpenClientType}
              setValue={setClientType}
              placeholder="Select Client Type"
              dropDownContainerStyle={{
                backgroundColor: "white",
              }}
              style={styles.dropdown}
              dropDownStyle={{ backgroundColor: "white" }}
              labelStyle={{ color: "black" }}
            />
          </View>

          {clientType === "customer" && (
            <View>
              <View style={styles.formField}>
                <Text style={styles.label}>
                  Customer Name<Text style={styles.required}>*</Text>
                </Text>
                <TextInput
  style={styles.input}
  placeholder="Enter customer's first and last name"
  placeholderTextColor="#999"
  value={clientName}
  onChangeText={(text) => {
    setClientName(text);
    if (text.length > 1) {
      const customerEntries = Object.entries(customers || {});
      const matches = customerEntries
        .filter(([key, value]) => key.toLowerCase().includes(text.toLowerCase()))
        .map(([key, value]) => ({ name: key, phone: value.phone }));
      setSearchResults(matches);
    } else {
      setSearchResults([]);
    }
  }}
/>
              </View>
              {searchResults.length > 0 && (
  <View style={styles.searchResults}>
    {searchResults.map((result, index) => (
      <TouchableOpacity
        key={index}
        style={styles.searchResultItem}
        onPress={() => {
          setClientName(result.name);
          setClientPhone(result.phone);
          setSearchResults([]);
          setSelectedCustomer(result);
        }}
      >
        <Text style={styles.searchResultText}>{result.name}</Text>
        <Text style={styles.searchResultSubText}>{result.phone}</Text>
      </TouchableOpacity>
    ))}
  </View>
              )}
              <View style={styles.formField}>
                <Text style={styles.label}>
                  Customer Phone<Text style={styles.required}>*</Text>
                </Text>
                <TextInput
                  style={styles.input}
                  placeholder="Enter customer's phone number"
                  placeholderTextColor="#999"
                  keyboardType="phone-pad"
                  value={clientPhone}
                  onChangeText={setClientPhone}
                />
              </View>
            </View>
          )}

          <View style={styles.formField}>
            <Text style={styles.label}>
              Add Location
            </Text>
            <TouchableOpacity
              style={styles.locationButton}
              onPress={handleSelectLocation}
            >
              <Text style={styles.locationButtonText}>
                {selectedLocation
                  ? fullStreetName
                  : businessLocation || "Select Location"}
              </Text>
            </TouchableOpacity>
          </View>

          <View style={styles.formField}>
            <Text style={styles.label}>Attach Tasklist</Text>
            <TouchableOpacity
              onPress={() => setTaskListModalVisible(true)}
              style={styles.selectTaskListButton}
            >
              <Text style={styles.selectTaskListButtonText}>
                {selectedTaskList
                  ? `Task List: ${selectedTaskList?.label}`
                  : "Select Tasklist"}
              </Text>
            </TouchableOpacity>
          </View>

          <View style={styles.formField}>
            <Text style={styles.label}>Description<Text style={styles.required}>*</Text></Text>
            <TextInput
              style={styles.textArea}
              placeholder="Describe the maintenance task in detail"
              placeholderTextColor="#999"
              multiline
              onChangeText={setReportDescription}
            />
          </View>

          <View style={styles.form1Field}>
            <Text style={styles.label}>
              Title<Text style={styles.required}>*</Text>
            </Text>
            <TextInput
              style={styles.input}
              placeholder="Weekly Trampoline Maintenance"
              placeholderTextColor="#999"
              onChangeText={setReportTitle}
            />
          </View>
        </ScrollView>

        {/* Location Choice Modal */}
        <Modal
          visible={locationChoiceModalVisible}
          transparent
          animationType="fade"
        >
          <TouchableOpacity
            style={styles.choiceModalContainer}
            activeOpacity={1}
            onPress={() => setLocationChoiceModalVisible(false)}
          >
            <View style={styles.choiceModal}>
              <Text style={styles.choiceText}>Choose Location Type</Text>
              { businessLocation !== '' ?
              <TouchableOpacity
                style={styles.choiceButton}
                onPress={handleUseBusinessLocation}
              >
                <Text style={styles.choiceButtonText}>
                  Use Business Location
                </Text>
              </TouchableOpacity>
              : null }
              <TouchableOpacity
                style={styles.choiceButton}
                onPress={handleUseCustomerAddress}
              >
                <Text style={styles.choiceButtonText}>
                  Use Customer Address
                </Text>
              </TouchableOpacity>
            </View>
          </TouchableOpacity>
        </Modal>

        <Modal
          visible={taskListModalVisible}
          animationType="slide"
          onRequestClose={() => setTaskListModalVisible(false)}
        >
          <SafeAreaView style={styles.modalTaskListContainer}>
            <Text style={styles.modalTitle}>Select a Task List</Text>
            <ScrollView contentContainerStyle={styles.taskListContainer}>
              {taskLists.map((taskList,index) => (
                <TouchableOpacity
                  key={index.toString()}
                  onPress={() => {
                    setSelectedTaskList(taskList);
                    setTaskListModalVisible(false);
                  }}
                  style={styles.taskListItem}
                >
                  <Text style={styles.taskListText}>{taskList.label}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
            <TouchableOpacity
              onPress={() => setTaskListModalVisible(false)}
              style={styles.closeModalButton}
            >
              <Text style={styles.closeModalButtonText}>Cancel</Text>
            </TouchableOpacity>
          </SafeAreaView>
        </Modal>

        {/* Map Modal */}
        <Modal visible={mapModalVisible} animationType="slide">
          <View style={styles.mapContainer}>
            <MapView
              ref={mapRef}
              style={styles.map}
              initialRegion={
                initialRegion || {
                  latitude: 37.78825,
                  longitude: -122.4324,
                  latitudeDelta: 0.0922,
                  longitudeDelta: 0.0421,
                }
              }
            >
              {selectedLocation && <Marker coordinate={selectedLocation} />}
            </MapView>

            {/* Search Input */}
            <GooglePlacesAutocomplete
              placeholder="Search Address"
              fetchDetails={true}
              onPress={(data, details = null) => {
                const { lat, lng } = details.geometry.location;
                setSelectedLocation({ latitude: lat, longitude: lng });
                setSearchText(data.description);

                if (details && details.address_components) {
                  const street = details.address_components.find(
                    (component) =>
                      component.types.includes("route") ||
                      component.types.includes("street_address")
                  );
                  if (street) {
                    setFullStreetName(`${details.formatted_address}`);
                  }
                }
              }}
              query={{
                key: Constants.expoConfig.extra.google.apiKey,
                language: "en",
              }}
              styles={{
                container: {
                  position: "absolute",
                  top: 40,
                  flex: 1,
                  width: "80%",
                },
                textInput: {
                  backgroundColor: "black",
                  color: "white",
                  borderRadius: 30,
                },
              }}
            />

            {/* Buttons Positioned at Bottom */}
            <View style={styles.buttonModalRow}>
              <TouchableOpacity
                style={styles.actionButton}
                onPress={() => setMapModalVisible(false)}
              >
                <Icon name="close" size={30} color="#ccc" />
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.actionButton}
                onPress={handleFocusPress}
              >
                <MaterialIcon name="center-focus-weak" size={30} color="#ccc" />
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.actionButton}
                onPress={confirmLocation}
              >
                <Icon name="checkmark" size={30} color="#ccc" />
              </TouchableOpacity>
            </View>
          </View>
        </Modal>

        <View style={styles.buttonRow}>
          <TouchableOpacity
            style={styles.skipButton}
            onPress={() => navigation.goBack()}
          >
            <Text style={styles.skipButtonText}>Back to list</Text>
          </TouchableOpacity>

          <LinearGradient
            colors={["#2196f3", "#21cbf3"]}
            start={{ x: 1, y: 0 }}
            end={{ x: 0, y: 0 }}
            style={styles.confirmButton}
          >
            <TouchableOpacity onPress={() => handleConfirmProject()}>
              <Text style={styles.confirmButtonText}>Confirm Project</Text>
            </TouchableOpacity>
          </LinearGradient>
        </View>


      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: "white",
  },
  backButton: {
    paddingRight: 10,
  },
  screenTitle: {
    fontSize: 19,
    fontWeight: "bold",
  },
  scrollContent: {
    flexDirection: "column-reverse",
    paddingHorizontal: 20,
    paddingTop: 0,
    flexGrow: 1,
    paddingBottom: 100,
  },
  form1Field: {
    zIndex: 1,
    marginTop: 0,
  },
  formField: {
    zIndex: 1,
    marginTop: 10,
  },
  label: {
    zIndex: 1,
    fontSize: 16,
    color: "black",
    fontWeight: "500",
    marginTop: 10,
    marginBottom: 5,
  },
  required: {
    color: "red",
  },
  input: {
    zIndex: 1,
    height: 40,
    borderColor: "#ccc",
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 10,
    fontSize: 16,
    color: "black",
    backgroundColor: "white",
  },
  textArea: {
    zIndex: 1,
    height: 100,
    borderColor: "#ccc",
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 10,
    fontSize: 16,
    color: "black",
    backgroundColor: "white",
    textAlignVertical: "top",
  },
  locationButton: {
    zIndex: 1,
    height: 40,
    borderRadius: 8,
    backgroundColor: "white",
    justifyContent: "center",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#ccc",
  },
  locationButtonText: {
    alignSelf: "flex-start",
    color: "black",
    fontSize: 16,
    paddingHorizontal: 10,
  },
  mapContainer: {
    flex: 1,
    justifyContent: "flex-start",
    alignItems: "center",
  },
  buttonModalRow: {
    position: "absolute",
    bottom: 20,
    left: 0,
    right: 0,
    flexDirection: "row",
    justifyContent: "space-evenly",
    padding: 10,
    backgroundColor: "transparent",
  },
  inputGoogle: {
    position: "absolute",
    top: 20,
    left: 0,
    right: 0,
    flexDirection: "row",
    padding: 10,
    backgroundColor: "red",
  },
  map: {
    width: "100%",
    height: "100%",
  },
  actionButton: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: "rgba(128, 128, 128, 0.5)",
    justifyContent: "center",
    alignItems: "center",
  },
  choiceModalContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(0, 0, 0, 0.4)",
  },
  choiceModal: {
    backgroundColor: "white",
    padding: 20,
    borderRadius: 10,
    width: 300,
  },
  choiceText: {
    fontSize: 18,
    marginBottom: 15,
    textAlign: "center",
  },
  choiceButton: {
    paddingVertical: 12,
    alignItems: "center",
    backgroundColor: "#2196f3",
    marginBottom: 10,
    borderRadius: 5,
  },
  choiceButtonText: {
    color: "white",
    fontSize: 16,
  },
  dropdown: {
    zIndex: 100,
    borderColor: "#ccc",
    borderWidth: 1,
    borderRadius: 8,
    backgroundColor: "white",
    paddingHorizontal: 10,
    fontSize: 16,
    color: "black",
  },
  inputText: {
    marginVertical: "2%",
    color: "black",
    fontSize: 16,
  },
  estimatedTimeContainer: {
    flexDirection: "row",
    alignItems: "center",
  },
  inputSmall: {
    width: 80,
    height: 40,
    borderColor: "#ccc",
    borderWidth: 1,
    borderRadius: 5,
    paddingHorizontal: 10,
    fontSize: 16,
  },
  estimatedTimeSeparator: {
    fontSize: 18,
    marginHorizontal: 5,
  },
  buttonRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginHorizontal: 20,
    marginTop: 10,
  },
  skipButton: {
    backgroundColor: "transparent",
    borderWidth: 1,
    borderColor: "#dcdcdc",
    borderRadius: 10,
    padding: 15,
    alignItems: "center",
    flex: 1,
    marginRight: 10,
  },
  skipButtonText: {
    color: "#2196f3",
    fontWeight: "bold",
  },
  confirmButton: {
    borderRadius: 10,
    padding: 15,
    flex: 2,
  },
  confirmButtonText: {
    color: "#fff",
    fontWeight: "bold",
    textAlign: "center",
  },
  selectTaskListButton: {
    padding: 12,
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 8,
    marginVertical: 8,
    backgroundColor: "transparent",
  },
  selectTaskListButtonText: {
    fontSize: 16,
    color: "#333",
  },
  modalTaskListContainer: {
    width: "90%",
    maxHeight: "100%",
    padding: 20,
    alignSelf: "center",
    justifyContent: "center",
    alignItems: "center",
    flex: 1,
    backgroundColor: "white",
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: "bold",
    marginBottom: 16,
  },
  taskListContainer: {
    paddingVertical: 8,
  },
  taskListItem: {
    paddingVertical: 15,
    paddingHorizontal: 20,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: "#ddd",
  },
  taskListText: {
    fontSize: 16,
  },
  closeModalButton: {
    padding: 12,
    marginTop: 16,
    backgroundColor: "#2196f3",
    borderRadius: 8,
    alignItems: "center",
  },
  closeModalButtonText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "bold",
  },
  searchResults: {
    backgroundColor: "white",
    borderRadius: 5,
    padding: 5,
    marginTop: 5,
    elevation: 5,
    maxHeight: 150,
    overflow: "hidden",
  },
  searchResultItem: {
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: "#ddd",
  },
  searchResultText: {
    fontSize: 16,
    color: "black",
  },
  searchResultSubText: {
    fontSize: 12,
    color: "#666",
  },
  icon: {
    alignSelf: 'center',
    width: 150,
    height: 150,
    marginRight: 0,
  },
});

export default CreateProjectScreen;
