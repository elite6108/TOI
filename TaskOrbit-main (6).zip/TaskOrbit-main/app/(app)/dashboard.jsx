import React, {useState, useEffect} from "react";
import {useFocusEffect} from "@react-navigation/native";
import {
    View,
    Text,
    StyleSheet,
    Image,
    TouchableOpacity,
    Alert,
    FlatList,
} from "react-native";
import {MaterialCommunityIcons, Feather} from "@expo/vector-icons";
import i18n from "@/app/localization";
import {PanResponder, Animated} from "react-native";
import {doc, getDoc} from "firebase/firestore";
import {getStorage, ref, getDownloadURL} from "firebase/storage";
import {auth, firestore} from "../(api)/firebase";
import PermissionChecker from "../(api)/perm_check";
import TaskItem from "../components/TaskItem";
import TaskOrbitDropDown from "@/app/components/TaskOrbitDropDown";

export default function DashboardScreen({navigation, route}) {
    const [fullName, setFullName] = useState("loading...");
    const [profileImage, setProfileImage] = useState(null);
    const [permissionGranted, setPermissionGranted] = useState(false);
    const userId = auth.currentUser.uid;
    const [isViewingTasks, setIsViewingTasks] = useState(true);
    const [tasks, setTasks] = useState([]);
    const [allTasks, setAllTasks] = useState([]);
    const [projects, setProjects] = useState([]);
    const [filteredProjects, setFilteredProjects] = useState([]);
    const [totalProjectCount, setTotalProjectCount] = useState(0);
    const [businessId, setBusinessId] = useState("");
    const [userRole, setUserRole] = useState("");
    const [userSecondRole, setUserSecondRole] = useState("");
    const [Roles, setRoles] = useState("");
    const [readyToCreateTasks, setReadyToCreateTasks] = useState(false);
    const [value, setValue] = useState("week");
    const [totalTaskListCount, setTotalTaskListCount] = useState(0);
    const [dueSoonCount, setDueSoonCount] = useState(0);
    const [totalTaskCount, setTotalTaskCount] = useState(0);
    const [filteredTasks, setFilteredTasks] = useState([]);

    const permissionCreateProjectId = "create_project";
    const hasProjectPermission = PermissionChecker({
        permissionId: permissionCreateProjectId,
    });

    const permissionCreateTaskId = "create_task_lists";
    const hasTaskPermission = PermissionChecker({
        permissionId: permissionCreateTaskId,
    });

    const data = [
        {label: "Today", value: "today"},
        {label: "This week", value: "week"},
        {label: "This month", value: "month"},
        {label: "This year", value: "year"},
        {label: "Lifetime", value: "lifetime"},
    ];
    const getStatusColor = (status) => {
        switch (status) {
            case "Overdue":
                return "#ffcccc";
            case "Due soon":
                return "#ffeb99";
            case "Upcoming":
                return "#b3e0e8";
            case "Future task":
                return "lightgreen";
            default:
                return "#b3e0e8";
        }
    };
    const formatDate = (isoDateString) => {
        const date = new Date(isoDateString);
        const day = String(date.getDate()).padStart(2, "0");
        const month = String(date.getMonth() + 1).padStart(2, "0");
        const year = date.getFullYear();

        return `${month}-${day}-${year}`;
    };

    const formatProjectDate = (timestamp) => {
        if (!timestamp || !timestamp.seconds) {
            console.error("Invalid timestamp:", timestamp);
            return "Invalid Date";
        }

        const date = new Date(timestamp.seconds * 1000);
        const day = String(date.getDate()).padStart(2, "0");
        const month = String(date.getMonth() + 1).padStart(2, "0");
        const year = date.getFullYear();

        return `${month}-${day}-${year}`;
    };

    useEffect(() => {
        const fetchUserData = async () => {
            try {
                const userDoc = await getDoc(doc(firestore, "Users", userId));
                if (userDoc.exists()) {
                    const userData = userDoc.data();

                    setFullName(userData.fullName);
                    setUserSecondRole(userData.assignedRoles) || [];
                    setProfileImage(userData.profileImage || null);
                    setBusinessId(userData.businessId);
                    setUserRole(userData.role);

                    if (!userData.loginPin) {
                        navigation.replace("(app)/pinCreation", {userDocId: userId});
                    }
                } else {
                    console.log("No such document!");
                }
            } catch (error) {
                console.error("Error fetching user data: ", error);
            }
        };

        fetchUserData();
    }, [userId, navigation]);

    const calculateStatus = (taskList) => {
        const {taskListSettings, taskItems} = taskList;
        const now = new Date();
        const dueDate = new Date(taskListSettings.dateTime);
        const daysDiff = Math.floor((dueDate - now) / (1000 * 60 * 60 * 24));

        const hasOpenTasks = taskItems.some((task) => task.status === "Open");

        if (hasOpenTasks) {
            if (daysDiff < 0) {
                return "Overdue";
            } else if (daysDiff === 0) {
                return "Due soon";
            } else if (daysDiff <= 2) {
                return "Due soon";
            } else if (daysDiff > 7) {
                return "Future task";
            } else if (daysDiff > 2 < 7) {
                return "Upcoming";
            }
        }
        return taskListSettings?.taskListStatus ? taskListSettings?.taskListStatus : "Open"
    };

    const calculateProjectStatus = (taskList) => {
        const now = new Date();
        const timestamp = taskList.projectSettings.dateTime;
        const dueDate = new Date(timestamp.seconds * 1000);
        const daysDiff = Math.floor((dueDate - now) / (1000 * 60 * 60 * 24));

        const hasOpenTasks = taskList.projectSettings.status;

        if (hasOpenTasks) {
            if (daysDiff < 0) {
                return "Overdue";
            } else if (daysDiff === 0) {
                return "Due soon";
            } else if (daysDiff <= 2) {
                return "Due soon";
            } else if (daysDiff > 7) {
                return "Future task";
            } else if (daysDiff > 2 < 7) {
                return "Upcoming";
            }
        }

        return "Completed";
    };

    const fetchTasks = async () => {
        try {
            const businessDoc = await getDoc(
                doc(firestore, "Businesses", businessId)
            );
            if (businessDoc.exists()) {
                const businessTasks = businessDoc.data().tasks;
                const businessRoles = businessDoc.data().roles;
                const userTasks = [];
                const userAllTasks = [];

                setRoles(businessRoles);
                setReadyToCreateTasks(true);

                for (const taskListName in businessTasks) {
                    const taskList = businessTasks[taskListName];
                    if (taskList.taskListSettings.roles.includes(userRole)) {
                        const status = calculateStatus(taskList);
                        const completedCount = taskList.taskItems.filter(
                            (task) => task.status === "Completed" || task.status === "Closed"
                        ).length;

                        if (status !== "Completed") {
                            userTasks.push({
                                id:taskListName,
                                name: taskList?.taskName,
                                ...taskList,
                                status,
                                completedCount,
                            });
                        }
                        userAllTasks.push({
                            id:taskListName,
                            name: taskList?.taskName,
                            ...taskList,
                            status,
                            completedCount,
                        });
                    } else if (
                        userSecondRole.some((role) =>
                            taskList.taskListSettings.roles.includes(role)
                        )
                    ) {
                        const status = calculateStatus(taskList);
                        const completedCount = taskList.taskItems.filter(
                            (task) => task.status === "Completed" || task.status === "Closed"
                        ).length;

                        if (status !== "Completed") {
                            userTasks.push({
                                id:taskListName,
                                name: taskList?.taskName,
                                ...taskList,
                                status,
                                completedCount,
                            });
                        }
                        userAllTasks.push({
                            id:taskListName,
                            name: taskList?.taskName,
                            ...taskList,
                            status,
                            completedCount,
                        });
                    }

                }

                userTasks.sort(
                    (a, b) =>
                        new Date(a.taskListSettings.dateTime) -
                        new Date(b.taskListSettings.dateTime)
                );
                userAllTasks.sort(
                    (a, b) =>
                        new Date(a.taskListSettings.dateTime) -
                        new Date(b.taskListSettings.dateTime)
                );

                setTasks(userTasks);
                setAllTasks(userAllTasks);

                const totalCount = userTasks.reduce(
                    (acc, task) => acc + task.taskItems.length,
                    0
                );
                setTotalTaskCount(totalCount);
            } else {
                console.log("No tasks found for this business!");
            }
        } catch (error) {
        }
    };

    const fetchProjects = async () => {
        try {
            const businessDoc = await getDoc(
                doc(firestore, "Businesses", businessId)
            );
            if (businessDoc.exists()) {
                const businessProjects = businessDoc.data().project;
                const userProjects = [];
                const storage = getStorage();

                setReadyToCreateTasks(true);

                for (const projectName in businessProjects) {
                    const project = businessProjects[projectName];

                    if (project.projectSettings?.assigned_employees?.includes(userId)) {
                        const status = calculateProjectStatus(project);

                        if (project.projectSettings.status === "Completed") {
                            continue;
                        }

                        const assignedEmployees =
                            project.projectSettings.assigned_employees;
                        const employeeProfilePictures = {};

                        for (const employee of assignedEmployees) {
                            try {
                                const profileImageRef = ref(
                                    storage,
                                    `/profileImages/${employee}`
                                );
                                const profileImageUrl = await getDownloadURL(profileImageRef);
                                employeeProfilePictures[employee] = profileImageUrl;
                            } catch (error) {
                                employeeProfilePictures[employee] = null;
                            }
                        }

                        userProjects.push({
                            name: projectName,
                            ...project,
                            status,
                            profilePictures: employeeProfilePictures,
                        });
                    }
                }

                userProjects.sort(
                    (a, b) =>
                        new Date(a.projectSettings.dateTime) -
                        new Date(b.projectSettings.dateTime)
                );

                setProjects(userProjects);
                const numberOfProjects = userProjects.length;
                setTotalProjectCount(numberOfProjects);
            } else {
                console.log("No projects found for this business!");
            }
        } catch (error) {
            console.error("Error fetching projects: ", error);
        }
    };

    useFocusEffect(
        React.useCallback(() => {
            if (businessId) {
                fetchTasks();
                fetchProjects();
            }
        }, [businessId, userRole, userSecondRole])
    );

    useEffect(() => {
        const filterData = () => {
            const now = new Date();
            let filteredTaskList = tasks;
            let filteredProjectList = projects;


            switch (value) {
                case "today":
                    filteredTaskList = tasks.filter(
                        (task) =>
                            new Date(task.taskListSettings.dateTime).toDateString() ===
                            now.toDateString()
                    );
                    filteredProjectList = projects.filter(
                        (project) =>
                            new Date(
                                project.projectSettings.dateTime.toDate()
                            ).toDateString() === now.toDateString()
                    );
                    break;
                case "week":
                    const startOfWeek = new Date();
                    const endOfWeek = new Date();
                    endOfWeek.setDate(endOfWeek.getDate() + 6);
                    filteredTaskList = tasks.filter((task) => {
                        const taskDate = new Date(task.taskListSettings.dateTime);
                        return taskDate >= startOfWeek && taskDate <= endOfWeek;
                    });

                    filteredProjectList = projects.filter((project) => {
                        const projectDate = new Date(
                            project.projectSettings.dateTime.toDate()
                        );
                        return projectDate >= startOfWeek && projectDate <= endOfWeek;
                    });
                    break;
                case "month":
                    const startOfMonth = new Date();
                    const endOfMonth = new Date();
                    endOfMonth.setMonth(startOfMonth.getMonth() + 1);
                    endOfMonth.setDate(endOfMonth.getDate() - 1);
                    filteredTaskList = tasks.filter((task) => {
                        const taskDate = new Date(task.taskListSettings.dateTime);
                        return taskDate >= startOfMonth && taskDate < endOfMonth;
                    });
                    filteredProjectList = projects.filter((project) => {
                        const projectDate = new Date(
                            project.projectSettings.dateTime.toDate()
                        );
                        return projectDate >= startOfMonth && projectDate < endOfMonth;
                    });
                    break;
                case "year":
                    const startOfYear = new Date();
                    const endOfYear = new Date();
                    endOfYear.setFullYear(startOfYear.getFullYear() + 1);

                    filteredTaskList = tasks.filter((task) => {
                        const taskDate = new Date(task.taskListSettings.dateTime);
                        return taskDate >= startOfYear && taskDate <= endOfYear;
                    });
                    filteredProjectList = projects.filter((project) => {
                        const projectDate = new Date(
                            project.projectSettings.dateTime.toDate()
                        );
                        return projectDate >= startOfYear && projectDate <= endOfYear;
                    });
                    break;
                case "lifetime":
                default:
                    filteredTaskList = tasks;
                    filteredProjectList = projects;
                    break;
            }


            setFilteredTasks(filteredTaskList);
            setFilteredProjects(filteredProjectList);
            setTotalTaskListCount(filteredTaskList.length);
            setTotalProjectCount(filteredProjectList.length);
            const dueSoonCount = filteredTaskList.filter(
                (task) => task.status === "Due soon"
            ).length;
            setDueSoonCount(dueSoonCount);
        };

        filterData();
    }, [tasks, projects, value]);


    const handleCreateTask = () => {
        if (readyToCreateTasks == true) {
            if (isViewingTasks) {
              //AllTasks (app)/create_task
                navigation.navigate("allTasks", {
                    tasks:allTasks,
                    roles: Roles,
                    businessId: businessId,
                    username: fullName,
                });
            } else {
                navigation.navigate("(app)/create_project", {
                    roles: Roles,
                    businessId: businessId,
                });
            }
        } else {
            Alert.alert(
                "Try again later",
                "We are still fetching your business info."
            );
        }
    };

    return (
        <View style={styles.container}>
            <View style={styles.headerContainer}>
                <View style={styles.logoContainer}>
                    <Image
                        source={
                            profileImage
                                ? {uri: profileImage.uri || profileImage}
                                : require("../../assets/images/taskorbit.png")
                        }
                        style={styles.logo}
                    />
                </View>
                <View>
                    <Text style={styles.greetingText}>{`${i18n.t('dashboard.hi')} ${fullName} 👋`}</Text>
                    <Text style={styles.welcomeText}>{`${i18n.t('dashboard.welcome_to_taskOrbit')}`}</Text>
                </View>
            </View>

            <View style={styles.quickViewHeader}>
                <Text style={styles.quickViewText}>{i18n.t('dashboard.quick_view')}</Text>
                <TaskOrbitDropDown onChange={(value) => setValue(value)} value={value}/>
            </View>

            <View style={styles.quickViewContainer}>
                <View style={styles.leftContainer}>
                    <Text style={styles.placeholderText}>{i18n.t('dashboard.task_count')}</Text>
                    <Text style={styles.numberText}>{totalTaskListCount}</Text>
                    <View style={styles.detailsContainer}>
                        <TouchableOpacity onPress={() => navigation.navigate("(app)/task_overview")}
                                          style={{flexDirection: 'row'}}>
                            <Text style={styles.detailsText}>View Details</Text>
                            <Feather
                                name="arrow-up-right"
                                size={20}
                                color="#2196f3"
                                style={styles.icon}
                            />
                        </TouchableOpacity>
                    </View>
                </View>

                <View style={styles.rightContainer}>
                    <View style={styles.topRightContainer}>
                        <Text style={styles.placeholderText}>{i18n.t('common.projects')}</Text>
                        <Text style={styles.numberText}>{totalProjectCount}</Text>
                        <View style={styles.detailsContainer}>
                            <TouchableOpacity onPress={() => navigation.navigate("(app)/project_overview")}
                                              style={{flexDirection: 'row'}}>
                                <Text style={styles.detailsText}>View Details</Text>
                                <Feather
                                    name="arrow-up-right"
                                    size={20}
                                    color="#2196f3"
                                    style={styles.icon}
                                />
                            </TouchableOpacity>
                        </View>
                    </View>
                    <View style={styles.bottomRightContainer}>
                        <Text style={styles.placeholderText}>{i18n.t('common.due_soon')}</Text>
                        <Text style={styles.numberText}>{dueSoonCount}</Text>
                        <View style={styles.detailsContainer}>
                            <Text style={styles.detailsText}>View Details</Text>
                            <Feather
                                name="arrow-up-right"
                                size={20}
                                color="#2196f3"
                                style={styles.icon}
                            />
                        </View>
                    </View>
                </View>
            </View>

            <View style={styles.reportsContainer}>
                <View style={styles.reportsHeader}>
                    <Text style={styles.reportsText}>
                        {isViewingTasks ? i18n.t('common.tasks') : i18n.t('common.projects')}
                    </Text>
                    {(isViewingTasks && hasTaskPermission) ||
                    (!isViewingTasks && hasProjectPermission) ? (
                        <TouchableOpacity
                            style={styles.createTaskButton}
                            onPress={handleCreateTask}
                        >
                            <Text style={styles.createTaskButtonText}>{i18n.t('common.add_new')}</Text>
                            <MaterialCommunityIcons
                                name="plus"
                                size={20}
                                color="black"
                                style={styles.plusIcon}
                            />
                        </TouchableOpacity>
                    ) : null}
                </View>
                {/* Switch between pages */}

                <View style={styles.switchContainer}>
                    <TouchableOpacity
                        onPress={() => setIsViewingTasks(true)}
                        style={[
                            styles.switchOption,
                            isViewingTasks && styles.activeOption,
                        ]}
                    >
                        <Text style={styles.switchText}>{i18n.t('common.tasks')}</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                        onPress={() => setIsViewingTasks(false)}
                        style={[
                            styles.switchOption,
                            !isViewingTasks && styles.activeOption,
                        ]}
                    >
                        <Text style={styles.switchText}>{i18n.t('common.projects')}</Text>
                    </TouchableOpacity>
                </View>
                {isViewingTasks ? (
                    <FlatList
                        data={filteredTasks}
                        contentContainerStyle={styles.contentContainer}
                        renderItem={({item, index}) => {
                            return (
                                <TaskItem
                                    key={index.toString()}
                                    index={index}
                                    navigation={navigation}
                                    businessId={businessId}
                                    roles={Roles}
                                    fullName={fullName}
                                    task={item}
                                />
                            )
                        }}/>
                ) : (
                    <FlatList
                        contentContainerStyle={styles.contentContainer}
                        data={filteredProjects}
                        renderItem={({item, index}) => {
                            const task = item;
                            return (
                                <TouchableOpacity
                                    key={index}
                                    style={[
                                        styles.reportItem,
                                        {borderLeftColor: getStatusColor(task.status)},
                                    ]}
                                    onPress={() =>
                                        navigation.navigate("(app)/project_details", {
                                            project: task.projectSettings,
                                            businessId: businessId,
                                            fullName: fullName,
                                        })
                                    }
                                >
                                    <View style={styles.taskHeader}>
                                        <Text style={styles.reportTitle}>
                                            {task.projectSettings.title}
                                        </Text>
                                        <View style={styles.taskCountContainer}>
                                            <View style={styles.detailsContainer}>
                                                <Text style={styles.detailsText}>View Details</Text>
                                                <Feather
                                                    name="arrow-up-right"
                                                    size={20}
                                                    color="black"
                                                    style={styles.icon}
                                                />
                                            </View>
                                        </View>
                                    </View>
                                    <Text style={[styles.reportDetails, {color: "#7E818E"}]}>
                                        {task.projectSettings.description}
                                    </Text>

                                    {/* Employee Profile Pictures */}
                                    <View style={styles.profileImagesContainer}>
                                        {Object.values(task.profilePictures)
                                            .slice(0, 4)
                                            .map((profileImage, imageIndex) => (
                                                <Image
                                                    key={imageIndex}
                                                    source={
                                                        profileImage
                                                            ? {uri: profileImage}
                                                            : require("../../assets/images/taskorbit.png")
                                                    }
                                                    style={styles.profileImage}
                                                />
                                            ))}
                                    </View>
                                </TouchableOpacity>
                            )
                        }}/>
                )}
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "#fff",
    },
    contentContainer: {
        paddingBottom: 500
        //flex: 1,
        //paddingBottom: 60,
    },
    headerContainer: {
        //marginTop: 15,
        flexDirection: "row",
        alignItems: "center",
    },
    logoContainer: {
        width: 50,
        height: 50,
        borderWidth: 2,
        borderRadius: 50,
        borderColor: "#2196f3",
        justifyContent: "center",
        alignItems: "center",
        marginLeft: 10,
        marginRight: 5,
    },
    logo: {
        width: "100%",
        height: "100%",
        borderRadius: 25,
    },
    greetingText: {
        fontSize: 22,
        fontWeight: "500",
        color: "#2196f3",
    },
    welcomeText: {
        fontSize: 17,
        color: "#000",
        marginTop: 2,
    },
    quickViewHeader: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        marginHorizontal: 10,
        marginTop: 25,
    },
    quickViewText: {
        fontSize: 20,
        fontWeight: "500",
        color: "#000",
    },
    dropdown: {
        width: 120,
        backgroundColor: "transparent",
        borderWidth: 1,
        borderColor: "grey",
        borderRadius: 10,
        padding: 7,
    },
    quickViewContainer: {
        flexDirection: "row",
        marginTop: 10,
    },
    leftContainer: {
        flex: 1,
        height: 250,
        backgroundColor: "#b3e0e8",
        borderRadius: 10,
        marginLeft: 10,
        marginRight: 10,
        padding: 10,
        justifyContent: "flex-start",
    },
    rightContainer: {
        marginRight: 10,
        flex: 1,
        flexDirection: "column",
    },
    topRightContainer: {
        flex: 1,
        backgroundColor: "#ffcccc",
        marginBottom: 10,
        borderRadius: 10,
        padding: 10,
        justifyContent: "flex-start",
    },
    bottomRightContainer: {
        flex: 1,
        backgroundColor: "#ffeb99",
        borderRadius: 10,
        padding: 10,
        justifyContent: "flex-start",
    },
    detailsContainer: {
        flexDirection: "row",
        justifyContent: "flex-end",
        alignItems: "center",
        marginTop: "auto",
    },
    detailsText: {
        fontSize: 14,
        color: "#000",
    },
    icon: {
        marginLeft: 5,
    },
    placeholderText: {
        fontSize: 20,
        fontWeight: "500",
        color: "#000",
        marginBottom: 10,
    },
    numberText: {
        fontSize: 24,
        fontWeight: "bold",
        color: "#000",
        marginBottom: 10,
    },
    reportsContainer: {
        marginHorizontal: 10,
        marginTop: 20,
    },
    reportsText: {
        fontSize: 20,
        fontWeight: "500",
        color: "#000",
        marginBottom: 0,
    },
    scrollView: {
        //top: 10,
        paddingBottom: 100,
        // maxHeight: 250,
    },
    reportItem: {
        backgroundColor: "#f9f9f9",
        padding: 15,
        marginBottom: 10,
        borderRadius: 10,
        borderWidth: 1,
        borderLeftWidth: 6,
        borderColor: "#ccc",
    },
    reportHeader: {
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
    },
    reportTitle: {
        fontSize: 18,
        color: "#161616",
        fontWeight: "bold",
        marginBottom: 5,
        flex: 2
    },
    statusContainer: {
        paddingHorizontal: 10,
        paddingVertical: 4,
        borderRadius: 15,
        marginRight: 5,
        marginBottom: 0,
    },
    statusText: {
        fontSize: 13,
        color: "black",
        fontWeight: "600",
        textAlign: "center",
        marginRight: 5,
    },
    reportDetails: {
        fontSize: 14,
        color: "#adacb2",
        marginBottom: 5,
    },
    taskHeader: {
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
    },
    taskCount: {
        fontSize: 16,
        fontWeight: "400",
        color: "#2196f3",
    },
    taskCountContainer: {
        flexDirection: "row",
        alignItems: "center",
    },
    completedContainer: {
        flexDirection: "row",
        alignItems: "center",
    },
    reportsHeader: {
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        marginBottom: 10,
    },
    createTaskButton: {
        flexDirection: "row",
        backgroundColor: "transparent",
        borderWidth: 1,
        borderColor: "grey",
        borderRadius: 10,
        padding: 7,
    },
    createTaskButtonText: {
        color: "black",
        fontSize: 16,
    },
    switchContainer: {
        flexDirection: "row",
        alignSelf: "center",
        width: "100%",
        marginBottom: 10,
        borderRadius: 10,
        backgroundColor: "#eee",
    },
    switchOption: {
        borderRadius: 10,
        width: "47%",
        paddingVertical: 10,
        paddingHorizontal: 20,
        marginVertical: 5,
        marginHorizontal: 5,
        shadowOpacity: 0.2,
        shadowRadius: 2,
        shadowOffset: 10,
    },
    activeOption: {
        backgroundColor: "#fff",
    },
    switchText: {
        alignSelf: "center",
        color: "black",
    },
    profileImagesContainer: {
        flexDirection: "row",
        alignItems: "center",
        marginTop: 25,
    },
    profileImage: {
        borderWidth: 1.5,
        borderColor: "#f9f9f9",
        width: 40,
        height: 40,
        borderRadius: 20,
        backgroundColor: "#eee",
        marginRight: -10,
    },
    moreText: {
        fontSize: 16,
        color: "#7E818E",
        marginLeft: 10,
    },
});
