import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  TextInput,
  Alert,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  TouchableWithoutFeedback,
  Keyboard,
  Image,
  ScrollView,
  Animated
} from 'react-native';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import Constants from 'expo-constants';
import axios from 'axios';
import { useNavigation, useRoute } from '@react-navigation/native';

const ChatScreen = ( ) => {
    const navigation = useNavigation();
    const route = useRoute();
    const { roles, businessId} = route.params;
    const [tasks, setTasks] = useState([]);
    const [responses, setResponses] = useState({
    title: '',
    tasks: '',
  });
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [messages, setMessages] = useState([]);
  const [messagesToSend, setMessagesToSend] = useState('');
  const [animationValues, setAnimationValues] = useState([]);
  const scrollViewRef = useRef(null);
  const [isThinking, setIsThinking] = useState(false);
  const [dotAnimationValues, setDotAnimationValues] = useState([new Animated.Value(0), new Animated.Value(0), new Animated.Value(0)]);

  const initialMessages = [
    { text: "Welcome to TaskOrbits tasklist creation screen! My name is ORBOT.", type: 'question' },
    { text: "Let's setup your new tasklist! Could you please shortly describe what the tasklist is about?", type: 'question' },
  ];

  const questions = [
    "Could you please shortly describe what the tasklist is about?",
    "That's perfect! Are there any specific things you want inside the tasklist?"
  ];

  useEffect(() => {
    const startAnimations = () => {
      dotAnimationValues.forEach((value, index) => {
        Animated.loop(
          Animated.sequence([
            Animated.timing(value, {
              toValue: 1,
              duration: 500,
              useNativeDriver: true,
              delay: index * 200,
            }),
            Animated.timing(value, {
              toValue: 0,
              duration: 500,
              useNativeDriver: true,
            }),
          ])
        ).start();
      });
    };

    if (isThinking) {
      startAnimations();
    }
  }, [isThinking]);

  useEffect(() => {
    const delay = 1000;
    const timer = setTimeout(() => {
      setMessages(initialMessages);

      const values = initialMessages.map(() => new Animated.Value(0));
      setAnimationValues(values);

      values.forEach((value, index) => {
        Animated.timing(value, {
          toValue: 1,
          duration: 500,
          useNativeDriver: true,
        }).start();
      });
    }, delay);

    return () => clearTimeout(timer);
  }, []);

  const handleInputChange = (input) => {
    setResponses((prev) => ({
      ...prev,
      [currentQuestionIndex === 0 ? 'title' : 'tasks']: input,
    }));
  };

  const validateResponse = async (question, answer) => {
    setIsThinking(true);
    try {
      const messagesToSend = [
        { role: "system", content: "You are a helpful assistant helping validate user responses." },
        { role: "user", content: `Does this response: "${answer}" somewhat answer the question: "${question}" even if it doesn't 100% answer it? If yes, respond 'Yes'. If no, respond 'No'. Make sure not to include a dot after 'Yes' or 'No' in your response.` }
      ];

      const response = await axios.post(
        'https://api.openai.com/v1/chat/completions',
        {
          model: "gpt-4o-mini",
          messages: messagesToSend,
          max_tokens: 5,
        },
        {
          headers: {
            'Authorization': `Bearer ${Constants.expoConfig.extra.openai.apiKey}`,
            'Content-Type': 'application/json',
          }
        }
      );

      const aiAnswer = response.data.choices[0].message.content.trim();
      console.log('AI validation response:', aiAnswer);
      return aiAnswer === "Yes";
    } catch (error) {
      console.error("Error from AI:", error);
      return false;
    } finally {
        setIsThinking(false);
    }
  };

  const generateTaskList = async (questionsAndAnswers) => {
    setIsThinking(true);
    console.log(questionsAndAnswers);

    try {
      const messagesToSend = [
        {
          role: "system",
          content: "You are a helpful assistant assisting in creating a task list for a company."
        },
        {
          role: "user",
          content: `The user has been asked the following questions and provided these responses:\n${questionsAndAnswers}. 
          Please generate general task(s) based on the user's input. Each task should include a title and type.
          Be in depth, and look at what goes in to the task. We want the person using you to be able to take thinking out of it.
          Make the title also a kind of description so it describes what the user should do.
          Depending on the type of task, assign the appropriate icon from the following list:\n
          - Short Entry (has an icon of: text-fields)\n
          - Checkmark (has an icon of: check-circle)\n
          - Signature (has an icon of: edit)\n
          - Yes/No (has an icon of: help)\n
          - Date (has an icon of: date-range)\n
          - QR Code (has an icon of: qr-code)\n
          Format the output as an array of tasks:\n
          [{"color": "#dcdcdc", "name": "(Task list name)", "type": {"icon": "(Task icon)", "title": "(Task type)"}}, (MORE HERE IF NEEDED)]
          So the format should be json. Only give back the JSON, no text at all besides that! Not even comma's etc. So don't for example write: '''json (json here). Only give the json it super important that you don't include anything besides the json. Use a maximum of 800 tokens`
        }
      ];

      const response = await axios.post(
        'https://api.openai.com/v1/chat/completions',
        {
          model: "gpt-4o-mini",
          messages: messagesToSend,
          max_tokens: 800,
        },
        {
          headers: {
            'Authorization': `Bearer ${Constants.expoConfig.extra.openai.apiKey}`,
            'Content-Type': 'application/json',
          }
        }
      );

      const taskList = response.data.choices[0].message.content.trim();
      console.log('Generated Task List:', taskList);


      const parsedTasks = JSON.parse(taskList);


      setTasks(parsedTasks);


      setMessages((prevMessages) => [
        ...prevMessages,
        { text: 'Here is what we came up with:', type: 'question' },
        { text: taskList, type: 'question' },
      ]);

    } catch (error) {
      console.error("Error generating task list:", error);
    } finally {

      setIsThinking(false);
    }
  };


useEffect(() => {
    if (tasks.length > 0) {
      navigation.replace('(app)/create_task_aiResults', {
        roles: roles, businessId: businessId, routetasks: tasks
      });
    }
  }, [tasks]);

  const handleSubmit = async () => {
    Keyboard.dismiss();
    const currentQuestion = questions[currentQuestionIndex];
    const userResponse = responses[currentQuestionIndex === 0 ? 'title' : 'tasks'];
    setResponses((prev) => ({
        ...prev,
        [currentQuestionIndex === 0 ? 'title' : 'tasks']: userResponse
    }));
    setMessages((prevMessages) => [...prevMessages, { text: userResponse, type: 'response' }]);

    if (currentQuestionIndex === 0) {
      const isValid = await validateResponse(currentQuestion, userResponse);

      if (isValid) {
        const newAnimationValue = new Animated.Value(0);
        setAnimationValues((prev) => [...prev, newAnimationValue]);

        Animated.timing(newAnimationValue, {
          toValue: 1,
          duration: 500,
          useNativeDriver: true,
        }).start();

        if (currentQuestionIndex < questions.length - 1) {
          setMessages((prevMessages) => [
            ...prevMessages,
            { text: questions[currentQuestionIndex + 1], type: 'question' }
          ]);
          setCurrentQuestionIndex((prev) => prev + 1);
        }
      } else {
        setMessages((prevMessages) => [
          ...prevMessages,
          { text: "It seems that your answer doesn't quite match the question. Could you please try rephrasing?", type: 'question' }
        ]);
      }
    } else {
      if (currentQuestionIndex < questions.length - 1) {
        setMessages((prevMessages) => [
          ...prevMessages,
          { text: questions[currentQuestionIndex + 1], type: 'question' }
        ]);
        setCurrentQuestionIndex((prev) => prev + 1);
      } else {
        const questionsAndAnswers = questions.map((q, i) => `Q: ${q}\nA: ${responses[i === 0 ? 'title' : 'tasks']}`).join('\n');
        await generateTaskList(questionsAndAnswers);
      }
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      keyboardVerticalOffset={0}
    >
      <View style={styles.safeArea}>
      <TouchableOpacity
  style={styles.backButton}
  onPress={() => navigation.goBack()}
>
  <MaterialIcons name="arrow-back" size={24} color="#333" />
</TouchableOpacity>
        <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
          <ScrollView
            ref={scrollViewRef}
            style={styles.messagesContainer}
            contentContainerStyle={styles.scrollContainer}
            onContentSizeChange={() => scrollViewRef.current.scrollToEnd({ animated: true })}
          >
            {messages.map((msg, index) => (
              <Animated.View
                key={index}
                style={{
                  opacity: animationValues[index] || 1,
                  transform: [{
                    translateY: animationValues[index] ? animationValues[index].interpolate({
                      inputRange: [0, 1],
                      outputRange: [20, 0],
                    }) : 0
                  }]
                }}
              >
                <View style={msg.type === 'question' ? styles.questionContainer : styles.responseContainer}>
                  {msg.type === 'question' && (
                    <Image
                      source={require('../../assets/images/taskorbit.png')}
                      style={styles.icon}
                    />
                  )}
                  <View style={msg.type === 'question' ? styles.questionBubble : styles.responseBubble}>
                    <Text style={msg.type === 'question' ? styles.messageText : styles.responseText}>
                      {msg.text}
                    </Text>
                  </View>
                </View>
              </Animated.View>
            ))}
{isThinking && (
  <View style={styles.thinkingContainer}>
    <Image source={require('../../assets/images/taskorbit.png')} style={styles.logo} />
    <Text style={styles.thinkingText}> Orbit is working on its Task</Text>
    <View style={styles.dotsContainer}>
      {dotAnimationValues.map((value, index) => (
        <Animated.Text
          key={index}
          style={{
            color: '#2196f3',
            transform: [{
              translateY: value.interpolate({
                inputRange: [0, 1],
                outputRange: [0, -5],
              }),
            }],
          }}>
          {'.'}
        </Animated.Text>
      ))}
    </View>
    <Image source={require('../../assets/images/taskorbit.png')} style={styles.logo} />
  </View>
)}
          </ScrollView>
        </TouchableWithoutFeedback>
        <View style={styles.inputContainer}>
          <TextInput
            style={styles.input}
            placeholder="Type your answer..."
            placeholderTextColor={'#ccc'}
            value={responses[currentQuestionIndex === 0 ? 'title' : 'tasks']}
            onChangeText={handleInputChange}
            onSubmitEditing={handleSubmit}
          />
          <TouchableOpacity style={styles.sendButton} onPress={handleSubmit}>
            <MaterialIcons name="send" size={24} color="#2196f3" />
          </TouchableOpacity>
        </View>
      </View>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  messagesContainer: {
    flex: 1,
    marginHorizontal: 10,
  },
  scrollContainer: {
    flexGrow: 1,
    justifyContent: 'flex-end',
  },
  questionContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  responseContainer: {
    alignItems: 'flex-end',
  },
  questionBubble: {
    backgroundColor: '#2196f3',
    borderRadius: 15,
    padding: 15,
    marginVertical: 5,
    maxWidth: '80%',
  },
  responseBubble: {
    backgroundColor: '#e0e0e0',
    borderRadius: 15,
    padding: 15,
    marginVertical: 5,
    maxWidth: '80%',
  },
  messageText: {
    color: '#fff',
  },
  responseText: {
    color: '#000',
  },
  icon: {
    width: 60,
    height: 60,
    marginRight: 0,
  },
  inputContainer: {
    marginHorizontal: 10,
    marginBottom: 10,
    flexDirection: 'row',
    alignItems: 'center',
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 10,
    backgroundColor: '#fff',
  },
  input: {
    flex: 1,
    height: 40,
    paddingLeft: 10,
    backgroundColor: 'transparent',
    marginRight: 10,
    borderWidth: 0,
  },
  sendButton: {
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: 15,
  },
  backButton: {
    position: 'absolute',
    backgroundColor: 'white',
    borderRadius: 50,
    top: 50,
    left: 25,
    zIndex: 1,
  },
  thinkingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 5,
    justifyContent: 'center',
  },
  logo: {
    width: 20,
    height: 20,
    marginHorizontal: 5,
  },
  thinkingText: {
    color: '#2196f3',
    fontSize: 16,
    marginLeft: 0,
  },
  dotsContainer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
  },
});

export default ChatScreen;
