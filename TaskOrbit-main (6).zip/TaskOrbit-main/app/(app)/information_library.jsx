import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  SafeAreaView,
  Modal,
  TextInput,
  TouchableWithoutFeedback,
  Alert,
  FlatList,
  Linking,
  KeyboardAvoidingView,
  Platform
} from 'react-native';
import { doc, getDoc } from "firebase/firestore";
import { getDatabase, ref, onValue, push, set } from "firebase/database";
import Icon from 'react-native-vector-icons/MaterialIcons';
import { auth, firestore, database } from "../(api)/firebase";
import {
    getStorage,
    getDownloadURL,
    ref as sRef,
    uploadBytes,
  } from "firebase/storage";
  import { useNavigation } from "@react-navigation/native";

  let DocumentPicker;
if (Platform.OS !== 'web') {
  DocumentPicker = require('react-native-document-picker');
}

const InformationLibrary = () => {
  const [modalVisible, setModalVisible] = useState(false);
  const [folderModalVisible, setFolderModalVisible] = useState(false);
  const [folders, setFolders] = useState([]);
  const [folderName, setFolderName] = useState('');
  const [currentFolder, setCurrentFolder] = useState(null);
    const navigation = useNavigation();
    const [folderHistory, setFolderHistory] = useState([]);
    const [webModalVisible, setWebModalVisible] = useState(false);
    const [isEditMode, setIsEditMode] = useState(false);

    useEffect(() => {
      fetchFolders();
    }, []);

  const handleAddFilePress = async () => {
    if (Platform.OS !== 'web') {
    try {
      const res = await DocumentPicker.pick({
        type: [DocumentPicker.types.allFiles],
      });


      const fileType = res[0].type;


      const file = res[0];
      const storage = getStorage();
      const fileRef = sRef(storage, `Documents/${currentFolder}/${file.name}`);

      const fileBlob = await fetch(file.uri).then((res) => res.blob());

      await uploadBytes(fileRef, fileBlob);


      const downloadURL = await getDownloadURL(fileRef);


      const userId = auth.currentUser.uid;
      const userDoc = await getDoc(doc(firestore, "Users", userId));

      if (!userDoc.exists) {
        console.error("User not found in Firestore.");
        return;
      }

      const businessId = userDoc.data().businessId;
      const db = getDatabase();

      const fileData = {
        fileName: file.name,
        fileType,
        fileUrl: downloadURL,
        uploadedAt: new Date().toISOString(),
      };

      const folderRef = ref(db, currentFolder ? `Businesses/${businessId}/Documents/${currentFolder}/files` : `Businesses/${businessId}/Documents`);
      await push(folderRef, fileData);

      setModalVisible(false);
    } catch (err) {
      if (DocumentPicker.isCancel(err)) {
        console.log('User canceled the picker');
      } else {
        console.error('Error uploading file:', err);
        Alert.alert('Error', 'Could not upload the file.');
      }
    }
  } else {
    setModalVisible(false);
    setWebModalVisible(true);
  }
  };

  const handleDelete = async (itemId, isFile = true) => {
    const itemType = isFile ? 'file' : 'folder';
    const deleteMessage = isFile
      ? `Are you sure you want to delete this ${itemType}?`
      : `Are you sure you want to delete this ${itemType}? This will also remove its contents.`;

    Alert.alert(
      "Confirm Deletion",
      deleteMessage,
      [
        {
          text: "Cancel",
          style: "cancel",
        },
        {
          text: "Delete",
          style: "destructive",
          onPress: async () => {
            try {
              const userId = auth.currentUser.uid;
              const userDoc = await getDoc(doc(firestore, "Users", userId));

              if (!userDoc.exists) {
                console.error("User not found in Firestore.");
                return;
              }

              const businessId = userDoc.data().businessId;
              const db = getDatabase();

              console.log("Deleting item", itemId, "Is File:", isFile);

              if (isFile) {
                const refPath = currentFolder
                  ? `Businesses/${businessId}/Documents/${currentFolder}/files/${itemId}`
                  : `Businesses/${businessId}/Documents/${itemId}`;
                const fileRef = ref(db, refPath);
                console.log("Deleting file from", fileRef.toString());
                await set(fileRef, null);
              } else {
                const refPath = currentFolder
                  ? `Businesses/${businessId}/Documents/${currentFolder}/subfolders/${itemId}`
                  : `Businesses/${businessId}/Documents/${itemId}`;
                const folderRef = ref(db, refPath);
                console.log("Deleting folder from", folderRef.toString());
                await set(folderRef, null);
              }

              fetchFolders(currentFolder);

            } catch (error) {
              console.error("Error deleting item:", error);
              Alert.alert("Error", "Could not delete the item.");
            }
          },
        },
      ],
      { cancelable: true }
    );
  };

  const fetchFolders = async (folderId = '') => {
    try {
      const userId = auth.currentUser.uid;
      const userDoc = await getDoc(doc(firestore, "Users", userId));

      if (!userDoc.exists) {
        console.error("User not found in Firestore.");
        return;
      }

      const businessId = userDoc.data().businessId;

      if (!businessId) {
        console.error("Business ID not found.");
        return;
      }

      const db = getDatabase();
      const folderRef = folderId
        ? ref(db, `Businesses/${businessId}/Documents/${folderId}/subfolders`)
        : ref(db, `Businesses/${businessId}/Documents`);

      onValue(folderRef, (snapshot) => {
        if (snapshot.exists()) {
          const data = snapshot.val();
          const folderList = Object.entries(data).map(([key, value]) => ({
            id: key,
            ...value,
          }));

          if (folderId) {
            const fileRef = ref(db, `Businesses/${businessId}/Documents/${folderId}/files`);
            onValue(fileRef, (fileSnapshot) => {
              if (fileSnapshot.exists()) {
                const fileData = fileSnapshot.val();
                const fileList = Object.entries(fileData).map(([fileKey, fileValue]) => ({
                  id: fileKey,
                  ...fileValue,
                }));
                setFolders((prev) => [...folderList, ...fileList]);
              } else {
                setFolders(folderList);
              }
            });
          } else {
            setFolders(folderList);
          }
        } else {
          setFolders([]);
        }
      });
    } catch (error) {
      console.error("Error fetching folders:", error);
    }
  };

  const handleAddPress = () => {
    setModalVisible(true);
  };

  const handleCreateFolder = async () => {
    if (folderName == '') {
        Alert.alert('Error', 'Please enter a folder name.');
        return;
    }
    try {
      const userId = auth.currentUser.uid;
      const userDoc = await getDoc(doc(firestore, "Users", userId));

      if (!userDoc.exists) {
        Alert.alert('Error', 'User not found in Firestore.');
        return;
      }

      const businessId = userDoc.data().businessId;

      if (!businessId) {
        Alert.alert('Error', 'Business ID not found.');
        return;
      }

      const db = getDatabase();
      const folderRef = currentFolder
        ? ref(db, `Businesses/${businessId}/Documents/${currentFolder}/subfolders`)
        : ref(db, `Businesses/${businessId}/Documents`);

      const folderData = {
        folderName,
        createdAt: new Date().toISOString()
      };

      await push(folderRef, folderData);

      setFolderName('');
      setFolderModalVisible(false);
      fetchFolders(currentFolder);
    } catch (error) {
      Alert.alert('Error', 'Could not create folder.');
      console.error(error);
    }
  };

  const handleBackPress = () => {
    if (folderHistory.length > 0) {
        const lastFolder = folderHistory[folderHistory.length - 1];
        setFolderHistory((prevHistory) => prevHistory.slice(0, -1));
        setCurrentFolder(lastFolder);
        fetchFolders(lastFolder);
    } else {
        navigation.goBack();
    }
};

const handleDownloadFile = async (fileUrl) => {
    try {

      await Linking.openURL(fileUrl);
    } catch (error) {
      console.error('Error opening file:', error);
      Alert.alert('Error', 'Could not open the file.');
    }
  };

  return (
    <View style={styles.container}>
      {/* Header */}
  <TouchableOpacity style={styles.backButton} onPress={handleBackPress}>
    <Icon name="arrow-back" size={30} color="black" />
  </TouchableOpacity>
      <View style={styles.header}>
      <TouchableOpacity style={styles.editButton} onPress={() => setIsEditMode(prev => !prev)}>
  <Icon name={isEditMode ? "check" : "edit"} size={20} color="black" />
</TouchableOpacity>
        <TouchableOpacity style={styles.plusButton} onPress={handleAddPress}>
          <Icon name="add" size={30} color="black" />
        </TouchableOpacity>
      </View>

      {/* Centered Logo */}
      <Image
        source={require('../../assets/images/taskorbit.png')}
        style={styles.logo}
      />

      {/* Page Title */}
      <Text style={styles.title}>Information Library</Text>

      <View style={styles.contentPlaceholder}>
  {folders.length === 0 ? (
    <Text style={styles.placeholderText}>No files or subfolders yet.</Text>
  ) : (
    <FlatList
      data={folders}
      keyExtractor={(item) => item.id}
      style={{paddingHorizontal: 10, width: '100%'}}
      renderItem={({ item }) => (
<View style={styles.folderItem}>
  <TouchableOpacity
    onPress={() => {
      if (item.fileUrl) {
        handleDownloadFile(item.fileUrl, item.fileName);
      } else {
        setFolderHistory((prevHistory) => [...prevHistory, currentFolder]);
        setCurrentFolder(item.id);
        fetchFolders(item.id);
      }
    }}
    style={{ flexDirection: 'row', alignItems: 'center', flex: 1 }}
  >
    {item.fileUrl ? (
      <Icon name="attach-file" size={24} color="#333" />
    ) : (
      <Icon name="folder" size={24} color="#333" />
    )}
    <Text style={styles.folderText}>{item.fileName || item.folderName}</Text>
  </TouchableOpacity>

  {/* Trash Bin Icon */}
  <TouchableOpacity
  onPress={() => isEditMode && handleDelete(item.id, !!item.fileUrl)}
  style={[styles.trashIcon, { opacity: isEditMode ? 1 : 0 }]}
  disabled={!isEditMode}
  >
    <Icon name="delete" size={24} color="red" />
  </TouchableOpacity>
</View>
      )}
/>
  )}
</View>

      {/* Modal for Options */}
      <Modal
        transparent={true}
        visible={modalVisible}
        animationType="fade"
        onRequestClose={() => setModalVisible(false)}
      >
        <TouchableWithoutFeedback onPress={() => setModalVisible(false)}>
          <View style={styles.modalOverlay} />
        </TouchableWithoutFeedback>
        <View style={styles.modalContent}>
          <Text style={styles.modalTitle}>Add New Item</Text>
          <TouchableOpacity
  style={styles.modalOption}
  onPress={() => {
    setModalVisible(false);
    setFolderModalVisible(true);
  }}
>
  <View style={styles.modalOptionContent}>
    <Icon name="create-new-folder" size={24} color="#333" />
    <Text style={styles.modalOptionText}>Create Folder</Text>
  </View>
</TouchableOpacity>
<TouchableOpacity
  style={styles.modalOption}
  onPress={handleAddFilePress}
>
  <View style={styles.modalOptionContent}>
    <Icon name="note-add" size={24} color="#333" />
    <Text style={styles.modalOptionText}>Add File</Text>
  </View>
</TouchableOpacity>
          <TouchableOpacity
            style={styles.modalOption}
            onPress={() => setModalVisible(false)}
          >
            <Text style={[styles.modalOptionText, { color: 'red' }]}>Cancel</Text>
          </TouchableOpacity>
        </View>
      </Modal>

      {/* Modal for Folder Name */}
      <Modal
  transparent={true}
  visible={folderModalVisible}
  animationType="slide"
  onRequestClose={() => setFolderModalVisible(false)}
>
  <TouchableWithoutFeedback onPress={() => setFolderModalVisible(false)}>
    <View style={styles.modalOverlay} />
  </TouchableWithoutFeedback>

  <KeyboardAvoidingView
    behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    style={styles.folderModalContent}
  >
    <Text style={styles.modalTitle}>Create Folder</Text>
    <TextInput
      style={styles.input}
      placeholder="Enter folder name"
      placeholderTextColor={'#ccc'}
      value={folderName}
      onChangeText={setFolderName}
    />
    <View style={styles.modalButtons}>
      <TouchableOpacity
        style={styles.modalOption}
        onPress={() => setFolderModalVisible(false)}
      >
        <Text style={[styles.modalOptionText, { color: 'red' }]}>Cancel</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={styles.modalOption}
        onPress={handleCreateFolder}
      >
        <Text style={styles.modalOptionText}>Create</Text>
      </TouchableOpacity>
    </View>
  </KeyboardAvoidingView>
</Modal>

<Modal
  transparent={true}
  visible={webModalVisible}
  animationType="fade"
  onRequestClose={() => setWebModalVisible(false)}
>
  <TouchableWithoutFeedback onPress={() => setWebModalVisible(false)}>
    <View style={styles.modalOverlay} />
  </TouchableWithoutFeedback>
  <View style={styles.modalContent}>
    <Text style={styles.modalTitle}>Feature Unavailable</Text>
    <Text style={styles.modalOptionText}>
      Uploading files is currently only available on iOS and Android devices. Please try using one of these platforms.
    </Text>
    <TouchableOpacity
      style={[styles.modalOption, { marginTop: 20 }]}
      onPress={() => setWebModalVisible(false)}
    >
      <Text style={[styles.modalOptionText, { color: 'black' }]}>Close</Text>
    </TouchableOpacity>
  </View>
</Modal>

    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9f9f9',
    paddingHorizontal: 20,
    paddingTop: 40,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    alignItems: 'center',
    position: 'absolute',
    top: 45,
    right: 20,
  },
  logo: {
    width: 100,
    height: 100,
    resizeMode: 'contain',
    alignSelf: 'center',
    marginTop: 0,
  },
  plusButton: {
    padding: 5,
  },
  title: {
    alignSelf: 'center',
    fontSize: 24,
    fontWeight: 'bold',
    marginHorizontal: 20
  },
  contentPlaceholder: {
    flex: 1,
    alignItems: 'flex-start',
    paddingLeft: 10,
    marginTop: 20,
    width: '100%',
  },
  placeholderText: {
    alignSelf: 'center',
    fontSize: 16,
    color: '#7e7e7e',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalOptionContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  modalContent: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'white',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 5,
  },
  folderModalContent: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'white',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 5,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  modalOption: {
    paddingVertical: 15,
    borderWidth: 1,
    borderRadius: 15,
    padding: 20,
    marginVertical: 5,
    borderColor: '#ddd',
  },
  modalOptionText: {
    fontSize: 16,
    color: '#333',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    color: 'black',
    borderRadius: 5,
    padding: 10,
    fontSize: 16,
    marginBottom: 10,
  },
  modalButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  folderItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 15,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 10,
    paddingHorizontal: 10,
    marginBottom: 10,
    width: '100%',
    justifyContent: 'space-between',
  },
  folderText: {
    fontSize: 18,
    marginLeft: 15,
    color: '#333',
  },
  backButton: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    alignItems: 'center',
    position: 'absolute',
    top: 45,
    left: 20,
    padding: 5,
  },

});

export default InformationLibrary;
