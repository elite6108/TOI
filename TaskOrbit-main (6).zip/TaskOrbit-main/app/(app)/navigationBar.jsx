import React, { useState, useEffect } from "react";
import { View, StyleSheet, TouchableOpacity } from "react-native";
import { Feather } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";

const Navigation = ({ currentPage }) => {
  const [selectedPage, setSelectedPage] = useState(currentPage);
  const navigation = useNavigation();

  useEffect(() => {
    setSelectedPage(currentPage);
  }, [currentPage]);

  const handlePress = (page) => {
    setSelectedPage(page);
    navigation.replace(page);
  };

  const pages = [
    { name: "(app)/dashboard", icon: "home" },
    { name: "(app)/search", icon: "search" },
    { name: "(app)/task_overview", icon: "trello" },
    { name: "(app)/project_overview", icon: "file" },
    { name: "(app)/settings", icon: "user" },
  ];

  return (
    <View style={styles.navContainer}>
      {pages.map((page) => (
        <TouchableOpacity
          key={page.name}
          style={[
            styles.navButton,
            selectedPage === page.name && styles.selectedButton,
          ]}
          onPress={() => handlePress(page.name)}
        >
          <Feather
            name={page.icon}
            size={24}
            color={selectedPage === page.name ? "#AA90E7" : "#898A94"}
          />
        </TouchableOpacity>
      ))}
    </View>
  );
};

const styles = StyleSheet.create({
  navContainer: {
    flexDirection: "row",
    justifyContent: "space-around",
    alignItems: "center",
    height: 60,
    backgroundColor: "transparent",
    borderTopWidth: 1,
    borderTopColor: "#ccc",
  },
  navButton: {
    width: 50,
    height: 50,
    borderRadius: 25,
    alignItems: "center",
    justifyContent: "center",
  },
  selectedButton: {
    backgroundColor: "rgba(243, 238, 251, 1)",
  },
});

export default Navigation;
