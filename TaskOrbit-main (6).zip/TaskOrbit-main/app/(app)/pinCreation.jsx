import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Alert
} from 'react-native';
import { firestore, auth } from '../(api)/firebase';
import { doc, setDoc } from 'firebase/firestore';
import Constants from 'expo-constants';
import CryptoJS from 'crypto-js';

const secretKey = Constants.expoConfig.extra.firebase.pinEncryptionKey;

const PinEntryScreen = ({ route, navigation }) => {
  const userId = auth.currentUser.uid;
  const [pin, setPin] = useState('');
  const [titleText, setTitleText] = useState('Create your PIN code');
  const [firstPinEntry, setFirstPinEntry] = useState(null);
  const [dotAnimations] = useState([
    new Animated.Value(1),
    new Animated.Value(1),
    new Animated.Value(1),
    new Animated.Value(1)
  ]);

  const handlePinPress = (number) => {
    if (pin.length < 4) {
      const newPin = pin + number;
      setPin(newPin);

      const index = newPin.length - 1;
      animateDot(index, true);

      if (newPin.length === 4) {
        handleSubmit(newPin);
      }
    }
  };

  const handleBackPress = () => {
    if (pin.length > 0) {
      const newPin = pin.slice(0, -1);
      setPin(newPin);

      animateDot(newPin.length, false);
    }
  };

  const animateDot = (index, enlarge) => {
    Animated.timing(dotAnimations[index], {
      toValue: enlarge ? 1.6 : 1,
      duration: 200,
      useNativeDriver: true,
    }).start();
  };

  const resetDots = () => {
    dotAnimations.forEach((animation) => {
      Animated.timing(animation, {
        toValue: 1,
        duration: 200,
        useNativeDriver: true,
      }).start();
    });
  };

  const handleSubmit = async (submittedPin) => {
    if (firstPinEntry === null) {
      setFirstPinEntry(submittedPin);
      setPin('');
      resetDots();
      console.log('Please confirm your PIN');
      setTitleText('Please confirm your PIN');
    } else if (submittedPin === firstPinEntry) {
      try {
        await setDoc(doc(firestore, 'Users', userId), { loginPin: submittedPin }, { merge: true });
        console.log('PIN set successfully');
        navigation.replace('BottomTabs');
      } catch (error) {
        console.error('Error setting PIN: ', error);
      }
    } else {
      Alert.alert('PINs do not match', 'Please try again.');
      console.log('PINs do not match. Please try again.');
      setTitleText('Create your PIN code');
      setFirstPinEntry(null);
      setPin('');
      resetDots();
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>{titleText}</Text>
      <View style={styles.pinDisplay}>
        <View style={styles.dotsContainer}>
          {Array.from({ length: 4 }, (_, index) => (
            <Animated.View
              key={index}
              style={[
                styles.dot,
                {
                  transform: [{ scale: dotAnimations[index] }],
                },
              ]}
            />
          ))}
        </View>
      </View>
      <View style={styles.buttonContainer}>
        {/* Buttons */}
        <View style={styles.row}>
          {[1, 2, 3].map((number) => (
            <TouchableOpacity
              key={number}
              style={styles.button}
              onPress={() => handlePinPress(number)}
            >
              <Text style={styles.buttonText}>{number}</Text>
            </TouchableOpacity>
          ))}
        </View>
        <View style={styles.row}>
          {[4, 5, 6].map((number) => (
            <TouchableOpacity
              key={number}
              style={styles.button}
              onPress={() => handlePinPress(number)}
            >
              <Text style={styles.buttonText}>{number}</Text>
            </TouchableOpacity>
          ))}
        </View>
        <View style={styles.row}>
          {[7, 8, 9].map((number) => (
            <TouchableOpacity
              key={number}
              style={styles.button}
              onPress={() => handlePinPress(number)}
            >
              <Text style={styles.buttonText}>{number}</Text>
            </TouchableOpacity>
          ))}
        </View>
        <View style={styles.row}>
          <View style={styles.emptyButton}></View>
          <TouchableOpacity style={styles.button} onPress={() => handlePinPress(0)}>
            <Text style={styles.buttonText}>0</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.button} onPress={handleBackPress}>
            <Text style={styles.buttonText}>←</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
  },
  title: {
    fontSize: 24,
    marginBottom: 20,
  },
  pinDisplay: {
    marginBottom: 20,
  },
  dotsContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
  },
  dot: {
    width: 10,
    height: 10,
    borderRadius: 10,
    backgroundColor: '#2196f3',
    margin: 10,
  },
  buttonContainer: {
    width: '60%',
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginVertical: 5,
  },
  button: {
    width: '30%',
    height: 60,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'transparent',
    borderRadius: 5,
  },
  buttonText: {
    fontSize: 24,
    color: 'black',
  },
  emptyButton: {
    width: '30%',
  },
});

export default PinEntryScreen;
