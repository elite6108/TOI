import React, {useMemo, useRef, useState} from "react";
import {
  Alert,
  Animated,
  Image,
  KeyboardAvoidingView,
  Linking,
  Modal,
  Platform,
  ScrollView,
  Share,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View
} from "react-native";
import {doc, getDoc, getFirestore, updateDoc, deleteField} from "firebase/firestore";
import {getDatabase, onValue, push, ref} from "firebase/database";
import {firestore} from "../(api)/firebase";
import MapView, {Marker} from "react-native-maps";
import {useNavigation, useRoute} from "@react-navigation/native";
import Constants from "expo-constants";
import {getDownloadURL, getStorage, ref as sRef, uploadBytes,} from "firebase/storage";
import * as Location from "expo-location";
import Ionicons from "react-native-vector-icons/Ionicons";
import Feather from "react-native-vector-icons/Feather";
import BottomSheet, {BottomSheetView} from "@gorhom/bottom-sheet";
import Icon from "react-native-vector-icons/FontAwesome";
import {launchImageLibrary} from "react-native-image-picker";
import {ReactNativeZoomableView} from "@openspacelabs/react-native-zoomable-view";
import SignatureModal from "@/app/modal/SignatureModal";
import RNHTMLtoPDF from "react-native-html-to-pdf";
import SignatureView from "react-native-signature-canvas";
import SignatureScreen from "react-native-signature-canvas";

const ProjectDetails = () => {
    const route = useRoute();
    const project = route.params.project;
    const {businessId, fullName} = route.params;
    const googleApi = Constants.expoConfig.extra.google.apiKey;
    const [profilePictures, setProfilePictures] = React.useState({});
    const [coordinates, setCoordinates] = React.useState(null);
    const [userLocation, setUserLocation] = React.useState(null);
    const navigation = useNavigation();
    const [overlayOpacity] = useState(new Animated.Value(0));
    const [isBottomSheetOpen, setIsBottomSheetOpen] = useState(false);
    const bottomSheetRef = useRef(null);
    const [noteInput, setNoteInput] = useState("");
    const [attachedTasklist, setAttachedTasklist] = useState(null);
    const [notes, setNotes] = useState([]);
    const [isPopupVisible, setIsPopupVisible] = useState(false);
    const [selectedMedia, setSelectedMedia] = useState([]);
    const [isImagePopupVisible, setIsImagePopupVisible] = useState(false);
    const [currentImage, setCurrentImage] = useState(null);
    const [showModal, setShowModal] = useState(false);
    const [signature, setSignature] = useState(null);
    const signatureRef = useRef();
    const [roles, setRoles] = useState("");


    const isDisabled= useMemo(()=>{
        if (project?.taskId ){
            return project?.taskListStatus!=='Completed'
        } else {
            return  false;
        }
    },[])

    const openImagePopup = (image) => {
        setCurrentImage(image);
        setIsImagePopupVisible(true);
    };

    const handleSignature = (signatureData) => {
        setSignature(signatureData);
        setShowModal(false)
        updateProjectStatusToClosed(signatureData)
    };

    const handleCloseModal = () => setShowModal(false);

    const closeImagePopup = () => {
        setIsImagePopupVisible(false);
    };

    const handleSheetChange = (index) => {
        if (index > 0) {
            if (!isBottomSheetOpen) {
                setIsBottomSheetOpen(index > 0);
                fadeInOverlay();
            }
        } else {
            if (isBottomSheetOpen) {
                setIsBottomSheetOpen(index > 0);
                fadeOutOverlay();
            }
        }
    };

    const togglePopup = () => {
        setIsPopupVisible(!isPopupVisible);
        bottomSheetRef.current?.close();
    };

    const fadeInOverlay = () => {
        Animated.timing(overlayOpacity, {
            toValue: 1,
            duration: 300,
            useNativeDriver: true,
        }).start();
    };

    const fadeOutOverlay = () => {
        Animated.timing(overlayOpacity, {
            toValue: 0,
            duration: 300,
            useNativeDriver: true,
        }).start();
    };

    const handleMediaSelection = () => {
        const options = {
            mediaType: "mixed",
            selectionLimit: 4,
        };

        launchImageLibrary({mediaType: "photo", quality: 0.3}, (response) => {
            if (response.didCancel) {
                console.log("User cancelled media selection");
            } else if (response.errorMessage) {
                console.error("Error selecting media:", response.errorMessage);
            } else if (response.assets) {
                setSelectedMedia([...selectedMedia, ...response.assets]);
                handleSendNote();
            }
        });
    };

    React.useEffect(() => {
        const fetchProfilePictures = async () => {
            const storage = getStorage();
            const pictures = {};

            for (const employee of project.assigned_employees) {
                try {
                    const profileImageRef = ref(storage, `/profileImages/${employee}`);
                    const profileImageUrl = await getDownloadURL(profileImageRef);
                    pictures[employee] = profileImageUrl;
                } catch {
                    pictures[employee] = "https://via.placeholder.com/50";
                }
            }
            setProfilePictures(pictures);
        };
        fetchProfilePictures();
    }, [project.assigned_employees]);

    React.useEffect(() => {
        const fetchCoordinates = async () => {
            if (project.location) {
                try {
                    const response = await fetch(
                        `https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(
                            project.location
                        )}&key=${googleApi}`
                    );
                    const data = await response.json();
                    if (data.results && data.results[0]) {
                        const {lat, lng} = data.results[0].geometry.location;
                        setCoordinates({latitude: lat, longitude: lng});
                    }
                } catch (error) {
                    console.error("Error fetching coordinates:", error);
                }
            }
        };
        fetchCoordinates();
    }, [project.location]);

    React.useEffect(() => {
        const getLocation = async () => {
            let {status} = await Location.requestForegroundPermissionsAsync();
            if (status === "granted") {
                let location = await Location.getCurrentPositionAsync({});
                setUserLocation(location.coords);
            }
        };
        getLocation();
    }, []);

    const handleMapPress = () => {
        if (userLocation && coordinates) {
            const url =
                Platform.OS === "ios"
                    ? `https://maps.apple.com/?daddr=${coordinates.latitude},${coordinates.longitude}&dirflg=d&t=m`
                    : `https://www.google.com/maps/dir/?api=1&origin=${userLocation.latitude},${userLocation.longitude}&destination=${coordinates.latitude},${coordinates.longitude}`;
            Linking.openURL(url);
        }
    };

    React.useEffect(() => {
        const db = getDatabase();
        const notesRef = ref(
            db,
            `Businesses/${businessId}/projects/${project.title}/projectSettings/notes`
        );

        const unsubscribe = onValue(notesRef, (snapshot) => {
            const data = snapshot.val();
            if (data) {
                const formattedNotes = Object.values(data).sort(
                    (a, b) => a.timestamp - b.timestamp
                );
                setNotes(formattedNotes);
            } else {
                setNotes([]);
            }
        });

        return () => unsubscribe();
    }, [businessId, project.title]);

    React.useEffect(() => {
        const fetchProjectSettings = async () => {
            try {
                const db = getFirestore();
                const taskId= project?.taskId;
                const taskList= project?.projectTasks;

                const attachedData={
                    ...taskList[taskId],
                    name:taskList[taskId]?.taskName,
                    taskName:taskList[taskId].taskName,
                    id: taskId,
                }

                setAttachedTasklist(attachedData);


               /* if (taskId) {
                    const businessDoc = await getDoc(
                        doc(firestore, "Businesses", businessId)
                    );
                    const businessRoles = businessDoc.data().roles;
                    setRoles(businessRoles);

                    const taskListDocSnap = businessDoc.data().tasks[taskId];

                    if (taskListDocSnap) {
                        const attachedData={
                            id: taskId,
                            name:taskListDocSnap?.taskName,
                            taskItems:taskListDocSnap.taskItems,
                            taskName:taskListDocSnap?.taskName,
                            taskListSettings:taskListDocSnap?.taskListSettings
                        }
                        setAttachedTasklist(attachedData);
                    } else {
                        console.log("projectSettings document does not exist");
                    }
                } else {
                    console.log("No task list found for this project");
                }*/
            } catch (error) {
                console.log(error);
            }
        };

        fetchProjectSettings();
    }, [businessId, project.title]);

    const handleSendNote = async () => {
        if (!noteInput.trim() && selectedMedia.length === 0) return;

        try {
            const db = getDatabase();
            const storage = getStorage();
            const notesRef = ref(
                db,
                `Businesses/${businessId}/projects/${project.title}/projectSettings/notes`
            );

            const uploadedMediaUrls = [];
            for (const media of selectedMedia) {
                const fileName = `${Date.now()}_${media.fileName}`;
                const storageRef = sRef(storage, `notes/${fileName}`);
                const response = await fetch(media.uri);
                const blob = await response.blob();
                await uploadBytes(storageRef, blob);
                const downloadUrl = await getDownloadURL(storageRef);
                uploadedMediaUrls.push(downloadUrl);
            }

            const noteData = {
                publisher: fullName,
                note: noteInput,
                media: uploadedMediaUrls,
                timestamp: new Date().toISOString(),
            };

            await push(notesRef, noteData);
            setNoteInput("");
            setSelectedMedia([]);
        } catch (error) {
            console.error("Error sending note:", error);
        }
    };

    const updateProjectStatusToClosed = async (signature) => {
        try {
            const projectRef = doc(firestore, "Businesses", businessId);
            const projectTitleRef = project.title;
            const storage = getStorage();

            let signaturePath = null;
            if (signature) {
                const reference = sRef(storage, `projects/${businessId}/${projectTitleRef}/signature.png`);
                const response = await fetch(signature);
                if (!response.ok) {
                    throw new Error("Failed to fetch signature image");
                }
                const blob = await response.blob();
                await uploadBytes(reference, blob);
                signaturePath = await getDownloadURL(reference);

            }

            await updateDoc(projectRef, {
                project: {
                    [projectTitleRef]: {
                        projectSettings: {
                            ...project,
                            status: "Completed",
                            signature: signaturePath,
                        },
                    },
                },
            });

            Alert.alert(
                "Project Completed",
                "This project has been successfully completed and its status is now set to Closed.",
                [{text: "OK", onPress: () => navigation.goBack()}],
                {cancelable: false}
            );
            console.log("Project status updated to Closed");
        } catch (error) {
            console.error("Error updating project status:", error);
            Alert.alert(
                "Error",
                "There was an issue updating the project status. Please try again."
            );
        }
    };

        const handleDeleteProject = async () => {
            Alert.alert(
                "Delete Project",
                "Are you sure you want to delete this project? This action cannot be undone.",
                [
                    {
                        text: "Cancel",
                        style: "cancel",
                    },
                    {
                        text: "Delete",
                        style: "destructive",
                        onPress: async () => {
                            try {
                                const projectDocRef = doc(firestore, "Businesses", businessId);
                                await updateDoc(projectDocRef, {
                                    [`project.${project.title}`]: deleteField(),
                                });
                                navigation.goBack();
                                console.log("Project deleted successfully.");
                            } catch (error) {
                                console.error("Error deleting project: ", error);
                            }
                        },
                    },
                ]
            );
        };

    const generateProjectPDF = async () => {
        try {
            const htmlContent = `
      <html>
        <head>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.5; margin: 0; padding: 0; }
            .container { padding: 20px; }
            .header { text-align: center; margin-bottom: 20px; }
            .header img { max-width: 200px; }
            .section { margin-bottom: 20px; border-bottom: 1px solid #ddd; padding-bottom: 15px; }
            .section-title { font-size: 20px; font-weight: bold; color: #333; margin-bottom: 10px; }
            .info { margin-bottom: 10px; }
            .label { font-weight: bold; color: #555; }
            .value { color: #222; }
            .notes-section .note { margin-bottom: 15px; }
            .note .publisher { font-weight: bold; color: #555; }
            .note .timestamp { font-size: 12px; color: #888; }
            .note .media img, .note .media video { width: 100%; max-height: 200px; margin-top: 5px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <img src="https://i.ibb.co/y4d8Vrg/IMG-7005.png" alt="Logo">
            </div>
            ${
                attachedTasklist
                    ? `<div class="section">
                     <div class="section-title">Attached Tasklist</div>
                     <div class="info">
                       <span class="label">Tasklist:</span> <span class="value">${attachedTasklist}</span>
                     </div>
                   </div>`
                    : ""
            }
            <div class="section">
              <div class="section-title">Project Details</div>
              <div class="info">
                <span class="label">Status:</span> <span class="value">${project.status}</span>
              </div>
              <div class="info">
                <span class="label">Priority:</span> <span class="value">${project.priority}</span>
              </div>
              <div class="info">
                <span class="label">Estimated Time:</span> <span class="value">${project.estimated_time}</span>
              </div>
              <div class="info">
                <span class="label">Tools:</span> <span class="value">${project.tools || "None"}</span>
              </div>
              <div class="info">
                <span class="label">Location:</span> <span class="value">${
                coordinates
                    ? `Lat: ${coordinates.latitude}, Lng: ${coordinates.longitude}`
                    : "Not specified"
            }</span>
              </div>
              <div class="info">
                <span class="label">Completion Date:</span> <span class="value">${new Date(
                project.dateTime.seconds * 1000
            ).toLocaleString()}</span>
              </div>
            </div>
            <div class="section notes-section">
              <div class="section-title">Notes</div>
              ${
                notes.length === 0
                    ? `<div class="info">No notes have been added to this project yet.</div>`
                    : notes
                        .map(
                            (note) => `
                          <div class="note">
                            <div>
                              <span class="publisher">${note.publisher}:</span> ${note.note}
                            </div>
                            <div class="timestamp">${new Date(
                                note.timestamp
                            ).toLocaleDateString()}</div>
                            ${
                                note.media
                                    ? `<div class="media">
                                    ${note.media
                                        .map((url) =>
                                            url.endsWith(".mp4")
                                                ? `<video src="${url}" controls></video>`
                                                : `<img src="${url}" />`
                                        )
                                        .join("")}
                                   </div>`
                                    : ""
                            }
                          </div>
                        `
                        )
                        .join("")
            }
            </div>
          </div>
        </body>
      </html>
    `;

            const options = {
                html: htmlContent,
                fileName: `Project_${project.name || "details"}`,
                directory: "Documents",
            };

            const pdf = await RNHTMLtoPDF.convert(options);
            if (Platform.OS === "ios") {
                Share.share({url: pdf.filePath});
            }
            console.log("PDF generated at:", pdf.filePath);
            return pdf.filePath;
        } catch (error) {
            console.error("Error generating PDF:", error);
            return null;
        }
    }

    return (
        <View style={styles.container}>
            <KeyboardAvoidingView
                style={{flex: 1}}
                behavior={Platform.OS === "ios" ? "padding" : "height"}
            >
                <View style={{flex: 1}}>
                    {/* Animated overlay for fade effect */}
                    {isBottomSheetOpen && (
                        <Animated.View
                            style={[styles.overlay, {opacity: overlayOpacity}]}
                        />
                    )}

                    <TouchableOpacity
                        style={styles.backButton}
                        onPress={() => navigation.goBack()}
                    >
                        <Ionicons name="arrow-back" size={24} color="#333"/>
                    </TouchableOpacity>
                    <TouchableOpacity
                        style={styles.moreButton}
                        onPress={() => bottomSheetRef.current?.expand()}
                    >
                        <Feather name="more-vertical" size={24} color="#333"/>
                    </TouchableOpacity>
                    <Image
                        source={require("../../assets/images/taskorbit.png")}
                        style={styles.appIcon}
                    />
                    <ScrollView
                        style={styles.container}
                        showsVerticalScrollIndicator={false}
                        showsHorizontalScrollIndicator={false}
                    >
                        <Text style={styles.title}>{project.title}</Text>
                        <Text style={styles.description}>{project.description}</Text>
                        {project.status === "Completed" ? (
                            <>
                                {project.customerDetails?.name && project.customerDetails.phone && (
                                    <View style={styles.infoContainer}>
                                        <Text style={styles.infoLabel}>Customer's name:</Text>
                                        <View style={styles.inputWithIcon}>
                                            <TextInput
                                                style={[
                                                    styles.input,
                                                    {height: 30, textAlignVertical: "top"},
                                                ]}
                                                value={project.customerDetails.name || "Invalid Name"}
                                                editable={false}
                                                multiline={true}
                                            />
                                            <Feather name="user" size={20} color="#002c48"/>
                                        </View>
                                    </View>
                                )}

                                <View style={styles.infoContainer}>
                                    <Text style={styles.infoLabel}>Location:</Text>
                                    {coordinates ? (
                                        <TouchableOpacity onPress={handleMapPress} activeOpacity={1}>
                                            <MapView
                                                style={styles.map}
                                                zoomEnabled={false}
                                                scrollEnabled={false}
                                                rotateEnabled={false}
                                                initialRegion={{
                                                    ...coordinates,
                                                    latitudeDelta: 0.01,
                                                    longitudeDelta: 0.01,
                                                }}
                                            >
                                                <Marker coordinate={coordinates} title="Project location"/>
                                            </MapView>
                                        </TouchableOpacity>
                                    ) : (
                                        <View style={styles.inputWithIcon}>
                                            <TextInput
                                                style={styles.input}
                                                value={project.location || "Not specified"}
                                                editable={false}
                                            />
                                            <Feather name="map-pin" size={20} color="#002c48"/>
                                        </View>
                                    )}
                                </View>

                                <View style={styles.infoContainer}>
                                    <Text style={styles.infoLabel}>Status:</Text>
                                    <View style={styles.inputWithIcon}>
                                        <TextInput
                                            style={styles.input}
                                            value={project.status}
                                            editable={false}
                                        />
                                        <Feather
                                            name={project.status == "Closed" ? "check-circle" : "circle"}
                                            size={20}
                                            color="#002c48"
                                        />
                                    </View>
                                </View>

                                <View style={styles.infoContainer}>
                                    <Text style={styles.infoLabel}>Signature:</Text>
                                    <View style={styles.inputWithIcon}>
                                        <Image
                                            source={{uri: project.signature}}
                                            style={styles.signatureMedia}
                                            resizeMode="cover"
                                        />
                                    </View>
                                </View>

                                <View style={styles.notesSection}>
                                    <Text style={styles.infoLabel}>Notes</Text>

                                    <View style={styles.notesContainer}>
                                        {notes.length === 0 ? (
                                            <Text style={styles.noNotesMessage}>No notes were added to this project
                                                throughout its duration. This may indicate that all essential
                                                information and updates were either documented elsewhere or not deemed
                                                necessary.</Text>
                                        ) : (
                                            <ScrollView contentContainerStyle={styles.scrollViewContent}>
                                                {notes.map((note, index) => (
                                                    <View key={index} style={styles.noteContainer}>
                                                        {/* Note details */}
                                                        <View style={styles.noteItemContainer}>
                                                            <Text style={styles.noteItem}>
                                                                <Text style={styles.publisher}>{note.publisher}</Text>
                                                                : {note.note}
                                                            </Text>
                                                            <Text style={styles.timestamp}>
                                                                {new Date(note.timestamp).toLocaleDateString("en-US", {
                                                                    month: "2-digit",
                                                                    day: "2-digit",
                                                                    year: "2-digit",
                                                                })}
                                                            </Text>
                                                        </View>

                                                        {/* Media content */}
                                                        {note.media && (
                                                            <View style={styles.mediaRowContainer}>
                                                                {note.media.map((mediaUrl, mediaIndex) => (
                                                                    <TouchableOpacity
                                                                        key={mediaIndex}
                                                                        style={styles.mediaWrapper}
                                                                        onPress={() => openImagePopup(mediaUrl)}
                                                                    >
                                                                        {mediaUrl.endsWith(".mp4") ? (
                                                                            <Video
                                                                                source={{uri: mediaUrl}}
                                                                                style={styles.media}
                                                                                controls
                                                                                resizeMode="contain"
                                                                            />
                                                                        ) : (
                                                                            <Image
                                                                                source={{uri: mediaUrl}}
                                                                                style={styles.media}
                                                                                resizeMode="cover"
                                                                            />
                                                                        )}
                                                                    </TouchableOpacity>
                                                                ))}
                                                            </View>
                                                        )}
                                                    </View>
                                                ))}
                                            </ScrollView>
                                        )}
                                    </View>
                                </View>
                            </>
                        ) : (
                            <>
                                {attachedTasklist == null ? null : (
                                    <View style={styles.infoContainer}>
                                        <Text style={styles.infoLabel}>Attached tasklist:</Text>
                                        <TouchableOpacity
                                            style={styles.buttonWithIcon}
                                            onPress={() =>{
                                                navigation.navigate("(app)/taskListScreen", {
                                                    task: attachedTasklist,
                                                    businessId: businessId,
                                                    taskListName: attachedTasklist?.taskName,
                                                    roles: roles,
                                                    username: fullName,
                                                    project
                                                })
                                            }

                                            }
                                        >
                                            <Text style={styles.buttonAttachedText}>View Tasklist</Text>
                                            <Ionicons
                                                name="arrow-forward"
                                                size={20}
                                                color="black"
                                                style={styles.icon}
                                            />
                                        </TouchableOpacity>
                                    </View>
                                )}

                                <View style={styles.infoContainer}>
                                    <Text style={styles.infoLabel}>Status:</Text>
                                    <View style={styles.inputWithIcon}>
                                        <TextInput
                                            style={styles.input}
                                            value={project.status}
                                            editable={false}
                                        />
                                        <Feather
                                            name={project.status == "Closed" ? "check-circle" : "circle"}
                                            size={20}
                                            color="#002c48"
                                        />
                                    </View>
                                </View>

                                <View style={styles.infoContainer}>
                                    <Text style={styles.infoLabel}>Priority:</Text>
                                    <View style={styles.inputWithIcon}>
                                        <TextInput
                                            style={styles.input}
                                            value={project.priority}
                                            editable={false}
                                        />
                                        <Feather name="alert-circle" size={20} color="#002c48"/>
                                    </View>
                                </View>

                                <View style={styles.infoContainer}>
                                    <Text style={styles.infoLabel}>Estimated Time:</Text>
                                    <View style={styles.inputWithIcon}>
                                        <TextInput
                                            style={styles.input}
                                            value={project.estimated_time}
                                            editable={false}
                                        />
                                        <Feather name="clock" size={20} color="#002c48"/>
                                    </View>
                                </View>

                                <View style={styles.infoContainer}>
                                    <Text style={styles.infoLabel}>Tools:</Text>
                                    <View style={styles.inputWithIcon}>
                                        <TextInput
                                            style={[
                                                styles.input,
                                                {height: 80, textAlignVertical: "top"},
                                            ]}
                                            value={project.tools || "None"}
                                            editable={false}
                                            multiline={true}
                                        />
                                        <Feather name="tool" size={20} color="#002c48"/>
                                    </View>
                                </View>

                                <View style={styles.infoContainer}>
                                    <Text style={styles.infoLabel}>Location:</Text>
                                    {coordinates ? (
                                        <TouchableOpacity onPress={handleMapPress} activeOpacity={1}>
                                            <MapView
                                                style={styles.map}
                                                zoomEnabled={false}
                                                scrollEnabled={false}
                                                rotateEnabled={false}
                                                initialRegion={{
                                                    ...coordinates,
                                                    latitudeDelta: 0.01,
                                                    longitudeDelta: 0.01,
                                                }}
                                            >
                                                <Marker coordinate={coordinates} title="Project location"/>
                                            </MapView>
                                        </TouchableOpacity>
                                    ) : (
                                        <View style={styles.inputWithIcon}>
                                            <TextInput
                                                style={styles.input}
                                                value={project.location || "Not specified"}
                                                editable={false}
                                            />
                                            <Feather name="map-pin" size={20} color="#002c48"/>
                                        </View>
                                    )}
                                </View>

                                <View style={styles.infoContainer}>
                                    <Text style={styles.infoLabel}>Completion date:</Text>
                                    <View style={styles.inputWithIcon}>
                                        <TextInput
                                            style={styles.input}
                                            value={new Date(
                                                project.dateTime.seconds * 1000
                                            ).toLocaleString()}
                                            editable={false}
                                        />
                                        <Feather name="calendar" size={20} color="#002c48"/>
                                    </View>
                                </View>

                                <View style={styles.notesSection}>
                                    <Text style={styles.infoLabel}>Notes</Text>

                                    <View style={styles.notesContainer}>
                                        {notes.length === 0 ? (
                                            <Text style={styles.noNotesMessage}>No notes have been added to this project
                                                yet.</Text>
                                        ) : (
                                            <ScrollView contentContainerStyle={styles.scrollViewContent}>
                                                {notes.map((note, index) => (
                                                    <View key={index} style={styles.noteContainer}>
                                                        {/* Note details */}
                                                        <View style={styles.noteItemContainer}>
                                                            <Text style={styles.noteItem}>
                                                                <Text style={styles.publisher}>{note.publisher}</Text>
                                                                : {note.note}
                                                            </Text>
                                                            <Text style={styles.timestamp}>
                                                                {new Date(note.timestamp).toLocaleDateString(
                                                                    "en-US",
                                                                    {
                                                                        month: "2-digit",
                                                                        day: "2-digit",
                                                                        year: "2-digit",
                                                                    }
                                                                )}
                                                            </Text>
                                                        </View>

                                                        {/* Media content */}
                                                        {note.media && (
                                                            <View style={styles.mediaRowContainer}>
                                                                {note.media.map((mediaUrl, mediaIndex) => (
                                                                    <TouchableOpacity
                                                                        key={mediaIndex}
                                                                        style={styles.mediaWrapper}
                                                                        onPress={() => openImagePopup(mediaUrl)}
                                                                    >
                                                                        {mediaUrl.endsWith(".mp4") ? (
                                                                            <Video
                                                                                source={{uri: mediaUrl}}
                                                                                style={styles.media}
                                                                                controls
                                                                                resizeMode="contain"
                                                                            />
                                                                        ) : (
                                                                            <Image
                                                                                source={{uri: mediaUrl}}
                                                                                style={styles.media}
                                                                                resizeMode="cover"
                                                                            />
                                                                        )}
                                                                    </TouchableOpacity>
                                                                ))}
                                                            </View>
                                                        )}
                                                    </View>
                                                ))}
                                            </ScrollView>
                                        )}
                                    </View>

                                    <View style={styles.inputWithIcon}>
                                        <TextInput
                                            style={[styles.input, {flex: 1, height: 40}]}
                                            placeholder="Add a note"
                                            placeholderTextColor={"#ccc"}
                                            value={noteInput}
                                            onChangeText={setNoteInput}
                                        />
                                        <TouchableOpacity onPress={handleMediaSelection}>
                                            <Feather name="file" size={20} color="#2196f3"/>
                                        </TouchableOpacity>
                                        <TouchableOpacity onPress={handleSendNote}>
                                            <Feather name="send" size={20} color="#2196f3"/>
                                        </TouchableOpacity>
                                    </View>

                                    <TouchableOpacity
                                        style={[styles.bottomSheetCompleteButton,{backgroundColor: isDisabled?'grey':'#32CD32'}]}
                                        onPress={() => setShowModal(true)}
                                        disabled={isDisabled}
                                    >
                                        <Text style={styles.bottomSheetConfirmButtonText}>
                                            Submit project
                                        </Text>
                                        <Icon
                                            name="check"
                                            size={20}
                                            color="white"
                                            style={styles.checkmarkIcon}
                                        />
                                    </TouchableOpacity>
                                </View>
                            </>
                        )}
                    </ScrollView>
                </View>


                <BottomSheet
                    ref={bottomSheetRef}
                    onChange={handleSheetChange}
                    index={-1}
                    //zIndex={10}
                    //snapPoints={["35%"]}
                    enablePanDownToClose={true}
                >
                    <BottomSheetView style={styles.bottomSheetContent}>
                        <Text
                            style={styles.popupLabel}
                            numberOfLines={1}
                            ellipsizeMode="clip"
                        >
                            {project.title}
                        </Text>
                        {project?.customerDetails?.name && project.customerDetails.phone ? (
                            <TouchableOpacity
                                style={styles.bottomSheetButton}
                                onPress={togglePopup}
                            >
                                <Text style={styles.bottomSheetButtonText}>
                                    Contact Customer
                                </Text>
                            </TouchableOpacity>
                        ) : null}
                        <TouchableOpacity style={styles.bottomSheetButton}>
                            <Text style={styles.bottomSheetButtonText}>
                                Submit incomplete project
                            </Text>
                        </TouchableOpacity>
                        <TouchableOpacity
                            style={styles.bottomSheetPDFButton}
                            onPress={generateProjectPDF}
                        >
                            <Text style={styles.bottomSheetConfirmButtonText}>
                                Export as PDF
                            </Text>
                            <Icon
                                name="file-pdf-o"
                                size={20}
                                color="white"
                                style={styles.checkmarkIcon}
                            />
                        </TouchableOpacity>
                        <TouchableOpacity
                            style={styles.bottomSheetDeleteButton}
                            onPress={handleDeleteProject}
                        >
                            <Text style={styles.bottomSheetConfirmButtonText}>
                                Delete Project
                            </Text>
                            <Icon
                                name="remove"
                                size={20}
                                color="white"
                                style={styles.checkmarkIcon}
                            />
                        </TouchableOpacity>
                    </BottomSheetView>
                </BottomSheet>
            </KeyboardAvoidingView>
            {isPopupVisible && (
                <View style={styles.popupContainer}>
                    <View style={styles.popupContent}>
                        <Text style={styles.contactCustomerText}>Contact Customer</Text>
                        <TextInput
                            style={styles.popupInput}
                            value={project.customerDetails?.name || "No Name"}
                            editable={false}
                            placeholder="Customer Name"
                        />
                        <TextInput
                            style={styles.popupInput}
                            value={project.customerDetails?.phone || "No Phone"}
                            editable={false}
                            placeholder="Customer Phone"
                        />
                        <View style={styles.popupButtonContainer}>
                            <TouchableOpacity
                                style={styles.closeButton}
                                onPress={togglePopup}
                            >
                                <Text style={styles.buttonText}>Close</Text>
                            </TouchableOpacity>
                            <TouchableOpacity
                                style={styles.callButton}
                                onPress={() =>
                                    Linking.openURL(`tel:${project.customerDetails?.phone}`)
                                }
                            >
                                <Text style={styles.buttonText}>Call Customer</Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                </View>
            )}


            <Modal
                visible={isImagePopupVisible}
                transparent={true}
                animationType="fade"
                onRequestClose={closeImagePopup}
            >
                <View style={styles.modalOverlay}>
                    <ReactNativeZoomableView
                        maxZoom={3}
                        minZoom={0.5}
                        zoomStep={0.5}
                        initialZoom={1}
                        bindToBorders={true}
                        onZoomAfter={this.logOutZoomState}
                        style={{
                            height: 150,
                            width: 500,
                        }}
                    >
                        <Image
                            source={{uri: currentImage}}
                            style={styles.fullscreenImage}
                        />
                    </ReactNativeZoomableView>
                    <TouchableOpacity
                        style={styles.closeButton}
                        onPress={closeImagePopup}
                    >
                        <Ionicons name="close" size={24} color="white"/>
                    </TouchableOpacity>
                </View>
            </Modal>

            <Modal visible={showModal} transparent={true}>
                <View style={styles.modalContainer}>
                    <View style={styles.modalContent}>
                        <Text>Sign to complete the project:</Text>
                        {/*<SignatureModal
                            onOK={(signature) => handleSignature(signature)}
                            onClose={() => setShowModal(false)}
                            clearText={"Cancel"}
                            confirmText={"Save Changes"}
                        />*/}
                        <SignatureScreen
                            style={{borderWidth: 1, borderColor: '#ccc'}}
              onOK={(signature) => {
                handleSignature(signature)
              }}
              onEmpty={() => console.log("No signature")}
              onClear={() => {
                setShowModal(false)
                //setSignature("")
              }}
              descriptionText=""
              clearText="Cancel"
              confirmText="Save Changes"
              autoClear={false}
          />
                         {/*<SignatureView
            onOK={(signature)=>handleSignature(signature)}
           // style={{borderWidth: 1, borderColor: '#ccc'}}
            ref={signatureRef}
            descriptionText="Sign Here"
            clearText="Clear"
            confirmText="Confirm"
           // webStyle={`.m-signature-pad--footer { display: none;}`}
          />*/}
                      {/*  <View style={styles.modalButtons}>
                <TouchableOpacity onPress={handleCloseModal} style={styles.closeModalButton}>
                  <Text style={styles.closeButtonText}>Cancel</Text>
                </TouchableOpacity>
                <TouchableOpacity onPress={updateProjectStatusToClosed} style={styles.confirmModalButton}>
                  <Text style={styles.closeButtonText}>Save Changes</Text>
                </TouchableOpacity>
      </View>*/}
                    </View>
                </View>
            </Modal>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 16,
        backgroundColor: "#fff",
    },
    appIcon: {
        width: 100,
        height: 100,
        alignSelf: "center",
        marginBottom: 0,
    },
    title: {
        fontSize: 24,
        fontWeight: "bold",
        marginBottom: 5,
        textAlign: "left",
    },
    description: {
        fontSize: 16,
        color: "#6b6b6b",
        marginBottom: 16,
    },
    input: {
        flex: 1,
        fontSize: 16,
        borderWidth: 1,
        borderColor: "transparent",
        borderRadius: 10,
        paddingVertical: 5,
        backgroundColor: "transparent",
        color: "#002c48",
    },
    inputWithIcon: {
        flexDirection: "row",
        alignItems: "center",
        borderWidth: 1,
        borderColor: "#002c48",
        borderRadius: 10,
        paddingHorizontal: 10,
        backgroundColor: "transparent",
    },
    infoContainer: {
        marginBottom: 16,
    },
    infoLabel: {
        fontSize: 16,
        fontWeight: "600",
        marginBottom: 4,
    },
    popupLabel: {
        alignSelf: "center",
        fontSize: 24,
        fontWeight: "600",
        marginBottom: 20,
    },
    map: {
        width: "100%",
        height: 200,
        marginTop: 0,
        borderRadius: 10,
    },
    backButton: {
        position: "absolute",
        top: 25,
        left: 25,
        zIndex: 1,
    },
    overlay: {
        position: "absolute",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: "rgba(0, 0, 0, 0.5)",
        zIndex: 1,
    },
    moreButton: {
        position: "absolute",
        top: 25,
        right: 25,
        zIndex: 1,
    },
    bottomSheetContent: {
        borderRadius: 50,
        flex: 1,
        paddingHorizontal: 16,
        paddingVertical: 5,
    },
    bottomSheetButton: {
        padding: 12,
        backgroundColor: "#f0f0f0",
        borderRadius: 8,
        marginBottom: 8,
    },
    bottomSheetCompleteButton: {
        marginTop: 10,
        padding: 12,
        backgroundColor: "#32CD32",
        borderRadius: 8,
        marginBottom: 8,
        flexDirection: "row",
        justifyContent: "center",
        alignItems: "center",
    },
    bottomSheetConfirmButtonText: {
        fontSize: 16,
        color: "white",
        fontWeight: "600",
        textAlign: "center",
    },
    checkmarkIcon: {
        marginLeft: 10,
    },
    bottomSheetButtonText: {
        fontSize: 16,
        fontWeight: "600",
        textAlign: "center",
    },
    contactCustomerText: {
        fontSize: 20,
        fontWeight: "bold",
        textAlign: "center",
        marginBottom: 10,
    },
    notesSection: {
        marginTop: 20,
        marginBottom: 30,
    },
    notesList: {
        marginTop: 10,
    },
    noteItem: {
        fontSize: 16,
        color: "#333",
        marginBottom: 5,
    },
    notesContainer: {
        marginVertical: 10,
        padding: 10,
        borderRadius: 10,
        backgroundColor: "transparent",
        maxHeight: 200,
        borderWidth: 1,
        borderColor: "black",
    },
    scrollViewContent: {
        flexGrow: 1,
    },
    noteItemContainer: {
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        marginBottom: 8,
    },
    noteItem: {
        fontSize: 14,
        color: "#333",
        flex: 1,
    },
    publisher: {
        color: "#2196f3",
        fontWeight: "bold",
    },
    timestamp: {
        fontSize: 12,
        color: "#888",
        textAlign: "right",
        marginLeft: 8,
    },
    buttonWithIcon: {
        flexDirection: "row",
        justifyContent: "space-between",
        backgroundColor: "transparent",
        padding: 8,
        borderRadius: 10,
        borderWidth: 1,
        borderColor: "black",
        alignSelf: "flex-start",
        width: "100%",
    },
    buttonAttachedText: {
        color: "black",
        fontSize: 16,
    },
    icon: {
        marginLeft: 10,
    },
    popupContainer: {
        position: "absolute",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: "rgba(0, 0, 0, 0.5)",
        justifyContent: "center",
        alignItems: "center",
    },
    popupContent: {
        backgroundColor: "white",
        padding: 20,
        borderRadius: 10,
        width: "80%",
        alignItems: "center",
    },
    popupInput: {
        width: "100%",
        padding: 10,
        marginBottom: 20,
        backgroundColor: "white",
        borderRadius: 5,
        borderWidth: 1,
        borderColor: "#ccc",
        textAlign: "center",
    },
    popupButtonContainer: {
        flexDirection: "row",
        justifyContent: "space-between",
        width: "100%",
    },
    closeButton: {
        backgroundColor: "#f44336",
        padding: 10,
        borderRadius: 5,
        flex: 1,
        marginRight: 10,
        alignItems: "center",
    },
    callButton: {
        backgroundColor: "#7ACF7A",
        padding: 10,
        borderRadius: 5,
        flex: 1,
        alignItems: "center",
    },
    bottomSheetPDFButton: {
        padding: 12,
        backgroundColor: "#2196f3",
        borderRadius: 8,
        marginBottom: 8,
        flexDirection: "row",
        justifyContent: "center",
        alignItems: "center",
    },
    bottomSheetDeleteButton: {
        padding: 12,
        backgroundColor: "#f32121",
        borderRadius: 8,
        marginBottom: 8,
        flexDirection: "row",
        justifyContent: "center",
        alignItems: "center",
    },
    buttonText: {
        color: "white",
        fontSize: 16,
    },
    mediaRowContainer: {
        marginBottom: 10,
        flexDirection: "row",
        flexWrap: "wrap",
        gap: 8,
    },
    mediaWrapper: {
        width: "48%",
        aspectRatio: 1,
        borderRadius: 8,
        overflow: "hidden",
        borderWidth: 1,
        borderColor: "#ccc",
    },
    mediaButton: {
        backgroundColor: "#2196f3",
        padding: 10,
        borderRadius: 5,
        alignItems: "center",
        marginVertical: 10,
    },
    mediaButtonText: {
        color: "#fff",
        fontSize: 16,
    },
    media: {
        width: "100%",
        height: "100%",
        borderRadius: 10,
    },
    mediaContainer: {
        marginVertical: 5,
    },
    signatureMedia: {
        width: '100%',
        paddingVertical: '50%',
        borderRadius: 10,
    },
    modalOverlay: {
        flex: 1,
        height: "100%",
        width: "100%",
        backgroundColor: "rgba(0, 0, 0, 0.9)",
        justifyContent: "center",
        alignItems: "center",
    },
    fullscreenImage: {
        width: "100%",
        height: "100%",
        resizeMode: "contain",
    },
    closeButton: {
        position: "absolute",
        top: 40,
        right: 20,
        padding: 10,
        backgroundColor: "rgba(0, 0, 0, 0.6)",
        borderRadius: 50,
    },
    thumbnailImage: {
        width: 100,
        height: 100,
        resizeMode: "cover",
        margin: 5,
        borderRadius: 10,
    },
    modalContainer: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
        backgroundColor: "rgba(0, 0, 0, 0.5)",
    },
    modalContent: {
        width: "80%",
        backgroundColor: "white",
        height: '50%',
        padding: 20,
        borderRadius: 10,
        alignItems: "center",
    },
    closeButton: {
        marginTop: 20,
        backgroundColor: "#2196f3",
        padding: 10,
        borderRadius: 5,
    },
    submitButton: {
        marginTop: 10,
        backgroundColor: "#2196f3",
        padding: 10,
        borderRadius: 5,
    },
    modalButtons: {
        marginTop: 10,
        flexDirection: 'row',
        justifyContent: 'space-between',
    },
    closeModalButton: {
        backgroundColor: 'white',
        borderWidth: 1,
        borderColor: '#dcdcdc',
        borderRadius: 10,
        padding: 10,
        alignItems: 'center',
        flex: 1,
        marginRight: 10,

    },
    confirmModalButton: {
        backgroundColor: 'white',
        borderWidth: 1,
        borderColor: '#dcdcdc',
        borderRadius: 10,
        padding: 10,
        alignItems: 'center',
        flex: 1,
    },
});

export default ProjectDetails;
