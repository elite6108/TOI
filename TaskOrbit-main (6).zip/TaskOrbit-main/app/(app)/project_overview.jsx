import React, {useEffect, useState} from "react";
import {
    View,
    Text,
    FlatList,
    StyleSheet,
    TouchableOpacity,
    Image,
    ActivityIndicator
} from "react-native";
import {doc, getDoc} from "firebase/firestore";
import {auth, firestore} from "../(api)/firebase";
import {useNavigation} from "@react-navigation/native";
import {Dropdown} from "react-native-element-dropdown";
import {getStorage, ref, getDownloadURL} from "firebase/storage";

const ProjectPage = () => {
    const [projects, setProjects] = useState([]);
    const [filteredProjects, setFilteredProjects] = useState([]);
    const [isViewingProjects, setIsViewingTasks] = useState(2);
    const [userRole, setUserRole] = useState(null);
    const [userSecondRole, setUserSecondRole] = useState([]);
    const [businessId, setBusinessId] = useState(null);
    const [loading, setLoading] = useState(true);
    const [value, setValue] = useState("week");
    const [fullName, setFullName] = useState("");
    const navigation = useNavigation();
    const userId = auth.currentUser?.uid;

    useEffect(() => {
        const fetchUserData = async () => {
            try {
                const userDoc = await getDoc(doc(firestore, "Users", userId));
                if (userDoc.exists()) {
                    const userData = userDoc.data();
                    setUserRole(userData.role);
                    setFullName(userData.fullName)
                    setUserSecondRole(userData.assignedRoles || []);
                    setBusinessId(userData.businessId);
                } else {
                    console.log("No such user document!");
                }
            } catch (error) {
                console.error("Error fetching user data: ", error);
            }
        };

        fetchUserData();
    }, [userId]);

    useEffect(() => {
        const fetchProjects = async () => {
            if (!businessId) return;

            try {
                const businessDoc = await getDoc(doc(firestore, "Businesses", businessId));
                if (businessDoc.exists()) {
                    const businessProjects = businessDoc.data().project;
                    const userProjects = [];
                    const employeeProfilePictures = {};
                    const storage = getStorage();

                    for (const projectName in businessProjects) {
                        const project = businessProjects[projectName];
                        const assignedEmployees = project.projectSettings.assigned_employees;

                        for (const employee of assignedEmployees) {
                            try {
                                const profileImageRef = ref(storage, `/profileImages/${employee}`);
                                const profileImageUrl = await getDownloadURL(profileImageRef);
                                //console.log(profileImageUrl)
                                employeeProfilePictures[employee] = profileImageUrl;
                            } catch (error) {
                                employeeProfilePictures[employee] = null;
                                //console.error(error)
                            }
                        }

                        if (assignedEmployees.includes(userId)) {
                            userProjects.push({
                                name: projectName,
                                profilePictures: employeeProfilePictures,
                                ...project,
                            });
                        }
                    }

                    userProjects.sort(
                        (a, b) =>
                            new Date(
                                a.projectSettings.dateTime.seconds * 1000
                            ).toLocaleString() -
                            new Date(b.projectSettings.dateTime.seconds * 1000
                            ).toLocaleString()
                    );
                    setProjects(userProjects);
                    setFilteredProjects(userProjects);
                } else {
                    console.log("No projects found for this business!");
                }
            } catch (error) {
                console.error("Error fetching projects: ", error);
            } finally {
                setLoading(false);
            }
        };

        fetchProjects();
    }, [businessId, userRole, userSecondRole]);

    useEffect(() => {
        const filterProjects = () => {
            if (isViewingProjects === 0) {
                const now = new Date();
                const dueSoonProjects = projects.filter((project) => {
                    const dueDate = new Date(
                        project.projectSettings.dateTime.seconds * 1000
                    ).toLocaleString();
                    const differenceInDays = (dueDate - now) / (1000 * 60 * 60 * 24);
                    return differenceInDays <= 2 && differenceInDays >= 0;
                });
                setFilteredProjects(dueSoonProjects);
            } else if (isViewingProjects === 1) {
                const completedProjects = projects.filter(
                    (project) => project.projectSettings.status === "Completed"
                );
                setFilteredProjects(completedProjects);
            } else {
                setFilteredProjects(projects);
            }
        };

        filterProjects();
    }, [isViewingProjects, projects]);

    useEffect(() => {
        const filterProjectsByTime = () => {
            let filtered = [...projects];

            if (value === "today") {
                const today = new Date();
                filtered = filtered.filter((project) => {
                    const dueDate = new Date(
                        project.projectSettings.dateTime.seconds * 1000
                    ).toLocaleString();
                    return dueDate.toString() === today.toDateString();
                });
            } else if (value === "week") {
                const startOfWeek = new Date();
                startOfWeek.setDate(startOfWeek.getDate() - startOfWeek.getDay());
                const endOfWeek = new Date();
                endOfWeek.setDate(endOfWeek.getDate() + (6 - endOfWeek.getDay()));

                filtered = filtered.filter((project) => {
                    const dueDate = new Date(
                        project.projectSettings.dateTime.seconds * 1000
                    ).toLocaleString();
                    return dueDate >= startOfWeek && dueDate <= endOfWeek;
                });
            }

            setFilteredProjects(filtered);
        };

        filterProjectsByTime();
    }, [value, projects]);

    if (loading) {
        return (
            <View style={styles.loadingContainer}>
                <ActivityIndicator size="large" color="#2196f3"/>
            </View>
        );
    }

    return (
        <View style={styles.container}>
            <View style={styles.filterContainer}>
                <Text style={styles.filterLabel}>Projects</Text>
                <Dropdown
                    style={styles.dropdown}
                    data={[
                        {label: "Today", value: "today"},
                        {label: "This week", value: "week"},
                        {label: "This month", value: "month"},
                        {label: "This year", value: "year"},
                        {label: "Lifetime", value: "lifetime"},
                    ]}
                    labelField="label"
                    valueField="value"
                    placeholder="Select"
                    value={value}
                    onChange={(item) => setValue(item.value)}
                />
            </View>
            <View style={styles.switchContainer}>
                <TouchableOpacity
                    onPress={() => setIsViewingTasks(0)}
                    style={[
                        styles.switchOption,
                        isViewingProjects === 0 && styles.activeOption,
                    ]}
                >
                    <Text
                        style={styles.switchText}
                        numberOfLines={1}
                        adjustsFontSizeToFit
                    >
                        Due Soon
                    </Text>
                </TouchableOpacity>
                <TouchableOpacity
                    onPress={() => setIsViewingTasks(1)}
                    style={[
                        styles.switchOption,
                        isViewingProjects === 1 && styles.activeOption,
                    ]}
                >
                    <Text
                        style={styles.switchText}
                        numberOfLines={1}
                        adjustsFontSizeToFit
                    >
                        Completed
                    </Text>
                </TouchableOpacity>
                <TouchableOpacity
                    onPress={() => setIsViewingTasks(2)}
                    style={[
                        styles.switchOption,
                        isViewingProjects === 2 && styles.activeOption,
                    ]}
                >
                    <Text
                        style={styles.switchText}
                        numberOfLines={1}
                        adjustsFontSizeToFit
                    >
                        All
                    </Text>
                </TouchableOpacity>
            </View>
            {filteredProjects.length === 0 ? (
                <Text style={styles.noTasksText}>No Projects available.</Text>
            ) : (
                <FlatList
                    data={filteredProjects}
                    keyExtractor={(item) => item.name}
                    renderItem={({item}) => {
                        const now = new Date();
                        const dueDate = new Date(
                            item.projectSettings.dateTime.seconds * 1000
                        ).toLocaleString();
                        const differenceInDays = (dueDate - now) / (1000 * 60 * 60 * 24);

                        let borderColor = "#b3e0e8";
                        let statusText = "Future Project";
                        if (item.projectSettings.status === "Completed") {
                            borderColor = "lightgreen";
                            statusText = "Completed";
                        } else if (differenceInDays <= 2 && differenceInDays >= 0) {
                            borderColor = "#ffeb99";
                            statusText = "Due Soon";
                        }

                        return (
                            <TouchableOpacity
                                onPress={() =>
                                    navigation.navigate("(app)/project_details", {
                                        project: item.projectSettings,
                                        businessId: businessId,
                                        fullName: fullName,
                                    })
                                }
                                style={[styles.projectItem, {borderLeftColor: borderColor}]}
                            >
                                <Text style={styles.projectTitle}>{item.name}</Text>
                                <Text style={styles.reportDetails}>{item.projectSettings.description}</Text>
                                <Text style={styles.projectDate}>
                                    Complete by: {dueDate.toLocaleString()}
                                </Text>
                                <View
                                    style={[styles.statusBadge, {backgroundColor: borderColor}]}
                                >
                                    <Text style={styles.statusText}>{statusText}</Text>
                                </View>

                                <View style={styles.profileImagesContainer}>
                                    {item.profilePictures && Object.values(item.profilePictures).length > 0 ? (
                                        Object.values(item.profilePictures)
                                            .slice(0, 4)
                                            .map((profileImage, imageIndex) => (
                                                <Image
                                                    key={imageIndex}
                                                    source={
                                                        profileImage
                                                            ? {uri: profileImage}
                                                            : require("../../assets/images/taskorbit.png")
                                                    }
                                                    style={styles.profileImage}
                                                />
                                            ))
                                    ) : (
                                        <Image
                                            source={require("../../assets/images/taskorbit.png")}
                                            style={styles.profileImage}
                                        />
                                    )}
                                </View>
                            </TouchableOpacity>
                        );
                    }}
                />
            )}
        </View>
    );
};

export default ProjectPage;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 20,
        backgroundColor: "white",
    },
    header: {
        fontSize: 24,
        fontWeight: "bold",
        marginBottom: 20,
    },
    loadingContainer: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
    },
    filterContainer: {
        flexDirection: "row",
        marginBottom: 15,
        alignItems: "center",
        justifyContent: "space-between",
    },
    reportDetails: {
        fontSize: 16,
        color: "#adacb2",
        marginBottom: 5,
    },
    filterLabel: {
        fontSize: 24,
        fontWeight: "bold",
        marginRight: 10,
    },
    dropdown: {
        width: 120,
        backgroundColor: "transparent",
        borderWidth: 1,
        borderColor: "grey",
        borderRadius: 10,
        padding: 7,
    },
    noTasksText: {
        textAlign: "center",
        marginTop: 20,
        fontSize: 16,
        color: "#666",
    },
    projectItem: {
        backgroundColor: "#f9f9f9",
        padding: 15,
        borderRadius: 8,
        marginBottom: 15,
        elevation: 3,
        borderTopWidth: 1,
        borderRightWidth: 1,
        borderBottomWidth: 1,
        borderColor: "#ccc",
        borderLeftWidth: 5,
        borderLeftColor: "#b3e0e8",
    },
    projectTitle: {
        fontSize: 18,
        marginBottom: 5,
        fontWeight: "bold",
    },
    projectDescription: {
        marginTop: 5,
        fontSize: 14,
        color: "#555",
    },
    projectDate: {
        marginTop: 10,
        fontSize: 12,
        color: "#999",
    },
    switchContainer: {
        backgroundColor: "#eee",
        flexDirection: "row",
        justifyContent: "space-around",
        marginBottom: 10,
        borderRadius: 10,
    },
    switchOption: {
        borderRadius: 10,
        flex: 1,
        paddingVertical: 10,
        paddingHorizontal: 10,
        marginVertical: 5,
        marginHorizontal: 5,
        shadowOpacity: 0.2,
        shadowRadius: 2,
        shadowOffset: 10,
    },
    activeOption: {
        backgroundColor: "#fff",
    },
    switchText: {
        alignSelf:"center",
        color: "black",
        fontSize: 16,
    },
    statusBadge: {
        position: "absolute",
        top: 10,
        right: 10,
        borderRadius: 15,
        paddingVertical: 5,
        paddingHorizontal: 10,
        alignItems: "center",
        justifyContent: "center",
    },
    statusText: {
        fontSize: 12,
        color: "#333",
        fontWeight: "bold",
    },
    profileImagesContainer: {
        flexDirection: "row",
        alignItems: "center",
        marginTop: 10,
    },
    profileImage: {
        borderWidth: 1.5,
        borderColor: "#f9f9f9",
        width: 40,
        height: 40,
        borderRadius: 20,
        backgroundColor: "#eee",
        marginRight: -10,
    },
    moreText: {
        fontSize: 16,
        color: "#7E818E",
        marginLeft: 10,
    },
});
