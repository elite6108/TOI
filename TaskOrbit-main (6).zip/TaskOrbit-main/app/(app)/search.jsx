import React, {useEffect, useState} from 'react';
import {FlatList, StyleSheet, TextInput, View} from 'react-native';
import {doc, getDoc} from 'firebase/firestore';
import {auth, firestore} from '../(api)/firebase';
import Icon from 'react-native-vector-icons/MaterialIcons';
import {useFocusEffect} from "@react-navigation/native";
import TaskItem from "../components/TaskItem";

export default function SearchPage({ navigation }) {
  const [searchQuery, setSearchQuery] = useState('');
  const [taskLists, setTaskLists] = useState([]);
  const [filteredTaskLists, setFilteredTaskLists] = useState([]);
  const [businessId, setBusinessId] = useState('');
  const [Roles, setRoles] = useState("");
  const [fullName, setFullName] = useState("loading...");
  const userId = auth.currentUser.uid;

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    const year = date.getFullYear();
    return `${month}-${day}-${year}`;
  };

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const userDoc = await getDoc(doc(firestore, 'Users', userId));
        if (userDoc.exists()) {
          setBusinessId(userDoc.data().businessId);
          const userData = userDoc.data();
          setFullName(userData.fullName);
        }
      } catch (error) {
        console.error('Error fetching user data: ', error);
      }
    };

    fetchUserData();
  }, [userId]);

  const fetchTaskLists = async () => {
    try {
      if (businessId) {
        const businessDoc = await getDoc(doc(firestore, 'Businesses', businessId));
        if (businessDoc.exists()) {
          const tasks = businessDoc.data().tasks;
          const businessRoles = businessDoc.data().roles;
          setRoles(businessRoles);
          const taskListArray = Object.keys(tasks).map(taskListName => {
            const taskItems = tasks[taskListName].taskItems || [];
            const completedCount = taskItems.filter(task => task.status === 'Completed').length;


            let status = calculateStatus(tasks[taskListName]);
            if (completedCount === taskItems.length && completedCount > 0) {
              //status = 'Completed';
            }

            return {
              id:taskListName,
              name: tasks[taskListName]?.taskName,
              ...tasks[taskListName],
              status,
              completedCount,
            };
          });

          taskListArray.sort((a, b) => new Date(a.taskListSettings.dateTime) - new Date(b.taskListSettings.dateTime));

          setTaskLists(taskListArray);
        }
      }
    } catch (error) {
      console.error('Error fetching tasks: ', error);
    }
  };

  useFocusEffect(
      React.useCallback(() => {
        fetchTaskLists()
      }, [businessId])
  );


  useEffect(() => {
    if (searchQuery === '') {
      setFilteredTaskLists(taskLists);
    } else {
      setFilteredTaskLists(
        taskLists.filter(taskList =>
          taskList.name.toLowerCase().includes(searchQuery.toLowerCase())
        )
      );
    }
  }, [searchQuery, taskLists]);

  const calculateStatus = (taskList) => {
    const { taskListSettings, taskItems } = taskList;
    const dueDate = new Date(taskList.taskListSettings.dateTime);
    const now = new Date();
    const daysDiff = Math.floor((dueDate - now) / (1000 * 60 * 60 * 24));
    const hasOpenTasks = taskItems?.some((task) => task.status === "Open");

    if (hasOpenTasks) {
      if (daysDiff < 0) {
        return 'Overdue';
      } else if (daysDiff <= 2) {
        return 'Due soon';
      } else if (daysDiff > 2 && daysDiff <= 7) {
        return 'Upcoming';
      } else {
        return 'Future task';
      }
    }
    return taskListSettings?.taskListStatus?taskListSettings?.taskListStatus:"Open"
  };

  const getStatusBackgroundColor = (status) => {
    switch (status) {
      case 'Overdue':
        return '#ffcccc';
      case 'Due soon':
        return '#ffeb99';
      case 'Upcoming':
        return '#b3e0e8';
      case 'Future task':
        return 'lightgreen';
      case 'Completed':
        return '#d4edda';
      default:
        return '#b3e0e8';
    }
  };

  const getStatusBorderColor = (status) => {
    switch (status) {
      case 'Overdue':
        return '#ff6666';
      case 'Due soon':
        return '#ffd966';
      case 'Upcoming':
        return '#66d9ff';
      case 'Future task':
        return '#66ff66';
      case 'Completed':
        return '#c3e6cb';
      default:
        return '#b3e0e8';
    }
  };

  return (
    <View style={styles.safeArea}>
      <View style={styles.container}>
        <View style={styles.searchContainer}>
          <TextInput
            style={styles.searchInput}
            placeholder="Search tasklists..."
            placeholderTextColor="#888"
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
          <Icon name="search" size={20} color="#888" style={styles.searchIcon} />
        </View>

        <FlatList
            data={filteredTaskLists}
            showsVerticalScrollIndicator={false}
            renderItem={({item,index})=>{
          return  (
              <TaskItem
                  key={index.toString()}
                  index={index}
                  navigation={navigation}
                  businessId={businessId}
                  roles={Roles}
                  fullName={fullName}
                  task={item}
              />
          )
        }} />


      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#fff',
  },
  container: {
    flex: 1,
    padding: 20,
  },
  searchContainer: {
    position: 'relative',
  },
  searchInput: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    padding: 10,
    paddingRight: 40,
    marginBottom: 16,
    fontSize: 16,
  },
  searchIcon: {
    position: 'absolute',
    right: 10,
    top: 12,
  },
  scrollView: {
    flex: 1,
  },
  taskListItem: {
    backgroundColor: '#f9f9f9',
    padding: 15,
    marginBottom: 10,
    borderRadius: 10,
    borderWidth: 1,
    borderLeftWidth: 6,
    borderColor: '#ccc',
  },
  taskListHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  taskListTitle: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  taskListDetails: {
    marginTop: 8,
    color: '#ccc',
  },
  statusContainer: {
    borderRadius: 20,
    paddingHorizontal: 10,
    paddingVertical: 4,
  },
  statusText: {
    color: 'black',
  },
});
