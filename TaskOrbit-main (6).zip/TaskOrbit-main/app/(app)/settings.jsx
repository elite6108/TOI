import React, { useEffect, useState } from 'react';
import { View, StyleSheet, Text, TouchableOpacity, StatusBar, TextInput, ScrollView, SafeAreaView, Image, Platform} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import { useFocusEffect } from '@react-navigation/native';
import { auth, firestore } from '../(api)/firebase';
import { signOut } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import AsyncStorage from '@react-native-async-storage/async-storage';
import PermissionChecker from '../(api)/perm_check'

const Settings = ({ navigation }) => {
  const [fullName, setFullName] = useState('loading...');
  const [profileImage, setProfileImage] = useState(null);
  const [businessId, setBusinessId] = useState('');
  const [hasSuperAdmin, setHasSuperAdmin] = useState(false);
  const permissionEditRolesId = "edit_roles";
  const hasRolesPermission = PermissionChecker({ permissionId: permissionEditRolesId });
  const userId = auth.currentUser.uid;
  const permissionEditEmployeesId = "edit_employee";
  const hasManageEmployeesPermission = PermissionChecker({
    permissionId: permissionEditEmployeesId,
  });

  const permissionAddEmployeesId = "add_employee";
  const hasAddEmployeesPermission = PermissionChecker({
    permissionId: permissionAddEmployeesId,
  });

    const fetchUserData = async () => {
      try {
        const userDoc = await getDoc(doc(firestore, 'Users', userId));
        if (userDoc.exists()) {
          setFullName(userDoc.data().fullName);
          setProfileImage(userDoc.data().profileImage || null);
          setBusinessId(userDoc.data().businessId || null)
          setHasSuperAdmin(userDoc.data().hasSuperAdmin || false)
        } else {
          console.log('No such document!');
        }
      } catch (error) {
        console.error('Error fetching user data: ', error);
      }
    };

  useFocusEffect(
    React.useCallback(() => {
      if (userId) {
        fetchUserData();
      }
    }, [userId])
  );

  const handleLogout = async () => {
    if (businessId == '') {
      Alert.alert('Try again later', 'We are still fetching your business info.');
    } else {
    try {
      await signOut(auth);
      console.log('User signed out successfully');
      await AsyncStorage.removeItem('userCredentials');
      console.log('User credentials removed from AsyncStorage');
      navigation.replace('(app)/employeeLogin', { QRCodeData: businessId });
    } catch (error) {
      console.error('Error signing out:', error);
    }
  }
  };

  const handleBusinessLogout = async () => {
    try {
      await signOut(auth);
      console.log('User signed out successfully');
      await AsyncStorage.removeItem('userCredentials');
      console.log('User credentials removed from AsyncStorage');
      navigation.replace('(auth)/login');
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  return (
    <View style={styles.safeArea}>

      {/* App Bar */}
      <View style={styles.appBar}>
        <Text style={styles.appBarText}>Settings</Text>
      </View>

      {/* User Info Section */}
      <View style={styles.userInfoContainer}>
      <Image
              source={profileImage ? { uri: profileImage.uri || profileImage } : require('../../assets/images/taskorbit.png')}
              style={styles.profileImage}
            />
        <Text style={styles.userName}>{fullName}</Text>
      </View>

      {/* Scrollable Buttons */}
      <ScrollView contentContainerStyle={[styles.scrollViewContent, Platform.OS === 'web' && { height: 10 }]} nestedScrollEnabled={true} scrollEnabled={true}>

        <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('(settings)/generalSettings')}>
          <Icon name="settings" size={20} color="#2196f3" style={styles.icon} />
          <Text style={styles.buttonText}>General</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('(app)/information_library')}>
          <Icon name="folder" size={20} color="#2196f3" style={styles.icon} />
          <Text style={styles.buttonText}>Information Library</Text>
        </TouchableOpacity>

        {/* <TouchableOpacity style={styles.button}>
          <Icon name="schedule" size={20} color="#2196f3" style={styles.icon} />
          <Text style={styles.buttonText}>Scheduling</Text>
        </TouchableOpacity> */}

        <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('(settings)/customers', {businessId: businessId})}>
          <FontAwesome name="users" size={20} color="#2196f3" style={styles.icon} />
          <Text style={styles.buttonText}>Customers</Text>
        </TouchableOpacity>

        {(hasSuperAdmin || hasRolesPermission) && (
  <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('(settings)/roles')}>
    <FontAwesome name="legal" size={20} color="#2196f3" style={styles.icon} />
    <Text style={styles.buttonText}>Roles</Text>
  </TouchableOpacity>
)}

       {(hasAddEmployeesPermission || hasManageEmployeesPermission) && (
        <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('(app)/create_user')}>
          <FontAwesome name="user" size={20} color="#2196f3" style={styles.icon} />
          <Text style={styles.buttonText}>Staff</Text>
        </TouchableOpacity>
       )}

        <TouchableOpacity style={styles.button}>
          <Icon name="location-on" size={20} color="#2196f3" style={styles.icon} />
          <Text style={styles.buttonText}>Location</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('(app)/deviceSharingQR')}>
          <Icon name="qr-code" size={20} color="#2196f3" style={styles.icon} />
          <Text style={styles.buttonText}>Device Sharing QR</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.button}>
          <Icon name="feedback" size={20} color="#2196f3" style={styles.icon} />
          <Text style={styles.buttonText}>Feedback</Text>
        </TouchableOpacity>

        {/* Logout Button */}
        <TouchableOpacity style={[styles.button, styles.logoutButton]} onPress={handleLogout}>
          <Icon name="switch-account" size={20} color="#2196f3" style={styles.icon} />
          <Text style={styles.buttonText}>Logout</Text>
        </TouchableOpacity>

        <TouchableOpacity style={[styles.button, styles.logoutButton]} onPress={handleBusinessLogout}>
          <Icon name="logout" size={20} color="#2196f3" style={styles.icon} />
          <Text style={styles.buttonText}>Logout of Business</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: 'white',
  },
  appBar: {
    backgroundColor: 'white',
    paddingVertical: 15,
    alignItems: 'flex-start',
    marginLeft: 30,
  },
  appBarText: {
    color: 'black',
    fontSize: 20,
    fontWeight: 'bold',
  },
  userInfoContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'white',
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 10,
    padding: 10,
    marginHorizontal: 20,
    marginBottom: 20,
  },
  profileImage: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginRight: 15,
  },
  userName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'black',
  },
  searchBar: {
    backgroundColor: 'white',
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 10,
    margin: 20,
    borderRadius: 10,
    fontSize: 16,
    color: 'black'
  },
  scrollViewContent: {
    flexGrow: 1,
    paddingHorizontal: 20,
    paddingBottom: 34,
  },
  button: {
    backgroundColor: 'white',
    borderRadius: 10,
    borderColor: '#ccc',
    borderWidth: 1,
    paddingVertical: 15,
    paddingHorizontal: 15,
    alignItems: 'center',
    flexDirection: 'row',
    marginBottom: 20,
  },
  buttonText: {
    color: 'black',
    fontSize: 16,
    marginLeft: 10,
  },
  icon: {
    marginRight: 10,
  },
  logoutButton: {
    backgroundColor: '#ffcccc',
  },
});

export default Settings;
