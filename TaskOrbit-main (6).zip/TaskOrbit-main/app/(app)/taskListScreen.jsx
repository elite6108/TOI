import React, {useEffect, useMemo, useRef, useState} from "react";
import {useNavigation} from "@react-navigation/native";
import {
    Alert,
    Animated,
    FlatList,
    Image,
    Modal,
    Platform,
    Share,
    StyleSheet,
    Text,
    TextInput,
    TouchableOpacity,
    View
} from "react-native";
import {MaterialCommunityIcons} from "@expo/vector-icons";
import DateTimePicker from "@react-native-community/datetimepicker";
import {deleteField, doc, setDoc, updateDoc} from "firebase/firestore";
import {firestore} from "../(api)/firebase";
import {getDownloadURL, getStorage, ref, uploadBytes} from "firebase/storage";
import RNHTMLtoPDF from "react-native-html-to-pdf";
import BottomSheet, {BottomSheetView} from "@gorhom/bottom-sheet";
import {CameraView} from 'expo-camera';
import Icon from "react-native-vector-icons/FontAwesome";
import RadioButton from "@/app/components/RadioButton";
import SignatureModal from "@/app/modal/SignatureModal";
import {convertStrToDate} from "@/constants/Utils";

let CheckBox;
if (Platform.OS === 'web') {
    CheckBox = require('react-native-web').CheckBox;
} else {
    CheckBox = require('@react-native-community/checkbox').default;
}

const TaskListScreen = ({route}) => {
    const {task, businessId, taskListName, roles, username,project} = route.params;

    const [taskDetails, setTaskDetails] = useState({});


    const navigation = useNavigation();
    const storage = getStorage();

    const [signature, setSignature] = useState("");
    const bottomSheetRef = useRef(null);
    const [signatures, setSignatures] = useState({});
    const [overlayOpacity] = useState(new Animated.Value(0));
    const signRef = useRef();
    const scanRef = useRef();
    const [isSignatureModalVisible, setSignatureModalVisible] = useState(false);
    const [date, setDate] = useState(new Date());
    const [showDatePicker, setShowDatePicker] = useState(false);
    const [checked, setChecked] = useState(false);
    const [yesChecked, setYesChecked] = useState(false);
    const [noChecked, setNoChecked] = useState(false);
    const [inputValues, setInputValues] = useState({});
    const [yesNoStates, setYesNoStates] = useState({});
    const [checkedStates, setCheckedStates] = useState({});
    const [isOptionsModalVisible, setOptionsModalVisible] = useState(false);
    const [selectedOption, setSelectedOption] = useState(null);
    const [qrCodeTasks, setQrCodeTasks] = useState([]);
    const [hasPermission, setHasPermission] = useState(null);
    const [scannedStates, setScannedStates] = useState(false);
    const [scannerModalVisible, setScannerModalVisible] = useState(false);
    const [modalTaskId, setModalTaskId] = useState('');

    const formatDate = (isoDateString) => {
        const date = new Date(isoDateString);
        const day = String(date.getDate()).padStart(2, "0");
        const month = String(date.getMonth() + 1).padStart(2, "0");
        const year = date.getFullYear();

        return `${month}-${day}-${year}`;
    };

    useEffect(() => {
        const qrCodeTasksList = task.taskItems.filter(item => item.type === "QR Code");
        setQrCodeTasks(qrCodeTasksList);
    }, [task.taskItems]);


    useEffect(() => {
        setTaskDetails(task)
    }, []);


    const handleOptionSelect = (option) => {
        setSelectedOption(option);
        setOptionsModalVisible(false);
        bottomSheetRef?.current?.close()
        navigation.navigate("(app)/update_task", {
            roles,
            businessId: businessId,
            username: username,
            task,
            isUpdate:true,
        });

    };

    useEffect(() => {
        const initializeTaskValues = () => {
            const initialInputValues = {};
            const initialYesNoStates = {};
            const initialCheckedStates = {};
            const initialScannedStates = {};
            const initialSignedStates = {};
            task.taskItems.forEach((taskItem) => {
                if (taskItem.type === "Short Entry") {
                    initialInputValues[taskItem.id] = taskItem.value || "";
                } else if (taskItem.type === "Checkmark") {
                    initialCheckedStates[taskItem.id] = taskItem.status === "Completed";
                } else if (taskItem.type === "QR Code") {
                    initialCheckedStates[taskItem.id] = taskItem.status === "Completed";
                } else if (taskItem.type === "Yes/No") {
                    initialYesNoStates[taskItem.id] = taskItem.value || "";
                } else if (taskItem.type === "Signature") {
                    initialSignedStates[taskItem.id] = taskItem.value || "";
                } else if (taskItem.type === "Date") {
                    if (taskItem.value) {
                        const dd = convertStrToDate(taskItem.value)
                        setDate(dd);
                    }
                }
            });

            setInputValues(initialInputValues);
            setYesNoStates(initialYesNoStates);
            setScannedStates(initialScannedStates);
            setCheckedStates(initialCheckedStates);
            setSignatures(initialSignedStates);
        };

        initializeTaskValues();
    }, [task?.taskItems]);


    const submitTaskUpdates = async () => {
        const updatedTasks = taskDetails?.taskItems?.map((taskItem) => {
            let status = "Open";
            let value = "";
            if (taskItem.type === "Short Entry" && inputValues[taskItem.id]) {
                status = "Completed";
                value = inputValues[taskItem.id];
            } else if (taskItem.type === "Checkmark" && checkedStates[taskItem.id]) {
                status = "Completed";
                value = "Task Done";
            } else if (taskItem.type === "QR Code" && scannedStates[taskItem.id]) {
                status = "Completed";
                value = "Task Done";
            } else if (taskItem.type === "Signature" && signatures[taskItem.id]) {
                status = "Completed";
                value = signatures[taskItem.id];
            } else if (taskItem.type === "Yes/No") {
                status = "Completed";
                value = yesNoStates[taskItem.id];
            } else if (taskItem.type === "Date" && date) {
                status = "Completed";
                value = formatDate(date.toISOString());
            } else if (taskItem.type === "Subtitle") {
                value = "Closed";
                status = "Closed"
            }

            return {...taskItem, status, value};
        });

        for (const taskItem of updatedTasks) {
            if (
                taskItem.type === "Signature" &&
                taskItem.value &&
                taskItem.value.startsWith("data:image")
            ) {
                try {
                    console.log("Captured Signature URI: ", taskItem.value);

                    const response = await fetch(taskItem.value);
                    const blob = await response.blob();

                    const fileRef = ref(
                        storage,
                        `signatures/${Date.now()}_${taskItem.id}.png`
                    );

                    await uploadBytes(fileRef, blob);

                    const downloadURL = await getDownloadURL(fileRef);

                    taskItem.value = downloadURL;
                    taskItem.status = "Completed";
                    console.log("Signature uploaded successfully and task updated.");
                } catch (error) {
                    console.error("Signature upload error: ", error);
                }
            }
        }

        const taskDocRef = doc(firestore, "Businesses", businessId);

        const taskModifiedData = {
            taskListSettings: {
                ...taskDetails.taskListSettings,
                taskListStatus: "Completed",
                taskListCompletedDate: new Date().toLocaleString("en-US", {
                    weekday: "short",
                    month: "short",
                    day: "numeric",
                    year: "numeric",
                    hour: "2-digit",
                    minute: "2-digit",
                    hour12: true,
                }),
            },
            taskItems: updatedTasks.map((item) => ({
                ...item,
                value: item.value,
            })),
        };


        if (project){
            const title= project?.title;
            const taskId= project?.taskId;

            const taskData= {
                [`${taskId}`]: taskModifiedData
            }
            const projectSettings= {
                ...project,
                projectTasks: taskData,
                taskListStatus: "Completed",
            }

            await updateDoc(taskDocRef, {
                [`project.${title}`]: {projectSettings},
            });
            setTaskDetails(taskModifiedData)
            navigation.navigate('BottomTabs')

        } else {
            const data = {
                tasks: {
                    [task?.id]: taskModifiedData,
                },
            }
            setTaskDetails(taskModifiedData)

            await setDoc(
                taskDocRef,
                data,
                {merge: true}
            );
            navigation.goBack();
        }

    };

    const isStatusCompleted = useMemo(() => {
        return taskDetails?.taskItems?.some((taskItem) => {
            return taskItem?.status?.toLowerCase() === 'open'
        });
    }, [taskDetails]);

    const updateTaskUpdates = async () => {
        const updatedTasks = taskDetails?.taskItems?.map((taskItem) => {
            let status = "Open";
            let value = "";
            if (taskItem.type === "Short Entry" && inputValues[taskItem.id]) {
                value = inputValues[taskItem.id];
                status = value === "" ? "Open" : "Completed";
            } else if (taskItem.type === "Checkmark" && checkedStates[taskItem.id]) {
                status = "Completed";
                value = "Task Done";
            } else if (taskItem.type === "QR Code" && scannedStates[taskItem.id]) {
                status = "Completed";
                value = "Task Done";
            } else if (taskItem.type === "Signature" && signatures[taskItem.id]) {
                status = signatures[taskItem.id]?.startsWith('http') ? "Completed" : "Open";
                value = signatures[taskItem.id];
            } else if (taskItem.type === "Yes/No") {
                status = yesNoStates[taskItem.id]?.length > 0 ? "Completed" : "Open";
                value = yesNoStates[taskItem.id];
            } else if (taskItem.type === "Date" && date) {
                status = "Completed";
                value = formatDate(date.toISOString());
            } else if (taskItem.type === "Subtitle") {
                value = "Closed";
                status = "Closed"
            }
            return {...taskItem, status, value};
        });

        for (const taskItem of updatedTasks) {
            if (
                taskItem.type === "Signature" &&
                taskItem.value &&
                taskItem.value.startsWith("data:image")
            ) {
                try {
                    const response = await fetch(taskItem.value);
                    const blob = await response.blob();

                    const fileRef = ref(
                        storage,
                        `signatures/${Date.now()}_${taskItem.id}.png`
                    );

                    await uploadBytes(fileRef, blob);

                    const downloadURL = await getDownloadURL(fileRef);
                    taskItem.value = downloadURL;
                    taskItem.status = "Completed";
                    console.log("Signature uploaded successfully and task updated.", downloadURL);
                } catch (error) {
                    console.error("Signature upload error: ", error);
                }
            }
        }
        const taskDocRef = doc(firestore, "Businesses", businessId);

        const taskModified = {
            taskListSettings: {
                ...task.taskListSettings,
            },
            taskItems: updatedTasks.map((item) => ({
                ...item,
                value: item.value,
            })),
        }
        if (project){
            const title= project?.title;
            const taskId= project?.taskId;

            const taskData= {
                [`${taskId}`]: taskModified
            }

            const projectSettings= {
                 ...project,
                projectTasks: taskData
            }

            await updateDoc(taskDocRef, {
                [`project.${title}`]: {projectSettings},
            });

            setTaskDetails(taskModified)

        } else{
            const data = {
                tasks: {
                    [task?.id]: taskModified,
                },
            }

            setTaskDetails(taskModified)
            await setDoc(
                taskDocRef,
                data,
                {merge: true}
            );
        }

    };

    const handleSheetChange = (index) => {
        if (index > 0) {
            fadeInOverlay();
        } else {
            fadeOutOverlay();
        }
    };

    const fadeInOverlay = () => {
        Animated.timing(overlayOpacity, {
            toValue: 1,
            duration: 0,
            useNativeDriver: true,
        }).start();
    };

    const fadeOutOverlay = () => {
        Animated.timing(overlayOpacity, {
            toValue: 0,
            duration: 0,

            useNativeDriver: true,
        }).start();
    };

    const handleExportAsPDF = async () => {
        try {
            const taskItemsHTML = task.taskItems
                .map(
                    (item) => `
          <tr>
            <td>${item.name}</td>
            <td>${item.type === "Subtitle" ? "Subtitle" : item.value || ""}</td>
            <td>${item.type === "Subtitle" ? null : item.status}</td>
          </tr>
        `
                )
                .join("");

            const formattedDeadline = task.taskListSettings.dateTime
                ? new Date(task.taskListSettings.dateTime).toLocaleString("en-US", {
                    weekday: "short",
                    month: "short",
                    day: "numeric",
                    year: "numeric",
                    hour: "2-digit",
                    minute: "2-digit",
                    hour12: true,
                })
                : "N/A";

            const htmlContent = `
        <html>
          <head>
            <style>
              table {
                width: 100%;
                border-collapse: collapse;
              }
              th, td {
                border: 1px solid black;
                padding: 8px;
                text-align: left;
              }
              th {
                background-color: #f2f2f2;
              }
              .header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 20px;
              }
              .header .details {
                text-align: left;
              }
              .header .logo {
                max-width: 100px;
              }
              .header img {
                max-width: 100%;
                height: auto;
              }
            </style>
          </head>
          <body>
            <div class="header">
              <div class="details">
                <h1>${taskListName}</h1>
                <p><strong>Deadline:</strong> ${formattedDeadline}</p>
                <p><strong>Completed:</strong> ${
                task.taskListSettings.taskListCompletedDate || "Not completed"
            }</p>
              </div>
              <div class="logo">
                <img src="https://i.ibb.co/y4d8Vrg/IMG-7005.png" alt="Logo">
              </div>
            </div>
            <table>
              <thead>
                <tr>
                  <th>Task</th>
                  <th>Value</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                ${taskItemsHTML}
              </tbody>
            </table>
          </body>
        </html>
      `;

            const options = {
                html: htmlContent,
                fileName: `TaskList_${taskListName}`,
                directory: "Documents",
            };

            const file = await RNHTMLtoPDF.convert(options);

            if (Platform.OS === "ios") {
                Share.share({url: file.filePath});
            } else {
                console.log("PDF saved to:", file.filePath);
                alert(`PDF saved to: ${file.filePath}`);
            }
        } catch (error) {
            console.error("Error generating PDF:", error);
            alert("Failed to export as PDF. Please try again.");
        }
    };

    const handleExportQRCodesAsPDF = async () => {
        try {
            // Generate HTML content for the PDF
            const qrCodeHTML = task.taskItems
                .filter((item) => item.type === "QR Code")
                .map(
                    (item) => `
            <div class="container">
              <h3>QR Code: '${item.name}'</h3>
              <p>Scan the QR code below to confirm your task.</p>
              <img 
                src="https://api.qrserver.com/v1/create-qr-code/?data=${item.id}&size=150x150" 
                alt="QR Code" 
                class="qr-code" 
              />
            </div>
          `
                )
                .join("");

            const htmlContent = `
        <html>
          <head>
            <style>
              body {
                font-family: 'Arial', sans-serif;
                margin: 0;
                padding: 0;
                background-color: #f7f8fa;
              }
              .container {
                text-align: center;
                padding: 20px;
                background-color: #ffffff;
                box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
                border-radius: 10px;
                max-width: 600px;
                margin: auto;
              }
              .logo {
                width: 150px;
                height: 150px;
                margin-bottom: 20px;
              }
              .qr-code {
                width: 150px;
                height: 150px;
                margin-top: 20px; /* Adjust the margin-top to create space between the text and QR code */
              }
              h3 {
                font-size: 20px;
                color: #333;
              }
              p {
                font-size: 14px;
                color: #6c757d;
              }
              .footer {
                margin-top: 30px;
                font-size: 12px;
                color: #6c757d;
                text-align: center;
              }
              .footer a {
                color: #2196f3;
                text-decoration: none;
              }
            </style>
          </head>
          <body>
            <div class="container">
              <img src="https://i.ibb.co/y4d8Vrg/IMG-7005.png" alt="TaskOrbit Logo" class="logo" />
              <h1>QR Codes</h1>
              <div class="qr-code-container">
                ${qrCodeHTML}
              </div>
              <div class="footer">
                <p>&copy; ${new Date().getFullYear()} TaskOrbit. All rights reserved.</p>
                <p>Visit us at <a href="https://www.taskorbit.com" target="_blank">www.taskorbit.com</a></p>
              </div>
            </div>
          </body>
        </html>
      `;

            // Generate the PDF
            const options = {
                html: htmlContent,
                fileName: 'Tasklist_QR_Codes',
                directory: 'Documents',
            };

            const file = await RNHTMLtoPDF.convert(options);

            // Notify the user
            if (Platform.OS === "ios") {
                Share.share({url: file.filePath});
            }
        } catch (error) {
            console.error('Error generating PDF:', error);
            alert('Failed to export QR Codes as PDF.');
        }
    };

    const handleDeleteTasklist = async () => {
        Alert.alert(
            "Delete Tasklist",
            "Are you sure you want to delete this tasklist? This action cannot be undone.",
            [
                {
                    text: "Cancel",
                    style: "cancel",
                },
                {
                    text: "Delete",
                    style: "destructive",
                    onPress: async () => {
                        try {
                            const taskDocRef = doc(firestore, "Businesses", businessId);
                            await updateDoc(taskDocRef, {
                                [`tasks.${task?.id}`]: deleteField(),
                            });
                            navigation.goBack();
                            console.log("Tasklist deleted successfully.");
                        } catch (error) {
                            console.error("Error deleting tasklist: ", error);
                        }
                    },
                },
            ]
        );
    };

    const handleEnd = async () => {
        await signRef.current.readSignature();
        handleOK();
    };

    const handleOK = (signature) => {
        console.log(signature);
    };
    const [isChanged, setIsChanged] = useState(false);

    useEffect(() => {
        if (isChanged) {
            updateTaskUpdates()
        }
    }, [isChanged, inputValues, checkedStates, scannedStates, yesNoStates, signatures, date])



    const renderTaskItem = ({item}) => {
        return (
            <>
                <View
                    style={{
                        height: 1,
                        backgroundColor: "rgba(192, 192, 192, 0.4)",
                        marginVertical: 10,
                    }}
                />
                <View
                    style={
                        item.type === "Subtitle"
                            ? {paddingHorizontal: 10, paddingVertical: 0, paddingTop: 0}
                            : styles.taskItem
                    }
                >
                    <Text
                        style={
                            item.type === "Subtitle"
                                ? {
                                    fontSize: 18,
                                    fontWeight: "bold",
                                    color: "#2196f3",
                                    textAlignVertical: "center",
                                }
                                : styles.taskName
                        }
                    >
                        {item.name}
                    </Text>

                    {item.type === "Short Entry" && (
                        <TextInput
                            style={styles.input}
                            placeholder="Enter short text"
                            placeholderTextColor="#666"
                            value={inputValues[item.id] || ""}
                            onChangeText={(text) => {
                                setInputValues((prev) => ({...prev, [item.id]: text}))
                                setIsChanged(true)
                            }
                            }
                            editable={task.taskListSettings?.taskListStatus !== "Completed"}
                        />
                    )}

                    {item.type === "Checkmark" && (
                        <View style={styles.checkboxContainer}>
                            <CheckBox
                                value={checkedStates[item.id] || false}
                                onValueChange={(newValue) => {
                                    setCheckedStates((prev) => ({...prev, [item.id]: newValue}))
                                    setIsChanged(true)
                                }
                                }
                                //onCheckColor={'#AA90E7'}
                                boxType="square"
                                style={styles.checkbox}
                                disabled={task.taskListSettings?.taskListStatus === "Completed"}
                            />
                            <Text>Confirm task</Text>
                        </View>
                    )}

                    {item.type === "QR Code" && (
                        <><TouchableOpacity
                            style={styles.signButton}
                            onPress={() => {
                                if (item.status === 'Open') {
                                    setScannerModalVisible(true)
                                    setModalTaskId(item.id)
                                }
                            }}
                        >
                            <Text
                                style={styles.signButtonText}>{item.status === 'Open' ? 'Scan QR Code' : 'Scan Completed'}</Text>
                        </TouchableOpacity>
                            <Modal visible={scannerModalVisible} animationType='none'>
                                <View style={{flex: 1, alignSelf: "center"}}>
                                    <View style={{padding: 25}}>
                                        <Image
                                            source={require("../../assets/images/taskorbit.png")}
                                            style={styles.logo}
                                            resizeMode="contain"/>

                                        {/* Title Text */}
                                        <Text style={styles.title}>Scan QR code to finish task</Text>
                                    </View>
                                    <View style={styles.scannerContainer}>
                                        <CameraView
                                            mode='picture'
                                            ref={scanRef}
                                            onBarcodeScanned={(result) => {
                                                if (result.data === item.id) {
                                                    setScannedStates((prev) => ({...prev, [modalTaskId]: true}))
                                                    setScannerModalVisible(false)
                                                    setIsChanged(true)
                                                    console.log('Task Completed Successfully')
                                                } else {
                                                    console.log('this is not the right task')
                                                }
                                            }}
                                            barCodeScannerSettings={{
                                                barCodeTypes: ["qr", 'aztec', 'ean13', 'ean8', 'qr', 'pdf417', 'upc_e', 'datamatrix', 'code39', 'code93', 'itf14', 'codabar', 'code128', 'upc_a'],
                                            }}
                                            style={{flex: 1, width: '100%', height: '100%'}}/>
                                        <Text style={styles.hintText}>
                                            Hold the camera steady to scan the code
                                        </Text>
                                    </View>
                                </View>
                                <View style={styles.modalButtonRow}>
                                    <TouchableOpacity
                                        style={styles.cancelButton}
                                        onPress={() => setScannerModalVisible(false)}
                                    >
                                        <Text style={styles.cancelButtonText}>Cancel</Text>
                                    </TouchableOpacity>
                                </View>
                            </Modal>
                        </>
                    )}

                    {item.type === "Signature" && (
                        <TouchableOpacity
                            disabled={task.taskListSettings?.taskListStatus === "Completed"}
                            onPress={() => {
                                setSignatureModalVisible(true)
                                setModalTaskId(item.id);
                            }}
                        >
                            <View style={styles.signatureContainer}>
                                {signatures[item.id] ? (
                                    <Image
                                        source={{uri: signatures[item.id]}}
                                        style={styles.signatureImage}
                                    />
                                ) : (
                                    <Text style={styles.signaturePlaceholder}>Tap to sign</Text>
                                )}
                            </View>
                        </TouchableOpacity>
                    )}

                    <Modal visible={isSignatureModalVisible} animationType="slide">
                        <View style={[styles.modalContainer]}>
                            <SignatureModal
                                isClose={true}
                                descriptionText={'Sign Here'}
                                onOK={(signature) => {
                                    setSignatures((prev) => ({...prev, [modalTaskId]: signature}));
                                    setSignatureModalVisible(false);
                                    setIsChanged(true)
                                }} onClose={() => setSignatureModalVisible(false)}/>
                        </View>
                    </Modal>

                    {item.type === "Yes/No" && (
                        <View style={styles.yesNoContainer}>
                            <RadioButton
                                isDisabled={task.taskListSettings?.taskListStatus === "Completed"}
                                value={yesNoStates[item.id]}
                                onChange={(text) => {
                                    setYesNoStates((prev) => ({
                                        ...prev,
                                        [item.id]: text,
                                    }));
                                    setIsChanged(true)

                                }}/>

                        </View>
                    )}

                    {item.type === "Date" && (
                        <View>
                            <TouchableOpacity
                                onPress={() => {
                                    setShowDatePicker(!showDatePicker);
                                    setModalTaskId(item.id);
                                }}
                                style={styles.datePickerButton}
                                disabled={task.taskListSettings?.taskListStatus === "Completed"}
                            >
                                <Text style={styles.datePickerText}>
                                    Select Date: {formatDate(date.toISOString())}
                                </Text>
                            </TouchableOpacity>
                            {showDatePicker && (
                                <DateTimePicker
                                    display="calendar"
                                    value={date}
                                    mode="datetime"
                                    onChange={(event, selectedDate) => {
                                        setShowDatePicker(false);
                                        if (event.type !== 'dismissed') {
                                            const currentDate = selectedDate || date;
                                            setDate(currentDate);
                                            setIsChanged(true)
                                        }
                                    }}
                                />
                            )}
                        </View>
                    )}
                </View>
            </>
        );
    };

    return (
        <View style={styles.safeContainer}>
            <View style={{flex: 1}}>
                {/* Animated overlay for fade effect */}

                <Animated.View
                    style={[
                        styles.overlay,
                        {opacity: overlayOpacity, zIndex: overlayOpacity},
                    ]}
                />

                <View style={styles.header}>
                    <TouchableOpacity onPress={() => navigation.goBack()}>
                        <MaterialCommunityIcons name="arrow-left" size={24} color="black"/>
                    </TouchableOpacity>
                    <Text style={styles.headerTitle}>Task</Text>
                </View>

                <View style={styles.header2}>
                    <Image
                        source={require("../../assets/images/taskorbit.png")}
                        style={styles.logo}
                        resizeMode="contain"
                    />
                </View>

                <View style={styles.taskInfo}>
                    <Text style={styles.taskTitle}>{task.name}</Text>
                    <Text
                        style={
                            task.taskListSettings?.taskListStatus === "Completed"
                                ? styles.completedText
                                : styles.dueDate
                        }
                    >
                        {task.taskListSettings?.taskListStatus === "Completed"
                            ? "Status: Completed"
                            : `Complete by: ${formatDate(task.taskListSettings.dateTime)}`}
                    </Text>
                    <TouchableOpacity
                        onPress={() => bottomSheetRef.current?.expand()}
                        style={styles.iconContainer}
                    >
                        <MaterialCommunityIcons
                            name="dots-vertical"
                            size={24}
                            color="black"
                        />
                    </TouchableOpacity>
                </View>

                <FlatList
                    data={task.taskItems}
                    keyExtractor={(item, index) => index.toString()}
                    renderItem={renderTaskItem}
                />

                {/* Buttons at the bottom, no absolute positioning */}
                <View style={styles.footer}>
                    {task.taskListSettings?.taskListStatus !== "Completed" && (
                        <TouchableOpacity
                            style={[styles.submitButton, isStatusCompleted && styles.disabledBtn]}
                            onPress={submitTaskUpdates}
                            disabled={isStatusCompleted}
                        >
                            <Text style={styles.submitButtonText}>Submit</Text>
                        </TouchableOpacity>
                    )}
                </View>
            </View>

            <BottomSheet
                ref={bottomSheetRef}
                onChange={handleSheetChange}
                index={-1}
                //zIndex={10}
                //snapPoints={["20%"]}
                enablePanDownToClose={true}
                backgroundStyle={{
                        backgroundColor: 'white', // Solid background
                        borderTopLeftRadius: 20,
                        borderTopRightRadius: 20,
                    }}
                //style={{borderWidth: 1, borderColor: 'grey', margin: 10, borderRadius: 5}}
            >
                <BottomSheetView style={styles.bottomSheetContent}>
                    <Text
                        style={styles.popupLabel}
                        numberOfLines={1}
                        ellipsizeMode="clip"
                    >
                        {taskListName}
                    </Text>
                    {task.taskListSettings?.taskListStatus !== "Completed" && <TouchableOpacity
                        style={styles.bottomSheetButton}
                        onPress={() => handleOptionSelect()}
                    >
                        <Text style={styles.bottomSheetButtonText}>Edit Task List</Text>
                    </TouchableOpacity>}
                    <TouchableOpacity
                        style={styles.bottomSheetCompleteButton}
                        onPress={handleExportQRCodesAsPDF}
                    >
                        <Text style={styles.bottomSheetConfirmButtonText}>
                            Export QR Codes as PDF
                        </Text>
                        <Icon
                            name="file-pdf-o"
                            size={20}
                            color="white"
                            style={styles.checkmarkIcon}
                        />
                    </TouchableOpacity>
                    {task.taskListSettings?.taskListStatus !== "Open" ? (
                        <TouchableOpacity
                            style={styles.bottomSheetCompleteButton}
                            onPress={handleExportAsPDF}
                        >
                            <Text style={styles.bottomSheetConfirmButtonText}>
                                Export Tasklist as PDF
                            </Text>
                            <Icon
                                name="file-pdf-o"
                                size={20}
                                color="white"
                                style={styles.checkmarkIcon}
                            />
                        </TouchableOpacity>
                    ) : null}
                    <TouchableOpacity
                        style={styles.bottomSheetDeleteButton}
                        onPress={handleDeleteTasklist}
                    >
                        <Text style={styles.bottomSheetConfirmButtonText}>Delete tasklist</Text>
                        <Icon
                            name="remove"
                            size={20}
                            color="white"
                            style={styles.checkmarkIcon}
                        />
                    </TouchableOpacity>
                </BottomSheetView>
            </BottomSheet>
        </View>
    );
};

const styles = StyleSheet.create({
    safeContainer: {
        flex: 1,
        backgroundColor: "#fff",
    },
    header: {
        flexDirection: "row",
        alignItems: "center",
        padding: 16,
        backgroundColor: "transparent",
    },
    header2: {
        position: "absolute",
        alignSelf: "center",
    },
    headerTitle: {
        fontSize: 24,
        marginLeft: 16,
    },
    taskInfo: {
        paddingHorizontal: 16,
        marginTop: 70,
        marginBottom: 16,
    },
    taskTitle: {
        fontSize: 20,
        marginBottom: 4,
    },
    popupLabel: {
        alignSelf: "center",
        fontSize: 24,
        fontWeight: "600",
        marginBottom: 20,
    },
    dueDate: {
        fontSize: 16,
        color: "gray",
    },
    completedText: {
        fontSize: 16,
        color: "green",
    },
    taskItem: {
        padding: 10,
    },
    taskName: {
        fontSize: 18,
        fontWeight: "500",
    },
    overlay: {
        position: "absolute",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: "rgba(0, 0, 0, 0.5)",
        zIndex: 1,
    },
    input: {
        borderWidth: 1,
        borderColor: "#ccc",
        padding: 10,
        marginTop: 10,
        borderRadius: 10,
        color: "#333",
    },
    checkboxContainer: {
        flexDirection: "row",
        alignItems: "center",
        marginTop: 10,

    },
    checkbox: {
        width: Platform.OS ==='ios' ?20:35,
        height: Platform.OS ==='ios'?20:35,
        marginRight: 8,
    },
    yesNoContainer: {
        flexDirection: "column",
        alignItems: "flex-start",
        marginTop: 10,
    },
    signButton: {
        backgroundColor: "transparent",
        borderWidth: 1,
        borderColor: "#ccc",
        paddingVertical: 10,
        paddingHorizontal: 20,
        borderRadius: 10,
        marginTop: 10,
    },
    signButtonText: {
        color: "#ccc",
        textAlign: "center",
        fontSize: 16,
    },
    modalContainer: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
        backgroundColor: "rgba(0, 0, 0, 0.5)",
    },
    modalContent: {
        backgroundColor: "#fff",
        padding: 20,
        borderRadius: 10,
        width: "90%",
        height: "45%",
        alignItems: "center",
    },
    signature: {
        width: "100%",
        minHeight: "20%",
        borderWidth: 1,
        borderColor: "#ccc",
        marginBottom: 10,
    },
    footer: {
        flexDirection: "row",
        justifyContent: "space-between",
        padding: 10,
        marginBottom: 10,
    },
    button: {
        flex: 1,
        backgroundColor: "white",
        borderWidth: 1,
        borderColor: "#ccc",
        paddingVertical: 10,
        marginHorizontal: 5,
        borderRadius: 10,
    },
    buttonText: {
        color: "black",
        textAlign: "center",
        fontSize: 16,
    },
    submitButton: {
        flex: 1,
        backgroundColor: "#AA90E7",
        paddingVertical: 10,
        marginHorizontal: 5,
        borderRadius: 10,
    },
    disabledBtn: {
        backgroundColor: "grey",
    },
    submitButtonText: {
        color: "#fff",
        textAlign: "center",
        fontSize: 16,
    },
    datePickerButton: {
        backgroundColor: "#f0f0f0",
        borderWidth: 1,
        borderColor: "#ccc",
        paddingVertical: 10,
        paddingHorizontal: 15,
        borderRadius: 10,
        marginTop: 10,
        alignItems: "center",
    },

    datePickerText: {
        color: "#333",
        fontSize: 16,
        textAlign: "center",
    },
    iconContainer: {
        position: "absolute",
        right: 16,
        top: 16,
    },
    modalContainer: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
        backgroundColor: "rgba(0, 0, 0, 0.5)",
    },
    modalContent: {
        width: "80%",
        backgroundColor: "white",
        borderRadius: 10,
        padding: 20,
        alignItems: "center",
    },
    modalTitle: {
        fontSize: 20,
        marginBottom: 15,
    },
    modalOption: {
        fontSize: 18,
        marginVertical: 10,
    },
    signatureContainer: {
        padding: 0,
        borderColor: "#ccc",
        borderWidth: 1,
        borderRadius: 5,
        alignItems: "center",
        justifyContent: "center",
        height: 160,
    },
    signatureImage: {
        width: "100%",
        height: "100%",
    },
    exportButton: {
        backgroundColor: "#2196f3",
        padding: 10,
        borderRadius: 5,
        margin: 10,
        alignItems: "center",
    },
    exportButtonText: {
        color: "white",
        fontSize: 16,
        fontWeight: "bold",
    },
    bottomSheetContent: {
        borderRadius: 50,
        flex: 1,
        paddingHorizontal: 16,
        paddingVertical: 0,
    },
    bottomSheetButton: {
        padding: 12,
        backgroundColor: "#f0f0f0",
        borderRadius: 8,
        marginBottom: 8,
    },
    bottomSheetCompleteButton: {
        padding: 12,
        backgroundColor: "#2196f3",
        borderRadius: 8,
        marginBottom: 8,
        flexDirection: "row",
        justifyContent: "center",
        alignItems: "center",
    },
    bottomSheetDeleteButton: {
        padding: 12,
        backgroundColor: "#f32121",
        borderRadius: 8,
        marginBottom: 8,
        flexDirection: "row",
        justifyContent: "center",
        alignItems: "center",
    },
    bottomSheetConfirmButtonText: {
        fontSize: 16,
        color: "white",
        fontWeight: "600",
        textAlign: "center",
    },
    checkmarkIcon: {
        marginLeft: 10,
    },
    bottomSheetButtonText: {
        fontSize: 16,
        fontWeight: "600",
        textAlign: "center",
    },
    scanButton: {
        backgroundColor: "#2196f3",
        padding: 10,
        borderRadius: 5,
        textAlign: "center",
        color: "white",
        fontWeight: "bold",
    },
    scannerContainer: {
        width: "80%",
        aspectRatio: 1,
        backgroundColor: "#f0f0f0",
        borderRadius: 15,
        overflow: "hidden",
        alignSelf: "center",
        position: "absolute",
        top: "30%",
        bottom: "30%",
    },
    hintText: {
        fontSize: 14,
        color: "rgba(102,102,102,1.00)",
        textAlign: "center",
        marginTop: 10,
    },
    logo: {
        alignSelf: "center",
        width: 150,
        height: 150,
    },
    title: {
        fontSize: 20,
        fontWeight: "bold",
        color: "#000",
        textAlign: "center",
    },
    cancelButton: {
        backgroundColor: "#fff",
        borderWidth: 1,
        borderColor: "#333",
        borderRadius: 10,
        padding: 10,
        flex: 1,
    },
    cancelButtonText: {
        color: "#333",
        textAlign: "center",
    },
    modalButtonRow: {
        alignSelf: "center",
        position: "absolute",
        bottom: 35,
        flexDirection: "row",
        justifyContent: "space-between",
        paddingHorizontal: 25,
        marginTop: 15,
    },
});

export default TaskListScreen;
