import React, {useCallback, useMemo, useState} from "react";
import Icon from 'react-native-vector-icons/MaterialIcons';

import {Alert, FlatList, StyleSheet, Text, TextInput, TouchableOpacity, View,} from "react-native";
import i18n from "@/app/localization";
import {MaterialCommunityIcons} from "@expo/vector-icons";
import {getStatusColor} from "@/app/utils/utils";
import {doc, getDoc, updateDoc} from "firebase/firestore";
import {firestore} from "@/app/(api)/firebase";

const randn = require('randn');


const AllTasks = ({route, navigation}) => {
    const {roles, businessId, username, tasks} = route.params;
    const [searchQuery, setSearchQuery] = useState('');


    const filteredData = useMemo(() => {
        if (!searchQuery) {
            // Remove duplicates if no search query is provided
            return Array.from(new Map(tasks.map(item => [item?.name?.toLowerCase(), item])).values());
        }

        // Apply search query filter first
        const filtered = tasks.filter((item) =>
            item?.name?.toLowerCase().includes(searchQuery.toLowerCase())
        );

        // Remove duplicates from filtered results
        return Array.from(new Map(filtered.map(item => [item?.name?.toLowerCase(), item])).values());
    }, [searchQuery]); // Recalculate only when search changes

    const clearSearch = useCallback(() => {
        setSearchQuery('');
    }, [searchQuery]);


    const onItemPress = useCallback((item) => {
        const selectedTask = JSON.parse(JSON.stringify(item));
        navigation.navigate("(app)/update_task", {
            roles: roles,
            businessId: businessId,
            username: username,
            task: selectedTask,
            isUpdate: true,
        });
    }, [])

    const createDuplicateTask = useCallback(async (item) => {
            const selectedTask = JSON.parse(JSON.stringify(item));
            delete selectedTask?.status;
            delete selectedTask?.id;
            selectedTask?.taskItems?.forEach(task => {
                delete task?.id;
                delete task?.value;
                //delete task?.status;
            });
            const businessId = route.params.businessId;
            const businessDocRef = doc(firestore, 'Businesses', businessId);

            const businessDoc = await getDoc(businessDocRef);

            if (businessDoc.exists()) {
                const id = randn();
                const dateTime = new Date(selectedTask?.taskListSettings?.dateTime);
                dateTime.setDate(dateTime.getDate() + 1);
                const displayDateTime = new Date(selectedTask?.taskListSettings?.displayDateTime);
                displayDateTime.setDate(displayDateTime.getDate() + 1);
                const taskItemObj = {
                    taskName: selectedTask?.taskName,
                    taskListSettings: {
                        ...selectedTask.taskListSettings,
                        dateTime: dateTime.toISOString(),
                        displayDateTime: displayDateTime.toISOString(),
                    },
                    taskItems: selectedTask.taskItems?.map(task => ({
                        ...task,
                        id: randn(),
                        status: task.type === 'Subtitle' ? 'Closed' : 'Open',
                    })),
                }
                const data = {
                    [`tasks.${id}`]: taskItemObj
                }
                const response = await updateDoc(businessDocRef, data);
                const taskItem = JSON.parse(JSON.stringify(taskItemObj))
                taskItem.id = id;
                navigation.navigate("(app)/taskListScreen", {
                    task: taskItem,
                    businessId: businessId,
                    taskListName: taskItem?.taskName,
                    roles: roles,
                    username: username,
                })
                // navigation.navigate('BottomTabs');
            }

        }
        ,
        []
    )

    const createNewTask = useCallback(() => {
        navigation.navigate("(app)/create_task", {
            roles: roles,
            businessId: businessId,
            username: username,
        });
    }, []);

    return (
        <View style={styles.container}>

            <View style={styles.headerViewContainer}>
                <TouchableOpacity onPress={() => navigation.goBack()}>
                    <MaterialCommunityIcons name="arrow-left" size={24} color="black"/>
                </TouchableOpacity>
                <View style={styles.searchContainer}>
                    <TextInput
                        style={styles.searchInput}
                        placeholder={i18n.t('allTasks.search_tasks')}
                        placeholderTextColor="#888"
                        value={searchQuery}
                        onChangeText={setSearchQuery}
                    />
                    {searchQuery.length > 0 ? (
                        <TouchableOpacity onPress={clearSearch} style={styles.searchIcon}>
                            <Icon name="close" size={20} color="#888"/>
                        </TouchableOpacity>
                    ) : (
                        <Icon name="search" size={20} color="#888" style={styles.searchIcon}/>
                    )}
                </View>
            </View>


            <FlatList
                style={styles.listContainerStyle}
                data={filteredData}
                showsVerticalScrollIndicator={false}
                renderItem={({item, index}) => {
                    return (<TouchableOpacity
                        key={index.toString()}
                        onPress={() => createDuplicateTask(item)}
                        style={[
                            styles.reportItem,
                            {borderColor: getStatusColor(item?.status)},
                        ]}>
                        <Text>{item.name}</Text>

                        <View style={{flexDirection: 'row'}}>
                            <TouchableOpacity onPress={() => onItemPress(item)}>
                                <MaterialCommunityIcons name="pencil" size={24} color="black"/>
                            </TouchableOpacity>
                        </View>
                    </TouchableOpacity>)

                }}
            />
            <TouchableOpacity style={styles.fab} onPress={createNewTask}>
                <MaterialCommunityIcons name="plus" size={24} color="white"/>
            </TouchableOpacity>

        </View>
    )
}


export default React.memo(AllTasks)

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        padding: 10
    },
    headerViewContainer: {
        flexDirection: 'row',
        alignItems: 'center'
    },
    listContainerStyle: {
        marginTop: 10,
        marginHorizontal: 10
    },

    searchContainer: {
        borderWidth: 1,
        borderColor: '#ddd',
        borderRadius: 8,
        paddingLeft: 10,
        paddingVertical: 10,
        marginLeft: 10,
        marginRight: 20,
        fontSize: 16,
        flexDirection: 'row',
        justifyContent: 'space-between',
    },
    searchInput: {
        fontSize: 16,
        width: '87%',
    },
    searchIcon: {
        marginRight: 10,
    },
    reportItem: {
        backgroundColor: "#f9f9f9",
        padding: 15,
        marginBottom: 10,
        borderRadius: 10,
        borderWidth: 1,
        borderLeftWidth: 6,
        borderColor: "#ccc",
        flexDirection: 'row',
        justifyContent: 'space-between'
    },
    fab: {
        position: 'absolute',
        bottom: 20,
        right: 20,
        backgroundColor: '#AA90E7',
        width: 60,
        height: 60,
        borderRadius: 30,
        justifyContent: 'center',
        alignItems: 'center',
        elevation: 5, // Shadow for Android
        shadowColor: '#000', // Shadow for iOS
        shadowOffset: {width: 0, height: 2},
        shadowOpacity: 0.3,
        shadowRadius: 3,
    },

});

