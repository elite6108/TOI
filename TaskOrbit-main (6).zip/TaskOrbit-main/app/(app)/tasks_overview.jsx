import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator
} from "react-native";
import { doc, getDoc } from "firebase/firestore";
import { auth, firestore } from "../(api)/firebase";
import { useNavigation } from "@react-navigation/native";
import { Dropdown } from "react-native-element-dropdown";

const TasksPage = () => {
  const [tasks, setTasks] = useState([]);
  const [filteredTasks, setFilteredTasks] = useState([]);
  const [isViewingTasks, setIsViewingTasks] = useState(2);
  const [userRole, setUserRole] = useState(null);
  const [userSecondRole, setUserSecondRole] = useState([]);
  const [businessId, setBusinessId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [value, setValue] = useState("week");
  const navigation = useNavigation();
  const userId = auth.currentUser?.uid;
  const [Roles, setRoles] = useState("");
  const [fullName, setFullName] = useState("loading...");


  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const userDoc = await getDoc(doc(firestore, "Users", userId));
        if (userDoc.exists()) {
          const userData = userDoc.data();
          setUserRole(userData.role);
          setUserSecondRole(userData.assignedRoles || []);
          setBusinessId(userData?.businessId);
          setFullName(userData?.fullName);
        } else {
          console.log("No such user document!");
        }
      } catch (error) {
        console.error("Error fetching user data: ", error);
      }
    };

    fetchUserData();
  }, [userId]);

  useEffect(() => {
    const fetchTasks = async () => {
      if (!businessId) return;

      try {
        const businessDoc = await getDoc(
          doc(firestore, "Businesses", businessId)
        );
        if (businessDoc.exists()) {
          const businessTasks = businessDoc.data().tasks;
          const userTasks = [];

          const businessRoles = businessDoc.data().roles;
          setRoles(businessRoles);

          for (const taskListName in businessTasks) {
            const taskList = businessTasks[taskListName];
            if (
              taskList.taskListSettings.roles.includes(userRole) ||
              userSecondRole.some((role) =>
                taskList.taskListSettings.roles.includes(role)
              )
            ) {
              userTasks.push({
                id:taskListName,
                name: taskList?.taskName,
                ...taskList,
              });
            }
          }

          userTasks.sort(
            (a, b) =>
              new Date(a.taskListSettings.dateTime) -
              new Date(b.taskListSettings.dateTime)
          );
          setTasks(userTasks);
          setFilteredTasks(userTasks);
        } else {
          console.log("No tasks found for this business!");
        }
      } catch (error) {
        console.error("Error fetching tasks: ", error);
      } finally {
        setLoading(false);
      }
    };

    fetchTasks();
  }, [businessId, userRole, userSecondRole]);

  useEffect(() => {
    const filterTasks = () => {
      if (isViewingTasks === 0) {
        const now = new Date();
        const dueSoonTasks = tasks.filter((task) => {
          const dueDate = new Date(task.taskListSettings.dateTime);
          const differenceInDays = (dueDate - now) / (1000 * 60 * 60 * 24);
          return differenceInDays <= 2 && differenceInDays >= 0;
        });
        setFilteredTasks(dueSoonTasks);
      } else if (isViewingTasks === 1) {
        const completedTasks = tasks.filter(
          (task) => task.taskListSettings.taskListStatus === "Completed"
        );
        setFilteredTasks(completedTasks);
      } else {
        setFilteredTasks(tasks);
      }
    };

    filterTasks();
  }, [isViewingTasks, tasks]);

  useEffect(() => {
    const filterTasks = () => {
      let filtered = [...tasks];

      if (value === "today") {
        const today = new Date();
        filtered = filtered.filter((task) => {
          const dueDate = new Date(task.taskListSettings.dateTime);
          return dueDate.toDateString() === today.toDateString();
        });
      } else if (value === "week") {
        const startOfWeek = new Date();
        startOfWeek.setDate(startOfWeek.getDate() - startOfWeek.getDay());
        const endOfWeek = new Date();
        endOfWeek.setDate(endOfWeek.getDate() + (6 - endOfWeek.getDay()));

        filtered = filtered.filter((task) => {
          const dueDate = new Date(task.taskListSettings.dateTime);
          return dueDate >= startOfWeek && dueDate <= endOfWeek;
        });
      } else if (value === "month") {
        const startOfMonth = new Date();
        startOfMonth.setDate(1);
        const endOfMonth = new Date(
          startOfMonth.getFullYear(),
          startOfMonth.getMonth() + 1,
          0
        );

        filtered = filtered.filter((task) => {
          const dueDate = new Date(task.taskListSettings.dateTime);
          return dueDate >= startOfMonth && dueDate <= endOfMonth;
        });
      } else if (value === "year") {
        const startOfYear = new Date();
        startOfYear.setMonth(0, 1);
        const endOfYear = new Date(startOfYear.getFullYear(), 11, 31);

        filtered = filtered.filter((task) => {
          const dueDate = new Date(task.taskListSettings.dateTime);
          return dueDate >= startOfYear && dueDate <= endOfYear;
        });
      } else if (value === "lifetime") {
      }

      setFilteredTasks(filtered);
    };

    filterTasks();
  }, [value, tasks]);

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
    <ActivityIndicator size="large" color="#2196f3" />
    </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.filterContainer}>
        <Text style={styles.filterLabel}>Tasks</Text>
        <Dropdown
          style={styles.dropdown}
          data={[
            { label: "Today", value: "today" },
            { label: "This week", value: "week" },
            { label: "This month", value: "month" },
            { label: "This year", value: "year" },
            { label: "Lifetime", value: "lifetime" },
          ]}
          labelField="label"
          valueField="value"
          placeholder="Select"
          value={value}
          onChange={(item) => setValue(item.value)}
        />
      </View>
      <View style={styles.switchContainer}>
        <TouchableOpacity
          onPress={() => setIsViewingTasks(0)}
          style={[
            styles.switchOption,
            isViewingTasks === 0 && styles.activeOption,
          ]}
        >
          <Text
            style={styles.switchText}
            numberOfLines={1}
            adjustsFontSizeToFit
          >{' Due Soon'}
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => setIsViewingTasks(1)}
          style={[
            styles.switchOption,
            isViewingTasks === 1 && styles.activeOption,
          ]}
        >
          <Text
              style={styles.switchText}
              numberOfLines={1}
              adjustsFontSizeToFit
          >{'Completed'}
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => setIsViewingTasks(2)}
          style={[
            styles.switchOption,
            isViewingTasks === 2 && styles.activeOption,
          ]}
        >
          <Text
            style={styles.switchText}
            numberOfLines={1}
            adjustsFontSizeToFit
          >
            All
          </Text>
        </TouchableOpacity>
      </View>

        <FlatList
          data={filteredTasks}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => {
            const now = new Date();
            const dueDate = new Date(item.taskListSettings.dateTime);
            const differenceInDays = (dueDate - now) / (1000 * 60 * 60 * 24);

            let borderColor = "#b3e0e8";
            let statusText = "Future Task";
            if (item.taskListSettings.taskListStatus === "Completed") {
              borderColor = "lightgreen";
              statusText = "Completed";
            } else if (differenceInDays <= 2 && differenceInDays >= 0) {
              borderColor = "#ffeb99";
              statusText = "Due Soon";
            }

            return (
              <TouchableOpacity
                onPress={() =>
                  navigation.navigate("(app)/taskListScreen", {
                    task: item,
                    businessId: businessId,
                    taskListName: item.name,
                    roles:Roles,
                    username: fullName,
                  })
                }
                style={[styles.taskItem, { borderLeftColor: borderColor }]}
              >
                <Text style={styles.taskTitle}>{item.name}</Text>
                <Text style={styles.taskDate}>
                  Assigned by: {item.taskListSettings.assignedBy}
                </Text>
                <Text style={styles.taskDate}>
                  Complete by: {dueDate.toLocaleString()}
                </Text>
                <View
                  style={[styles.statusBadge, { backgroundColor: borderColor }]}
                >
                  <Text style={styles.statusText}>{statusText}</Text>
                </View>
              </TouchableOpacity>
            );
          }}
          ListEmptyComponent={()=> <Text style={styles.noTasksText}>No tasks available.</Text>}
        />

    </View>
  );
};

export default TasksPage;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: "white",
  },
  header: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 20,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  filterContainer: {
    flexDirection: "row",
    marginBottom: 15,
    alignItems: "center",
    justifyContent: "space-between",
  },
  filterLabel: {
    fontSize: 24,
    fontWeight: "bold",
    marginRight: 10,
  },
  dropdown: {
    width: 120,
    backgroundColor: "transparent",
    borderWidth: 1,
    borderColor: "grey",
    borderRadius: 10,
    padding: 7,
  },
  noTasksText: {
    textAlign: "center",
    marginTop: 20,
    fontSize: 16,
    color: "#666",
  },
  taskItem: {
    backgroundColor: "#f9f9f9",
    padding: 15,
    borderRadius: 8,
    marginBottom: 15,
    elevation: 3,
    borderTopWidth: 1,
    borderRightWidth: 1,
    borderBottomWidth: 1,
    borderColor: "#ccc",
    borderLeftWidth: 5,
    borderLeftColor: "#b3e0e8",
  },
  taskTitle: {
    fontSize: 18,
    marginBottom: 5,
    fontWeight: "bold",
  },
  taskDescription: {
    marginTop: 5,
    fontSize: 14,
    color: "#555",
  },
  taskDate: {
    marginTop: 10,
    fontSize: 12,
    color: "#999",
  },
  switchContainer: {
    backgroundColor: "#eee",
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 10,
    borderRadius: 10,
  },
  switchOption: {
    borderRadius: 10,
    flex: 1,
    paddingVertical: 10,
    paddingHorizontal: 10,
    marginVertical: 5,
    marginHorizontal: 5,
    shadowOpacity: 0.2,
    shadowRadius: 2,
    shadowOffset: 10,
   // backgroundColor:'red'
  },
  activeOption: {
    backgroundColor: "#fff",
  },
  switchText: {
    alignSelf: "center",
    color: "black",
    fontSize: 16,
  },
  statusBadge: {
    position: "absolute",
    top: 10,
    right: 10,
    borderRadius: 15,
    paddingVertical: 5,
    paddingHorizontal: 10,
    alignItems: "center",
    justifyContent: "center",
  },
  statusText: {
    fontSize: 12,
    color: "#333",
    fontWeight: "bold",
  },
});
