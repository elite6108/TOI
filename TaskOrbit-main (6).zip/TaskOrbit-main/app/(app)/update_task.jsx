import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Modal,
  Image,
  KeyboardAvoidingView,
  Platform,
  Alert,
  TouchableWithoutFeedback, Keyboard,
  StatusBar,
  Share
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import DateTimePicker from '@react-native-community/datetimepicker';
import { MaterialIcons, FontAwesome } from '@expo/vector-icons';
import { doc, getDoc, updateDoc } from 'firebase/firestore';
import {  firestore } from '../(api)/firebase';
import DropDownPicker from 'react-native-dropdown-picker';
import RNHTMLtoPDF from 'react-native-html-to-pdf';
import randn from "randn";

export default function UpdateTask({ route, navigation }) {
  const { roles, businessId, username,task,isUpdate} = route.params;
  const [tasks, setTasks] = useState([{ name: '', color: '#dcdcdc', type: null }]);
  const [modalVisible, setModalVisible] = useState(false);
  const [TaskmodalVisible, setTaskModalVisible] = useState(false);
  const [selectedTaskIndex, setSelectedTaskIndex] = useState(null);
  const [selectedType, setSelectedType] = useState(null);
  const [selectedIcon, setSelectedIcon] = useState(null);
  const [selectedRoles, setSelectedRoles] = useState([]);
  const [selectedNotificationRoles, setSelectedNotificationRoles] = useState([]);
 const [selectedFrequency, setSelectedFrequency] = useState(null);
  const [taskListName, setTaskListName] = useState(task?.name || task?.taskListName);
  const [open, setOpen] = useState(false);
  const [open1, setOpen1] = useState(false);
  const [frequencyOpen, setFrequencyOpen] = useState(false);
  const [value, setValue] = useState(null);
  const [selectedDate, setSelectedDate] = useState('');
const [showDatePicker, setShowDatePicker] = useState(false);
  const [displayDate, setDisplayDate] = useState(new Date());
  const [showDisplayDatePicker, setShowDisplayDatePicker] = useState(false);

const randn = require('randn');
  const [taskErrors, setTaskErrors] = useState({
    tasks: false,
    selectedRoles: false,
    selectedFrequency: false,
  });
  const [roleOptions, setRoleOptions] = useState(
    roles.map(role => ({
      label: role.name,
      value: role.name,
      color: role.color,
    }))
  );

  const frequencyOptions = [
    { label: 'Once', value: 'once' },
    { label: 'Daily', value: 'daily' },
    { label: 'Bi-Weekly', value: 'bi_weekly' },
    { label: 'Monthly', value: 'monthly' },
    { label: 'On a specific date', value: 'specific_date' },
  ];

  const taskTypes = [
    { title: 'Subtitle', icon: 'title' },
    { title: 'Short Entry', icon: 'text-fields' },
    { title: 'Checkmark', icon: 'check-circle' },
    { title: 'Signature', icon: 'edit' },
    { title: 'Yes/No', icon: 'help' },
    { title: 'Date', icon: 'date-range' },
    { title: 'QR Code', icon: 'qr-code' },
  ];

  const handleTaskChange = (index, value) => {
    const updatedTasks = [...tasks];
    updatedTasks[index].name = value;
    setTasks(updatedTasks);
  };


  const removeTask = (index) => {
    Alert.alert(
      "Delete Task",
      "Are you sure you want to delete this task?",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Delete",
          onPress: () => {
            const updatedTasks = tasks.filter((_, i) => i !== index);
            setTasks(updatedTasks);
          },
          style: "destructive",
        },
      ]
    );
  };

  const confirmTaskCreation = () => {
    const updatedTasks = [...tasks];
    updatedTasks[selectedTaskIndex].type = { title: selectedType, icon: selectedIcon };
    setTasks(updatedTasks);
    setModalVisible(false);
    setSelectedType(null);
    setSelectedIcon(null);
    setSelectedTaskIndex(null);
  };

  const openTaskListSettings = () => {
    setTaskModalVisible(true);
  };

  const confirmTaskListSettings = () => {
    setTaskModalVisible(false);
};

const addTask = () => {
    setTasks([...tasks, { name: '', color: '#dcdcdc', type: null }]);
  };

  const confirmTaskListCreation = async () => {
    const missingFields = [];


    if (taskListName === '') missingFields.push('Assign a tasklist name');
    if (selectedRoles.length === 0) missingFields.push('Select at least one role');
    if (selectedNotificationRoles.length === 0) missingFields.push('Select notification roles');
    if (!selectedFrequency) missingFields.push('Select a task frequency');
    if (!selectedDate) missingFields.push('Select a date');
    if (!displayDate) missingFields.push('Select a Display Date');
    if (tasks.some(task => !task.type)) missingFields.push('Assign a type to all tasks');


    if (missingFields.length > 0) {
      Alert.alert('Incomplete Task Setup', `Please complete the following:\n- ${missingFields.join('\n- ')}`);
      return;
    }

    const businessId = route.params.businessId;
    const businessDocRef = doc(firestore, 'Businesses', businessId);

    try {
      const businessDoc = await getDoc(businessDocRef);

      if (businessDoc.exists()) {
        const businessData = businessDoc.data();


        let data= {
          [`tasks.${task?.id? task.id:randn()}`]: {
            taskName:taskListName,
            taskListSettings: {
              roles: selectedRoles,
              notificationRoles: selectedNotificationRoles,
              frequency: selectedFrequency,
              dateTime: selectedDate.toISOString(),
              displayDateTime: displayDate.toISOString(),
              assignedBy: username
            },
            taskItems: tasks.map(task => ({
              id: task?.id? task.id:randn(),
              name: task.name,
              type: task.type.title,
              status: task.type.title === 'Subtitle' ? 'Closed' : task?.value?"Completed":'Open',
              value:task?.value?task?.value:""
            })),
          }
        }

        console.log('data----', JSON.stringify(data))

        await updateDoc(businessDocRef, data);
        navigation.navigate('BottomTabs');
      } else {
        Alert.alert('Error', 'Business not found.');
      }
    } catch (error) {
      console.error('Error adding task list:', error);
      Alert.alert('Error', 'An error occurred while creating the task list.');
    }
  }

  const handleOpen = (dropdown) => {

    if (dropdown === 'roles' && open) {
      setOpen(false);
    } else if (dropdown === 'roles1' && open1) {
      setOpen1(false);
    } else if (dropdown === 'frequency' && frequencyOpen) {
      setFrequencyOpen(false);
    } else {

      setOpen(false);
      setOpen1(false);
      setFrequencyOpen(false);


      if (dropdown === 'roles') setOpen(true);
      if (dropdown === 'roles1') setOpen1(true);
      if (dropdown === 'frequency') setFrequencyOpen(true);
    }
  };

  useEffect(()=>{
    const updatedTaks=task?.taskItems?.map((_task)=>{
      const _type= taskTypes?.find((_taskType)=> _taskType.title===_task.type);
      return {..._task, name: _task?.name, color: '#dcdcdc', type: _type,id:_task.id, }
    });
    setTasks(updatedTaks);

    const taskListSettings= task?.taskListSettings;
    setSelectedRoles(taskListSettings?.roles);
    setSelectedNotificationRoles(taskListSettings?.notificationRoles)
    setSelectedFrequency(taskListSettings?.frequency)
    setSelectedDate(new Date(taskListSettings?.dateTime));
    setDisplayDate(new Date(taskListSettings?.displayDateTime));

  },[])

  const generatePDF = async (taskId, taskName) => {
    try {
      // Fetch the QR code image URL
      const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?data=${taskId}&size=150x150`;

      // Define the HTML content with QR code, logo, and footer
      const htmlContent = `
        <html>
          <head>
            <style>
              body {
                font-family: 'Arial', sans-serif;
                margin: 0;
                padding: 0;
                background-color: #f7f8fa;
              }
              .container {
                text-align: center;
                padding: 20px;
                background-color: #ffffff;
                box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
                border-radius: 10px;
                max-width: 600px;
                margin: auto;
              }
              .logo {
                width: 150px;
                height: 150px;
                margin-bottom: 20px;
              }
              .qr-code {
                width: 150px;
                height: 150px;
                margin-bottom: 20px;
              }
              .footer {
                margin-top: 30px;
                font-size: 12px;
                color: #6c757d;
                text-align: center;
              }
              .footer a {
                color: #2196f3;
                text-decoration: none;
              }
            </style>
          </head>
          <body>
            <div class="container">
              <img src="https://i.ibb.co/y4d8Vrg/IMG-7005.png" alt="TaskOrbit Logo" class="logo" />
              <h3>QR Code: '${taskName}'</h3>
              <p>Scan the QR code below to confirm your task.</p>
              <img src="${qrCodeUrl}" alt="QR Code" class="qr-code" />
              <div class="footer">
                <p>&copy; ${new Date().getFullYear()} TaskOrbit. All rights reserved.</p>
                <p>Visit us at <a href="https://taskorbitapp.com/" target="_blank">www.taskorbitapp.com</a></p>
              </div>
            </div>
          </body>
        </html>
      `;

      // Generate the PDF
      const options = {
        html: htmlContent,
        fileName: 'task_qr_code',
        directory: 'Documents',
      };

      const file = await RNHTMLtoPDF.convert(options);

      // Notify user of success
      if (Platform.OS === "ios") {
        Share.share({ url: file.filePath });
      }
    } catch (error) {
      console.error("Error generating PDF:", error);
      Alert.alert('Error', 'There was an issue generating the PDF.');
    }
  };

return (
  <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <StatusBar barStyle="dark-content" backgroundColor="#ffffff" />
      <Image
        source={require('../../assets/images/taskorbit.png')}
        style={styles.logo}
        resizeMode="contain"
      />

      <Text style={styles.headerText}>
        <Text style={styles.blueText}>{isUpdate?'Let’s Update a task list!':'Let’s create a new task list!'}</Text>
        {"\n\n"}
        <Text style={styles.blackText}>Tell us which tasks your business usually uses.</Text>
      </Text>

      <ScrollView style={styles.scrollView} contentContainerStyle={styles.scrollContent}>
      {tasks.map((task, index) => (
  <View key={index} style={[styles.taskContainer, { borderColor: task.color }]}>
    <TextInput
      style={styles.taskInput}
      value={task.name}
      placeholder={'Enter Text here...'}
      onChangeText={(value) => handleTaskChange(index, value)}
      multiline
      numberOfLines={4}
      textAlignVertical="top"
    />
    <TouchableOpacity
      onPress={() => {
        setSelectedTaskIndex(index);
        setModalVisible(true);
      }}
      style={styles.editButton}
    >
      <MaterialIcons name={task.type ? task.type.icon : 'edit'} size={24} color="#2196f3" />
      <Text style={styles.changeTypeText}>{task.type ? 'Change type' : 'Add type'}</Text>
    </TouchableOpacity>
        {task.id && (
      <TouchableOpacity onPress={() => generatePDF(task.id, task.name)} style={styles.editButton}>
        <MaterialIcons name="qr-code" size={24} color="#2196f3" />
        <Text style={styles.changeTypeText}>Show QR</Text>
      </TouchableOpacity>
    )}
    <TouchableOpacity onPress={() => removeTask(index)} style={styles.editButton}>
      <MaterialIcons name={'delete'} size={24} color="red" />
      <Text style={styles.removeTaskText}>{'Remove'}</Text>
    </TouchableOpacity>
  </View>
))}
        <TouchableOpacity style={styles.addButton} onPress={addTask}>
          <Text style={styles.addButtonText}>Add new task</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.addButton} onPress={openTaskListSettings}>
        <Text style={styles.addButtonText}>Task list settings</Text>
      </TouchableOpacity>
      <LinearGradient
  colors={['#a72693', '#f3a6f3']}
  start={{ x: 1, y: 0 }}
  end={{ x: 0, y: 1 }}
  style={styles.taskAiCreation}
>
<TouchableOpacity onPress={() =>     navigation.replace('(app)/generateTaskList', {
      roles, businessId
    })} style={styles.confirmAIButton}>
  <FontAwesome name="magic" size={20} color="#fff" style={styles.icon} />
  <Text style={styles.confirmAIButtonText}>Create with AI</Text>
</TouchableOpacity>
</LinearGradient>
      </ScrollView>

      {/* Modal for task type selection */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Select a task type</Text>
            <ScrollView>
              {taskTypes.map((type, typeIndex) => (
                <TouchableOpacity
                  key={typeIndex}
                  style={[styles.typeButton, selectedType === type.title && styles.selectedType]}
                  onPress={() => {
                    setSelectedType(type.title);
                    setSelectedIcon(type.icon);
                  }}
                >
                  <MaterialIcons name={type.icon} size={24} color="#2196f3" />
                  <Text style={styles.typeButtonText}>{type.title}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
            <View style={styles.modalButtonRow}>
              <TouchableOpacity
                style={styles.cancelButton}
                onPress={() => setModalVisible(false)}
              >
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.confirmTaskButton}
                onPress={confirmTaskCreation}
              >
                <Text style={styles.confirmTaskButtonText}>Confirm</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      <Modal
  animationType="slide"
  transparent={true}
  visible={TaskmodalVisible}
  onRequestClose={() => setTaskModalVisible(false)}
>
  <View style={styles.modalContainer}>
    <View style={styles.modalContent}>
      <Text style={styles.modalTitle}>Task list settings</Text>

      {/* New input for Task List Name */}
      <Text style={styles.modalHeader}>Task List Name</Text>
      <TextInput
        style={styles.input}
        placeholder="Enter task list name"
        placeholderTextColor={'black'}
        value={taskListName}
        onChangeText={setTaskListName}
      />

<Text style={styles.modalHeader}>Select Completion Date/Time</Text>
<TouchableOpacity
  style={styles.datePickerButton}
  onPress={() => setShowDatePicker(true)}
>
  <Text style={styles.datePickerButtonText}>
    {selectedDate ? selectedDate.toLocaleString() : 'Pick a start date/time'}
  </Text>
</TouchableOpacity>

{showDatePicker && (
  <DateTimePicker
    value={selectedDate}
    mode="datetime"
    display="default"
    onChange={(event, date) => {
      if (event.type === 'set') {
        // This means the user clicked "OK" and selected a date
        if (date) {
          setShowDatePicker(false);
          setSelectedDate(date);
        }
      }
      // If the event is 'dismissed', meaning the user clicked "Cancel"
      setShowDatePicker(false);
    }}
  />
)}

      <Text style={styles.modalHeader}>Select Display  Date/Time</Text>
      <TouchableOpacity
          style={styles.datePickerButton}
          onPress={() => setShowDisplayDatePicker(true)}
      >
        <Text style={styles.datePickerButtonText}>
          {displayDate ? displayDate.toLocaleString() : 'Pick a start date/time'}
        </Text>
      </TouchableOpacity>



      {showDisplayDatePicker && (
          <DateTimePicker
              value={displayDate}
              mode="datetime"
              display="default"
              minimumDate={new Date()}
              maximumDate={selectedDate}
              onChange={(event, date) => {
                if (event.type === 'set') {
                  // This means the user clicked "OK" and selected a date
                  if (date) {
                    setShowDisplayDatePicker(false);
                    setDisplayDate(date);
                  }
                }
                // If the event is 'dismissed', meaning the user clicked "Cancel"
                setShowDisplayDatePicker(false);

              }}
          />
      )}

{ roles ?
      <><Text style={styles.modalHeader}>Roles attached to list</Text><DropDownPicker
                zIndex={10}
                open={open}
                value={selectedRoles}
                items={roleOptions}
                setOpen={() => handleOpen('roles')}
                setValue={setSelectedRoles}
                placeholder="Select roles"
                multiple={true}
                min={0}
                max={5} /><Text style={styles.modalHeader}>Notification roles on task completion</Text><DropDownPicker
                  zIndex={9}
                  open={open1}
                  value={selectedNotificationRoles}
                  items={roleOptions}
                  setOpen={() => handleOpen('roles1')}
                  setValue={setSelectedNotificationRoles}
                  placeholder="Select roles"
                  multiple={true}
                  min={0}
                  max={5} /></>
: null }
      <Text style={styles.modalHeader}>Task Frequency</Text>
      <DropDownPicker
            zIndex={8}
        open={frequencyOpen}
        value={selectedFrequency}
        items={frequencyOptions}
        setOpen={() => handleOpen('frequency')}
        setValue={setSelectedFrequency}
        placeholder="Select frequency"
      />
      <View style={styles.modalButtonRow}>
        <TouchableOpacity
          style={styles.cancelButton}
          onPress={() => setTaskModalVisible(false)}
        >
          <Text style={styles.cancelButtonText}>Cancel</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.confirmTaskButton}
          onPress={confirmTaskListSettings}
        >
          <Text style={styles.confirmTaskButtonText}>Confirm</Text>
        </TouchableOpacity>
      </View>
    </View>
  </View>
</Modal>

      <View style={styles.buttonRow}>
        <TouchableOpacity style={styles.skipButton} onPress={() => navigation.goBack()}>
          <Text style={styles.skipButtonText}>Back to list</Text>
        </TouchableOpacity>

        <LinearGradient
          colors={['#2196f3', '#21cbf3']}
          start={{ x: 1, y: 0 }}
          end={{ x: 0, y: 0 }}
          style={styles.confirmButton}
        >
          <TouchableOpacity onPress={confirmTaskListCreation}>
            <Text style={styles.confirmButtonText}>{isUpdate?'Update task':'Confirm task creation'} </Text>
          </TouchableOpacity>
        </LinearGradient>
      </View>
    </KeyboardAvoidingView>
    </TouchableWithoutFeedback>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    justifyContent: 'flex-start',
  },
  logo: {
    width: '100%',
    marginTop: 20,
    height: 150,
  },
  headerText: {
    fontWeight: 'bold',
    marginBottom: 20,
  },
  blueText: {
    fontSize: 25,
    color: '#2196f3',
  },
  blackText: {
    fontSize: 20,
    color: 'black',
  },
  scrollView: {
    flex: 1,
    marginBottom: 20,
  },
  scrollContent: {
    paddingBottom: 20,
  },
  taskContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f0f0f0',
    borderRadius: 10,
    marginVertical: 5,
    padding: 10,
    borderWidth: 2,
  },
  taskInput: {
    flex: 1,
    fontSize: 16,
    height: 50,
    color: 'black',
    marginLeft: 10,
  },
  editButton: {
    padding: 5,
    alignItems: 'center',
  },
  changeTypeText: {
    fontSize: 12,
    color: '#2196f3',
  },
  removeTaskText: {
    fontSize: 12,
    color: 'red',
  },
  addButton: {
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: '#dcdcdc',
    borderRadius: 10,
    padding: 15,
    alignItems: 'center',
    marginVertical: 5,
    width: '100%',
  },
  addButtonText: {
    color: 'black',
    fontWeight: 'bold',
  },
  buttonRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  skipButton: {
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: '#dcdcdc',
    borderRadius: 10,
    padding: 15,
    alignItems: 'center',
    flex: 1,
    marginRight: 10,
  },
  skipButtonText: {
    color: '#2196f3',
    fontWeight: 'bold',
  },
  confirmButton: {
    borderRadius: 10,
    padding: 15,
    flex: 2,
  },
  confirmButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  taskAiCreation: {
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'center',
    top: 5,
  },
  confirmAIButton: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  icon: {
    marginRight: 8,
  },
  confirmAIButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 10,
    width: '80%',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 0,
    textAlign: 'center',
  },
  modalHeader: {
    fontSize: 14,
    fontWeight: 'bold',
    marginTop: 20,
    marginBottom: 5,
    textAlign: 'left',
  },
  typeButton: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 10,
    borderWidth: 1,
    borderColor: '#dcdcdc',
    borderRadius: 10,
    marginVertical: 5,
  },
  selectedType: {
    backgroundColor: '#e0f7fa',
  },
  typeButtonText: {
    marginLeft: 10,
  },
  modalButtonRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 15,
  },
  confirmTaskButton: {
    backgroundColor: '#2196f3',
    borderRadius: 10,
    padding: 10,
    flex: 1,
    marginLeft: 5,
  },
  cancelButton: {
    backgroundColor: '#f44336',
    borderRadius: 10,
    padding: 10,
    flex: 1,
    marginRight: 5,
  },
  confirmTaskButtonText: {
    color: '#fff',
    textAlign: 'center',
  },
  cancelButtonText: {
    color: '#fff',
    textAlign: 'center',
  },
  input: {
    borderColor: 'black',
    color: 'black',
    borderWidth: 1,
    borderRadius: 5,
    padding: 12,
    fontSize: 16,
  },
  datePickerButton: {
    padding: 10,
    borderWidth: 1,
    borderColor: 'black',
    borderRadius: 10,
  },
  datePickerButtonText: {
    color: 'black',
  },
});
