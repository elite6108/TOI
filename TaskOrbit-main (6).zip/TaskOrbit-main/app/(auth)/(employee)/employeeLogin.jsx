import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ActivityIndicator, SafeAreaView, Pressable, ScrollView, TouchableOpacity } from 'react-native';
import { useRoute, useNavigation } from '@react-navigation/native';
import { firestore } from '../../(api)/firebase'; 
import { collection, doc, getDoc, getDocs, query, where } from 'firebase/firestore';
import { Ionicons } from '@expo/vector-icons'; 

const UserDetailsScreen = () => {
  const route = useRoute();
  const navigation = useNavigation();
  const { QRCodeData } = route.params;
  const [matchingUsers, setMatchingUsers] = useState([]);
  const [businessName, setBusinessName] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchBusinessAndUsers = async () => {
      try {
        const businessDocRef = doc(firestore, 'Businesses', QRCodeData);
        const businessDocSnap = await getDoc(businessDocRef);

        if (businessDocSnap.exists()) {
          const businessData = businessDocSnap.data();
          setBusinessName(businessData.name);
        } else {
          setBusinessName('Business not found');
        }

        const usersRef = collection(firestore, 'Users');
        const q = query(usersRef, where('businessId', '==', QRCodeData));
        const querySnapshot = await getDocs(q);

        const users = querySnapshot.docs.map(doc => {
          const data = doc.data();
          return { id: doc.id, fullName: data.fullName, email: data.email };
        });
        setMatchingUsers(users);
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchBusinessAndUsers();
  }, [QRCodeData]);

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#000" />
        <Text>Loading data...</Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
            <TouchableOpacity
        style={styles.backButton}
        onPress={() => navigation.replace('(app)/employeeScanner')}
      >
        <Ionicons name="arrow-back" size={24} color="#333" />
      </TouchableOpacity>

      <Text style={styles.title}>{businessName}</Text>
      <Text style={styles.headerText}>Please select your employee account to continue</Text>
      <ScrollView contentContainerStyle={styles.scrollViewContent}>
        {matchingUsers.length > 0 ? (
          matchingUsers.map((user, index) => (
            <Pressable
              key={index}
              style={styles.userContainer}
              onPress={() => navigation.navigate('(auth)/pinEntry', { userDocId: user.id })}
            >
              <Text style={styles.userText} numberOfLines={1} adjustsFontSizeToFit>
                {user.fullName}
              </Text>
            </Pressable>
          ))
        ) : (
          <Text style={styles.noMatchText}>No users found with this Business ID.</Text>
        )}
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    alignItems: 'stretch',
    paddingVertical: 16,
    paddingHorizontal: 0,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerText: {
    fontSize: 18,
    color: '#666',
    textAlign: 'center',
    marginBottom: 12,
    paddingHorizontal: 20,
  },
  title: {
    fontSize: 24,
    alignSelf: 'center',
    fontWeight: 'bold',
    marginBottom: 5,
    color: '#2196f3',
  },
  scrollViewContent: {
    paddingBottom: 16,
    alignItems: 'center',
  },
  userContainer: {
    padding: 12,
    marginVertical: 6,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#ddd',
    backgroundColor: '#f9f9f9',
    width: '90%',
    alignItems: 'center',
    elevation: 1, 
    shadowColor: '#000', 
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.2,
    shadowRadius: 1.5,
  },
  userText: {
    fontSize: 18,
    color: '#333',
    fontWeight: '500',
  },
  noMatchText: {
    fontSize: 16,
    color: '#999',
    textAlign: 'center',
    paddingHorizontal: 20,
  },
  backButton: {
    position: 'absolute',
    top: 50, 
    left: 25,
    zIndex: 1, 
  },
});

export default UserDetailsScreen;
