import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity } from 'react-native';
import { BarCodeScanner } from 'expo-barcode-scanner';
import { BlurView } from 'expo-blur';
import Ionicons from 'react-native-vector-icons/Ionicons'; 
import { useNavigation } from '@react-navigation/native';

const QRCodeScannerScreen = () => {
  const [hasPermission, setHasPermission] = useState(null);
  const [scanned, setScanned] = useState(false);
  const navigation = useNavigation();

  useEffect(() => {
    const requestPermission = async () => {
      const { status } = await BarCodeScanner.requestPermissionsAsync();
      setHasPermission(status === 'granted');
    };

    requestPermission();
  }, []);

  const handleBarCodeScanned = ({ type, data }) => {
    setScanned(true);
    console.log(`QR Code Scanned! Data: ${data}`);
    navigation.replace('(app)/employeeLogin', { QRCodeData: data });
  };

  if (hasPermission === null) {
    return <Text>Requesting camera permission...</Text>;
  }
  if (hasPermission === false) {
    return <Text>No access to camera</Text>;
  }

  return (
    <View style={styles.container}>
      {/* Back Button */}
      <TouchableOpacity style={styles.backButton} onPress={() => navigation.replace('(auth)/login')}>
        <Ionicons name="arrow-back" size={28} color="#333" />
      </TouchableOpacity>

      {/* App Logo */}
      <Image
        source={require('../../../assets/images/taskorbit.png')} 
        style={styles.logo}
        resizeMode="contain"
      />

      {/* Title Text */}
      <Text style={styles.title}>Scan QR code to log in</Text>

      {/* QR Scanner */}
      <View style={styles.scannerContainer}>
        <BarCodeScanner
          onBarCodeScanned={scanned ? undefined : handleBarCodeScanned}
          style={StyleSheet.absoluteFillObject}
        />
        {scanned && (
          <>
            <BlurView intensity={50} style={StyleSheet.absoluteFillObject} tint="dark" />
            <TouchableOpacity style={styles.overlayButton} onPress={() => setScanned(false)}>
              <Text style={styles.overlayButtonText}>Tap to Scan Again</Text>
            </TouchableOpacity>
          </>
        )}
      </View>

      {/* Hint Text */}
      <Text style={styles.hintText}>Hold the camera steady to scan the code</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 16,
  },
  backButton: {
    position: 'absolute',
    top: 50, 
    left: 25,
    zIndex: 1, 
  },
  logo: {
    width: 150,
    height: 150,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#000',
    marginBottom: 20,
    textAlign: 'center',
  },
  scannerContainer: {
    width: '80%',
    aspectRatio: 1,
    backgroundColor: '#f0f0f0',
    borderRadius: 15,
    overflow: 'hidden',
    marginBottom: 10,
    position: 'relative',
  },
  hintText: {
    fontSize: 14,
    color: 'rgba(102,102,102,1.00)',
    textAlign: 'center',
    marginTop: 10,
  },
  overlayButton: {
    position: 'absolute',
    top: '50%',
    left: '50%',
    alignSelf: 'left',
    transform: [{ translateX: -50 }, { translateY: -50 }],
    backgroundColor: 'rgba(0,0,0,0.7)',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 8,
  },
  overlayButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});

export default QRCodeScannerScreen;
