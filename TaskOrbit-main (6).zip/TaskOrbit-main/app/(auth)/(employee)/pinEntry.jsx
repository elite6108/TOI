import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Alert,
  TouchableOpacity,
  Animated,
  Modal
} from 'react-native';
import { firestore, auth } from '../../(api)/firebase';
import { doc, getDoc } from 'firebase/firestore';
import { signInWithCustomToken, getAuth } from 'firebase/auth';
import CryptoJS from 'crypto-js';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Constants from 'expo-constants';

const secretKey = Constants.expoConfig.extra.firebase.pinEncryptionKey;

const PinEntryScreen = ({ route, navigation }) => {
  const { userDocId } = route.params;
  const [pin, setPin] = useState('');
  const [dotAnimations] = useState([
    new Animated.Value(1),
    new Animated.Value(1),
    new Animated.Value(1),
    new Animated.Value(1)
  ]);
  const [modalVisible, setModalVisible] = useState(false);

  const handlePinPress = (number) => {
    if (pin.length < 4) {
      const newPin = pin + number;
      setPin(newPin);


      const index = newPin.length - 1;
      animateDot(index, true);


      if (newPin.length === 4) {
        handleSubmit(newPin);
      }
    }
  };

  const handleBackPress = () => {
    if (pin.length > 0) {
      const newPin = pin.slice(0, -1);
      setPin(newPin);


      animateDot(newPin.length, false);
    }
  };

  const animateDot = (index, enlarge) => {
    Animated.timing(dotAnimations[index], {
      toValue: enlarge ? 1.6 : 1,
      duration: 200,
      useNativeDriver: true,
    }).start();
  };

  const handleSubmit = async (submittedPin) => {
    if (submittedPin.length < 4) return;

    try {
      const response = await fetch('http://85.215.53.196/api/loginHandler.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ userDocId, pin: submittedPin }),
      });

      if (!response.ok) {
        throw new Error('Invalid PIN or authentication failed');
      }

      const data = await response.json();
      console.log('Response Data:', data);

      if (data.status === 200) {
        const token = data.token;
        console.log('Generated Token:', token);

        const auth = getAuth();
        const userCredential = await signInWithCustomToken(auth, token);
        const { user } = userCredential;

        await AsyncStorage.setItem(
          'userCredentials',
          JSON.stringify({
            uid: user.uid,
          })
        );

        navigation.replace('BottomTabs');
      } else {
        console.log('Login failed:', data.message);
        Alert.alert('Error', data.message || 'Unable to log in with the provided PIN.');
      }
    } catch (error) {
      console.error('Error during PIN login:', error);
      Alert.alert('Error', 'Unable to log in with the provided PIN.');
    }
  };

  const handleForgotPin = () => {
    setModalVisible(true);
  };

  return (
    <View style={styles.container}>
      <TouchableOpacity
        style={styles.backButton}
        onPress={() => navigation.goBack()}
      >
        <Ionicons name="arrow-back" size={24} color="#333" />
      </TouchableOpacity>

      <Text style={styles.title}>Enter your PIN code</Text>
      <View style={styles.pinDisplay}>
        <View style={styles.dotsContainer}>
          {Array.from({ length: 4 }, (_, index) => (
            <Animated.View
              key={index}
              style={[
                styles.dot,
                {
                  transform: [{ scale: dotAnimations[index] }],
                },
              ]}
            />
          ))}
        </View>
      </View>
      <View style={styles.buttonContainer}>
        {/* First Row of Buttons */}
        <View style={styles.row}>
          {[1, 2, 3].map((number) => (
            <TouchableOpacity
              key={number}
              style={styles.button}
              onPress={() => handlePinPress(number)}
            >
              <Text style={styles.buttonText}>{number}</Text>
            </TouchableOpacity>
          ))}
        </View>
        {/* Second Row of Buttons */}
        <View style={styles.row}>
          {[4, 5, 6].map((number) => (
            <TouchableOpacity
              key={number}
              style={styles.button}
              onPress={() => handlePinPress(number)}
            >
              <Text style={styles.buttonText}>{number}</Text>
            </TouchableOpacity>
          ))}
        </View>
        {/* Third Row of Buttons */}
        <View style={styles.row}>
          {[7, 8, 9].map((number) => (
            <TouchableOpacity
              key={number}
              style={styles.button}
              onPress={() => handlePinPress(number)}
            >
              <Text style={styles.buttonText}>{number}</Text>
            </TouchableOpacity>
          ))}
        </View>
        {/* Fourth Row with Back Button, 0 Button, and Empty Space */}
        <View style={styles.row}>
          <View style={styles.emptyButton}></View>
          <TouchableOpacity
            style={styles.button}
            onPress={() => handlePinPress(0)}
          >
            <Text style={styles.buttonText}>0</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.button}
            onPress={handleBackPress}
          >
            <Text style={styles.buttonText}>←</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* "Forgot PIN code?" text at the bottom */}
      <TouchableOpacity onPress={handleForgotPin}>
        <Text style={styles.forgotPinText}>Forgot PIN code?</Text>
      </TouchableOpacity>

      {/* Modal for Reset PIN Code */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Reset PIN Code</Text>
            <Text style={styles.modalText}>
              Your employer can reset your PIN code for you.
            </Text>
            <TouchableOpacity
              style={styles.modalButton}
              onPress={() => setModalVisible(false)}
            >
              <Text style={styles.modalButtonText}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
  },
  backButton: {
    position: 'absolute',
    top: 50,
    left: 25,
    zIndex: 1,
  },
  title: {
    fontSize: 24,
    marginBottom: 20,
  },
  pinDisplay: {
    marginBottom: 20,
  },
  dotsContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
  },
  dot: {
    width: 10,
    height: 10,
    borderRadius: 10,
    backgroundColor: '#2196f3',
    margin: 10,
  },
  buttonContainer: {
    width: '60%',
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginVertical: 5,
  },
  button: {
    width: '30%',
    height: 60,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'transparent',
    borderRadius: 5,
  },
  buttonText: {
    fontSize: 24,
    color: 'black',
  },
  emptyButton: {
    width: '30%',
  },
  forgotPinText: {
    color: '#2196f3',
    marginTop: 20,
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    width: '80%',
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    padding: 20,
    elevation: 10,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#2196f3',
    textAlign: 'center',
  },
  modalText: {
    fontSize: 16,
    marginBottom: 20,
    color: '#333',
    textAlign: 'left',
  },
  modalButton: {
    backgroundColor: '#2196f3',
    borderRadius: 5,
    paddingVertical: 10,
    paddingHorizontal: 15,
    alignItems: 'center',
  },
  modalButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default PinEntryScreen;
