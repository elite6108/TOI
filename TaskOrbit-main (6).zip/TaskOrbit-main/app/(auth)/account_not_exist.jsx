import React from 'react';
import { View, Text, StyleSheet, Alert, Image, TouchableOpacity } from 'react-native';
import { getAuth, deleteUser } from 'firebase/auth'; 
import { useNavigation } from '@react-navigation/native'; 

const NoBusinessDataPage = () => {
  const navigation = useNavigation(); 

  const handleDeleteAccount = async () => {
    
    Alert.alert(
      'Are you sure?',
      'This action cannot be undone. Do you really want to delete your account?',
      [
        {
          text: 'Cancel', 
          style: 'cancel' 
        },
        {
          text: 'Yes, Delete',
          onPress: async () => {
            try {
              const auth = getAuth();
              await deleteUser(auth.currentUser); 
              Alert.alert('Account Deleted', 'Your account has been successfully deleted.');

              
              navigation.replace('(auth)/login'); 
            } catch (error) {
              console.error('Error deleting account: ', error);
              Alert.alert('Error', 'There was an issue deleting your account.');
            }
          }
        }
      ]
    );
  };

  return (
    <View style={styles.container}>
      <View style={styles.card}>
        <Image
          source={require('../../assets/images/taskorbit.png')} 
          style={styles.image}
        />
        <Text style={styles.title}>We Could Not Find Your User Data</Text>
        <Text style={styles.message}>
          It seems like your user data is no longer available. You might have been removed from your business.
          If you'd like to delete your account permanently, please click the button below.
        </Text>
        
        <TouchableOpacity style={styles.deleteButton} onPress={handleDeleteAccount}>
          <Text style={styles.deleteButtonText}>Delete My Account</Text>
        </TouchableOpacity>
        
        <Text style={styles.footer}>
          If you have any questions, feel free to contact support.
        </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#f1f5f9', 
  },
  card: {
    width: '90%',
    maxWidth: 350,
    backgroundColor: '#ffffff',
    borderRadius: 20,
    padding: 20,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 5,
  },
  image: {
    width: 120,
    height: 120,
    borderRadius: 60,
    marginBottom: 20,
  },
  title: {
    fontSize: 26,
    fontWeight: '700',
    color: '#333',
    marginBottom: 10,
    textAlign: 'center',
    fontFamily: 'AvenirNext-Bold',
  },
  message: {
    fontSize: 16,
    color: '#555',
    textAlign: 'center',
    marginBottom: 30,
    paddingHorizontal: 20,
    lineHeight: 24,
    fontFamily: 'AvenirNext-Regular',
  },
  deleteButton: {
    backgroundColor: '#ff4f4f',
    paddingVertical: 12,
    paddingHorizontal: 50,
    borderRadius: 30,
    marginBottom: 20,
    shadowColor: '#ff4f4f',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 5,
  },
  deleteButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '600',
    textAlign: 'center',
    fontFamily: 'AvenirNext-Bold',
  },
  footer: {
    fontSize: 14,
    color: '#888',
    textAlign: 'center',
    fontFamily: 'AvenirNext-Regular',
  }
});

export default NoBusinessDataPage;
