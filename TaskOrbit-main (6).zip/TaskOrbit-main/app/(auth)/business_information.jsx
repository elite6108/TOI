import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  Image,
  TouchableWithoutFeedback, Keyboard,
  StatusBar,
  ScrollView
} from 'react-native';
import MapView, { Marker } from 'react-native-maps';
import Geolocation from 'react-native-geolocation-service';
import { GooglePlacesAutocomplete } from 'react-native-google-places-autocomplete';
import { LinearGradient } from 'expo-linear-gradient';
import { Dropdown } from 'react-native-element-dropdown';
import { firestore } from '../(api)/firebase';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { Alert } from 'react-native';
import axios from 'axios'; 
import Constants from 'expo-constants';

export default function BusinessSetup({ route, navigation }) {
  const { name, email, password } = route.params;
  const [businessName, setbusinessName] = useState('');
  const [businessDBAName, setbusinessDBAName] = useState('');
  const [businessAddress, setBusinessAddress] = useState('');
  const [businessIndustry, setBusinessIndustry] = useState(null);
  const [mapVisible, setMapVisible] = useState(false);
  const [currentLocation, setCurrentLocation] = useState(null);
  const [coordinates, setCoordinates] = useState(null);
  const [inputErrors, setInputErrors] = useState({
    businessName: false,
    businessDBAName: false,
    businessAddress: false,
    businessIndustry: false,
  });

  const industryOptions = [
    { label: 'Construction', value: 'Construction' },
    { label: 'Hospitality', value: 'Hospitality' },
    { label: 'Retail', value: 'Retail' },
    { label: 'Healthcare', value: 'Healthcare' },
    { label: 'Real Estate', value: 'Real Estate' },
    { label: 'Manufacturing', value: 'Manufacturing' },
    { label: 'Education', value: 'Education' },
    { label: 'Transportation and Logistics', value: 'Transportation and Logistics' },
    { label: 'Information Technology (IT)', value: 'Information Technology (IT)' },
    { label: 'Finance and Banking', value: 'Finance and Banking' },
    { label: 'Food and Beverage', value: 'Food and Beverage' },
    { label: 'Entertainment and Media', value: 'Entertainment and Media' },
    { label: 'Telecommunications', value: 'Telecommunications' },
    { label: 'Automotive', value: 'Automotive' },
    { label: 'Energy and Utilities', value: 'Energy and Utilities' },
    { label: 'Professional Services', value: 'Professional Services' },
    { label: 'Non-Profit and Charities', value: 'Non-Profit and Charities' },
    { label: 'Agriculture', value: 'Agriculture' },
    { label: 'Cleaning and Maintenance', value: 'Cleaning and Maintenance' },
    { label: 'Personal Services', value: 'Personal Services' },
    { label: 'Government and Public Sector', value: 'Government and Public Sector' },
    { label: 'Marketing and Advertising', value: 'Marketing and Advertising' },
    { label: 'Architecture and Engineering', value: 'Architecture and Engineering' },
    { label: 'Insurance', value: 'Insurance' },
    { label: 'Event Planning', value: 'Event Planning' },
    { label: 'Security Services', value: 'Security Services' },
    { label: 'Wholesale and Distribution', value: 'Wholesale and Distribution' },
    { label: 'Environmental Services', value: 'Environmental Services' },
    { label: 'Aerospace and Defense', value: 'Aerospace and Defense' },
  ];

  useEffect(() => {
    Geolocation.getCurrentPosition(
      position => {
        const { latitude, longitude } = position.coords;
        setCurrentLocation({
          latitude,
          longitude,
          latitudeDelta: 0.01,
          longitudeDelta: 0.01,
        });
      },
      error => console.log('Could not get location'),
      { enableHighAccuracy: true, timeout: 20000, maximumAge: 1000 }
    );
  }, []);

  
  const handleAddressSearch = async (address) => {
    setBusinessAddress(address)
    if (!address) return;
    try {
      const response = await axios.get(`https://maps.googleapis.com/maps/api/geocode/json`, {
        params: {
          address: address,
          key: Constants.expoConfig.extra.google.apiKey,
        },
      });

      const results = response.data.results;
      if (results.length > 0) {
        const { lat, lng } = results[0].geometry.location;
        setCoordinates({ latitude: lat, longitude: lng });
        setBusinessAddress(address);
        setMapVisible(true);
      } else {
        Alert.alert('Error', 'No results found for this address');
      }
    } catch (error) {
      console.log(error)
      Alert.alert('Error', 'Failed to fetch address details');
    }
  };

  const handleAddressConfirm = () => {
    if (!coordinates) {
      Alert.alert('Error', 'Please select a valid address');
      return;
    }
    setMapVisible(false);
    
  };

  return (
    <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
      <KeyboardAvoidingView
        style={styles.container}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        <StatusBar barStyle="dark-content" backgroundColor="#ffffff" />
        <Image
          source={require('../../assets/images/taskorbit.png')}
          style={styles.logo}
          resizeMode="contain"
        />

        <Text style={styles.headerText}>
          <Text style={styles.blueText}>Let’s get your business setup!</Text>
          {"\n\n"}
          <Text style={styles.blackText}>Tell us more about your business.</Text>
        </Text>

        <ScrollView style={{flex:1,height:'100%'}} keyboardShouldPersistTaps='handled'>
          <View style={styles.inputContainer}>
            <Text style={styles.labelText}>Legal Business Name*</Text>
            <TextInput
              placeholder="Enter your legal business name"
              placeholderTextColor="#9698a0"
              style={[styles.input, { borderColor: inputErrors.businessName ? 'red' : '#dcdcdc' }]}
              value={businessName}
              onChangeText={setbusinessName}
            />
          </View>

          <View style={styles.inputContainer}>
            <Text style={styles.labelText}>DBA Name</Text>
            <TextInput
              placeholder="Enter your DBA name"
              placeholderTextColor="#9698a0"
              style={[styles.input, { borderColor: inputErrors.businessDBAName ? 'red' : '#dcdcdc' }]}
              value={businessDBAName}
              onChangeText={setbusinessDBAName}
            />
          </View>

          <View style={styles.inputContainer}>
            <Text style={styles.labelText}>Business Industry*</Text>
            <Dropdown
              style={[styles.input, { borderColor: inputErrors.businessIndustry ? 'red' : '#dcdcdc' }]}
              data={industryOptions}
              labelField="label"
              valueField="value"
              placeholder="Select an industry"
              value={businessIndustry}
              onChange={(item) => setBusinessIndustry(item.value)}
              placeholderStyle={styles.placeholderStyle}
              selectedTextStyle={styles.selectedTextStyle}
              containerStyle={styles.dropdownContainer}
            />
          </View>

          {/* Address Input */}
          <View style={styles.inputContainer}>
            <Text style={styles.labelText}>Business Address</Text>
<GooglePlacesAutocomplete
  placeholder="Search for your business address"
  minLength={2}  
  autoFocus={false}
  returnKeyType={'search'}
  fetchDetails={true}
  onPress={(data, details = null) => {
    setBusinessAddress(data.description);
    setCoordinates({
      latitude: details.geometry.location.lat,
      longitude: details.geometry.location.lng
    });
    setMapVisible(true);
  }}
  query={{
    key: Constants.expoConfig.extra.google.apiKey,
    language: 'en', 
  }}
  styles={{
    textInput: styles.inputLocation,
    description: {
      fontSize: 14,
      color: '#000',
    },
    predefinedPlacesDescription: {
      color: '#1faadb',
    },
  }}
/>
          </View>

          {mapVisible && currentLocation && coordinates && (
            <View style={styles.mapContainer}>
              <TouchableOpacity onPress={handleAddressConfirm} style={styles.confirmButton}>
                <Text style={styles.confirmButtonText}>Confirm Address</Text>
              </TouchableOpacity>
            </View>
          )}
        </ScrollView>

          {/* Confirm Business Info Button */}
          <View style={styles.buttonContainer}>
            <LinearGradient
              colors={['#2196f3', '#21cbf3']}
              start={{ x: 1, y: 0 }}
              end={{ x: 0, y: 0 }}
              style={styles.confirmButton}
            >
              <TouchableOpacity
                onPress={async () => {
                  let hasErrors = false;
                  const newErrors = {
                    businessName: businessName === '',
                    businessIndustry: !businessIndustry,
                  };

                  setInputErrors(newErrors);

                  Object.values(newErrors).forEach((error) => {
                    if (error) hasErrors = true;
                  });

                  if (hasErrors) return;

                  const businessQuery = query(
                    collection(firestore, 'Businesses'),
                    where('name', '==', businessName)
                  );
                  const businessSnapshot = await getDocs(businessQuery);

                  if (!businessSnapshot.empty) {
                    Alert.alert('Business Exists', 'Please choose a different business name.');
                    return;
                  }

                  navigation.replace('(auth)/role_setup', {
                    name,
                    email,
                    password,
                    businessName,
                    businessDBAName,
                    businessIndustry,
                    businessAddress,
                  });
                }}
              >
                <Text style={styles.confirmButtonText}>Confirm business information</Text>
              </TouchableOpacity>
            </LinearGradient>
          </View>
      </KeyboardAvoidingView>
    </TouchableWithoutFeedback>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    justifyContent: 'flex-start',
  },
  logo: {
    width: '100%',
    marginTop: 20,
    height: 150,
  },
  headerText: {
    fontWeight: 'bold',
    marginBottom: 20,
  },
  blueText: {
    fontSize: 25,
    color: '#2196f3',
  },
  blackText: {
    fontSize: 20,
    color: 'black',
  },
  inputContainer: {
    width: '100%',
    marginBottom: 0,
  },
  labelText: {
    alignSelf: 'flex-start',
    fontSize: 14,
    fontWeight: 'bold',
    color: '#000',
    paddingLeft: 10,
    marginBottom: 5,
  },
  input: {
    width: '100%',
    borderWidth: 1,
    borderColor: '#dcdcdc',
    borderRadius: 10,
    padding: 15,
    backgroundColor: 'transparent',
    marginBottom: 20,
  },
  inputLocation: {
    width: '100%',
    borderWidth: 1,
    borderColor: '#dcdcdc',
    borderRadius: 10,
    padding: 15,
    backgroundColor: 'transparent',
    marginBottom: 0,
  },
  placeholderStyle: {
    color: '#9698a0',
  },
  selectedTextStyle: {
    color: '#000',
  },
  dropdownContainer: {
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#dcdcdc',
  },
  buttonContainer: {
    position: 'absolute',
    bottom: 20,
    left: 0,
    right: 0,
    paddingHorizontal: 20,
  },  
  confirmButton: {
    borderRadius: 10,
    padding: 15,
    flex: 2,
  },
  confirmButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  addressButton: {
    backgroundColor: '#2196f3',
    borderRadius: 10,
    padding: 15,
    alignItems: 'center',
    marginVertical: 10,
  },
  addressButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  mapContainer: {
    height: 200,
    marginTop: 0,
    borderRadius: 10,
    overflow: 'hidden',
  },
  addressInput: {
    padding: 15,
    borderColor: '#dcdcdc',
    borderWidth: 1,
    borderRadius: 10,
    marginTop: 10,
    backgroundColor: '#fff',
  },
  confirmButton: {
    backgroundColor: '#21cbf3',
    borderRadius: 10,
    padding: 15,
    alignItems: 'center',
    marginTop: 10,
  },
  confirmButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
});
