import React, { useEffect, useState } from 'react';
import { View, Image, StyleSheet, StatusBar, Animated } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getAuth, signInWithEmailAndPassword } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { firestore } from '../(api)/firebase';

const CheckForLogin = ({ navigation }) => {
  const [fadeAnim] = useState(new Animated.Value(1));

  useEffect(() => {
    const checkAutoLogin = async () => {
      try {
        const storedCredentials = await AsyncStorage.getItem('userCredentials');

        if (storedCredentials) {
          const { email, password } = JSON.parse(storedCredentials);

          const auth = getAuth();
          const userCredential = await signInWithEmailAndPassword(auth, email, password);

          if (userCredential) {
            const user = userCredential.user;
            const userDocRef = doc(firestore, 'Users', user.uid);
            const userDoc = await getDoc(userDocRef);

            if (userDoc.exists()) {
              const userData = userDoc.data();
              console.log('User businessId:', userData.businessId);
              console.log('User role:', userData.role);
              console.log('User Fullname:', userData.fullName);

              await AsyncStorage.setItem('userData', JSON.stringify(userData));

              fadeOutAndNavigate('BottomTabs');
            } else {
              console.log('No user document found!');
              fadeOutAndNavigate('(auth)/account_not_exist');
            }
          } else {
            fadeOutAndNavigate('(auth)/login');
          }
        } else {
          fadeOutAndNavigate('(auth)/login');
        }
      } catch (error) {
        console.log('Auto-login failed:', error.message);
        fadeOutAndNavigate('(auth)/login');
      }
    };

    setTimeout(checkAutoLogin, 2000);

  }, []);

  const fadeOutAndNavigate = (route) => {
    Animated.timing(fadeAnim, {
      toValue: 0,
      duration: 1000,
      useNativeDriver: true,
    }).start(() => {
      navigation.replace(route);
    });
  };

  return (
    <Animated.View style={[styles.container, { opacity: fadeAnim }]}>
      <StatusBar barStyle="dark-content" backgroundColor="#ffffff" />
      <Image
        source={require('../../assets/images/taskorbit.png')}
        style={styles.logo}
      />
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
    justifyContent: 'center',
    alignItems: 'center',
  },
  logo: {
    width: 200,
    height: 200,
  },
});

export default CheckForLogin;
