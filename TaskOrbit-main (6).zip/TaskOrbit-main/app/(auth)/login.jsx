import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Image,
  KeyboardAvoidingView,
  Platform,
  Alert,
  TouchableWithoutFeedback,
  Keyboard,
  StatusBar,
  ScrollView
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { auth, firestore } from '../(api)/firebase';
import { doc, getDoc } from 'firebase/firestore';
import AsyncStorage from '@react-native-async-storage/async-storage';
import i18n from "@/app/localization";

export default function LoginScreen({ navigation }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [passwordVisible, setPasswordVisible] = useState(false);

  const handleLogin = () => {
    if (!email || !password) {
      Alert.alert("Error", "Please enter both email and password.");
      return;
    }

    signInWithEmailAndPassword(auth, email, password)
      .then(async (userCredential) => {
        const user = userCredential.user;
        const userDocRef = doc(firestore, 'Users', user.uid);
        const userDoc = await getDoc(userDocRef);

        if (userDoc.exists()) {
          const userData = userDoc.data();
          console.log('User businessId:', userData.businessId);
          console.log('User role:', userData.role);
          console.log('User Fullname:', userData.fullName);


          await AsyncStorage.setItem('userCredentials', JSON.stringify({
            email,
            password,
            uid: user.uid,
          }));

          navigation.replace('BottomTabs');
        } else {
          navigation.replace('(auth)/account_not_exist');
          console.log('No user data found!');
        }
      })
      .catch((error) => {
        const errorMessage = error.message;
        Alert.alert("Login Error", 'Incorrect username or password.');
      });
  };

  return (
    <TouchableWithoutFeedback onPress={Platform.OS !== 'web' ? Keyboard.dismiss : null}>
      <KeyboardAvoidingView
        style={styles.container}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        contentContainerStyle={{ flexGrow: 1 }}
      >
        <StatusBar barStyle="light-content" backgroundColor="#ffffff" />
        <ScrollView contentContainerStyle={styles.scrollView} showsVerticalScrollIndicator={false}>
        <Image
          source={require('../../assets/images/taskorbit.png')}
          style={styles.icon}
        />
        <View style={styles.inputContainer}>
          <Text style={styles.headerText}>{i18n.t('auth.login')}</Text>
        </View>

        <View style={styles.inputContainer}>
          <Text style={styles.subText}>Start your 30-day free trial.</Text>
        </View>

        <View style={styles.inputContainer}>
          <Text style={styles.labelText}>Email*</Text>
        </View>

        <View style={styles.inputContainer}>
        <TextInput
          placeholder="Enter your e-mail"
          placeholderTextColor="#9698a0"
          style={styles.input}
          value={email}
          onChangeText={setEmail}
          keyboardType="email-address"
          importantForAutofill='no'
          autoComplete={'off'}
          autoCorrect={false}
          autoCapitalize="none"
        />
        </View>

        <View style={styles.inputContainer}>
          <Text style={styles.labelText}>Password*</Text>
        </View>
        <View style={styles.passwordInputContainer}>
          <TextInput
            placeholder="Enter your password"
            placeholderTextColor="#9698a0"
            secureTextEntry={!passwordVisible}
            style={styles.passwordInput}
            value={password}
            onChangeText={setPassword}
            autoCapitalize="none"
          />
          <TouchableOpacity
            onPress={() => setPasswordVisible(!passwordVisible)}
            style={styles.eyeIconContainer}
          >
            <Ionicons
              name={passwordVisible ? 'eye-off' : 'eye'}
              size={24}
              color="gray"
            />
          </TouchableOpacity>
        </View>

        <View style={styles.resetTextContainer}>
          <Text style={styles.alreadyText}>Forgot password? </Text>
          <TouchableOpacity onPress={() => navigation.navigate('(auth)/reset_password')}>
            <Text style={styles.loginText}>Reset here!</Text>
          </TouchableOpacity>
        </View>

        <TouchableOpacity style={styles.getStartedButton} onPress={handleLogin}>
          <Text style={styles.getStartedText}>Login</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.socialButton} onPress={() => navigation.replace('(app)/employeeScanner')}>
  <View style={styles.socialButtonContent}>
    <Ionicons name="location-outline" size={20} color="#2196f3" style={styles.socialIcon} />
    <Text style={styles.socialButtonText}>Connect to location</Text>
  </View>
</TouchableOpacity>


        <TouchableOpacity style={styles.socialButton}>
          <View style={styles.socialButtonContent}>
            <Image
              source={require('../../assets/icons/google.jpeg')}
              style={styles.socialIcon}
            />
            <Text style={styles.socialButtonText}>Log in with Google</Text>
          </View>
        </TouchableOpacity>

        <TouchableOpacity style={styles.socialButton}>
          <View style={styles.socialButtonContent}>
            <Image
              source={require('../../assets/icons/apple.jpeg')}
              style={styles.socialIcon}
            />
            <Text style={styles.socialButtonText}>Log in with Apple</Text>
          </View>
        </TouchableOpacity>

        <TouchableOpacity style={styles.socialButton} onPress={() => navigation.replace('(auth)/register')}>
          <View style={styles.socialButtonContent}>
          <Ionicons name="copy-outline" size={20} color="#2196f3" style={styles.socialIcon} />
            <Text style={styles.socialButtonText}>Get started</Text>
          </View>
        </TouchableOpacity>
        </ScrollView>
      </KeyboardAvoidingView>
    </TouchableWithoutFeedback>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
    justifyContent: 'center',
    alignItems: 'stretch',
    padding: 20,
    maxHeight: '100vh',
  },
  scrollView: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  icon: {
    width: 150,
    height: 150,
  },
  headerText: {
    alignSelf: 'flex-start',
    fontSize: 25,
    fontWeight: 'bold',
    color: '#2196f3',
    paddingLeft: 10,
    marginBottom: 10,
  },
  inputContainer: {
    width: '100%',
    marginBottom: 0,
  },
  subText: {
    alignSelf: 'flex-start',
    fontSize: 14,
    color: '#000',
    paddingLeft: 10,
    marginBottom: 20,
  },
  labelText: {
    alignSelf: 'flex-start',
    fontSize: 14,
    fontWeight: 'bold',
    color: '#000',
    paddingLeft: 10,
    marginBottom: 5,
  },
  input: {
    width: '100%',
    borderWidth: 1,
    borderColor: '#dcdcdc',
    borderRadius: 10,
    padding: 15,
    backgroundColor: 'transparent',
    marginBottom: 20,
  },
  passwordInputContainer: {
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#dcdcdc',
    borderRadius: 10,
    marginBottom: 20,
  },
  passwordInput: {
    flex: 1,
    padding: 15,
    backgroundColor: 'transparent',
  },
  eyeIconContainer: {
    paddingRight: 15,
  },
  getStartedButton: {
    width: '100%',
    backgroundColor: '#2196f3',
    borderRadius: 10,
    paddingVertical: 15,
    alignItems: 'center',
    marginBottom: 10,
  },
  getStartedText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  socialButton: {
    width: '100%',
    borderRadius: 10,
    paddingVertical: 15,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#2196f3',
    marginBottom: 10,
    backgroundColor: 'transparent',
  },
  socialButtonContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  socialIcon: {
    width: 20,
    height: 20,
    marginRight: 10,
  },
  socialButtonText: {
    color: 'black',
    fontSize: 16,
    fontWeight: 'bold',
  },
  loginTextContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 10,
  },
  resetTextContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  alreadyText: {
    fontSize: 14,
    color: '#9698a0',
  },
  loginText: {
    fontSize: 14,
    color: '#2196f3',
  },
});
