import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Image, KeyboardAvoidingView, Platform, Alert, Keyboard, TouchableWithoutFeedback, StatusBar } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { fetchSignInMethodsForEmail, OAuthProvider, signInWithCredential } from 'firebase/auth';
import { firestore, auth } from '../(api)/firebase';

export default function RegisterScreen({ navigation }) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [passwordVisible, setPasswordVisible] = useState(false);
  const [inputBorders, setInputBorders] = useState({
    name: '#dcdcdc',
    email: '#dcdcdc',
    password: '#dcdcdc',
  });  

  const handleRegister = async () => {
    
    if (!name.trim() || !email.trim() || !password.trim()) {
      setInputBorders({
        name: !name.trim() ? 'red' : '#dcdcdc',
        email: !email.trim() ? 'red' : '#dcdcdc',
        password: !password.trim() ? 'red' : '#dcdcdc',
      });
      return;  
    }
  
    try {
      const normalizedEmail = email.trim().toLowerCase();
      console.log('Checking normalized email:', normalizedEmail);
  
      const signInMethods = await fetchSignInMethodsForEmail(auth, normalizedEmail);
      if (signInMethods.length > 0) {
        Alert.alert('User Exists', 'An account with this email already exists.');
        return;
      }
  
      navigation.replace('(auth)/business_information', {
        name,
        email: normalizedEmail,
        password,
      });
    } catch (error) {
      console.error('Error during registration:', error);
      Alert.alert('Error', 'An error occurred during registration. Please try again.');
    }
  };

  const handleAppleSignIn = async () => {
    // try {
    //   const appleAuthRequestResponse = await AppleAuthentication.signInAsync({
    //     requestedScopes: [
    //       AppleAuthentication.AppleAuthenticationScope.FULL_NAME,
    //       AppleAuthentication.AppleAuthenticationScope.EMAIL,
    //     ],
    //   });
  
    //   const { identityToken, email, fullName } = appleAuthRequestResponse;
      
      
    //   if (email) {
    //     const normalizedEmail = email.trim().toLowerCase();
  
        
    //     const signInMethods = await fetchSignInMethodsForEmail(auth, normalizedEmail);
    //     if (signInMethods.length > 0) {
    //       Alert.alert('User already exists', 'An account with this email already exists.');
    //       return;
    //     }
    //   }
  
    //   const provider = new OAuthProvider('apple.com');
    //   const credential = provider.credential({
    //     idToken: identityToken,
    //   });
  
      
    //   const userCredential = await signInWithCredential(auth, credential);
  
      
    //   if (userCredential.additionalUserInfo?.isNewUser) {
    //     handleRegister(); 
    //   } else {
    //     Alert.alert('User already exists', 'You are already registered.');
    //   }
  
    // } catch (error) {
    //   console.error('Error with Apple sign in:', error);
    //   Alert.alert('Apple Sign-In Error', 'There was a problem with Apple Sign-In. Please try again.');
    // }
  };  

  return (
    <TouchableWithoutFeedback onPress={Platform.OS !== 'web' ? Keyboard.dismiss : null} accessible={false}>
      <KeyboardAvoidingView
        style={styles.container}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        <StatusBar barStyle="dark-content" backgroundColor="#ffffff" />
        <Image 
          source={require('../../assets/images/taskorbit.png')} 
          style={styles.icon} 
        />
        
        <View style={styles.inputContainer}>
          <Text style={styles.headerText}>Sign Up Your Business</Text>
        </View>
        
        <View style={styles.inputContainer}>
          <Text style={styles.subText}>Start your 30-day free trial.</Text>
        </View>
  
        <View style={styles.inputContainer}>
          <Text style={styles.labelText}>Name*</Text>
        </View>
        <TextInput
          placeholder="Enter your full name"
          placeholderTextColor="#9698a0"
          style={[styles.input, { borderColor: inputBorders.name }]}
          value={name}
          onChangeText={setName}
        />
        
        <View style={styles.inputContainer}>
          <Text style={styles.labelText}>Email*</Text>
        </View>
        <TextInput
          placeholder="Enter your e-mail"
          placeholderTextColor="#9698a0"
          value={email}
          onChangeText={setEmail}
          style={[styles.input, { borderColor: inputBorders.email }]}
          keyboardType="email-address"
          importantForAutofill="no"
          autoComplete="email"
          autoCorrect={false}
          autoCapitalize="none"
        />
  
        <View style={styles.inputContainer}>
          <Text style={styles.labelText}>Password*</Text>
        </View>
        <View style={[styles.passwordInputContainer, { borderColor: inputBorders.password }]}>
          <TextInput
            placeholder="Enter a password"
            placeholderTextColor="#9698a0"
            secureTextEntry={!passwordVisible}
            style={styles.passwordInput}
            value={password}
            onChangeText={setPassword}
          />
          <TouchableOpacity
            onPress={() => setPasswordVisible(!passwordVisible)}
            style={styles.eyeIconContainer}
          >
            <Ionicons
              name={passwordVisible ? 'eye-off' : 'eye'}
              size={24}
              color="gray"
            />
          </TouchableOpacity>
        </View>
  
        <TouchableOpacity style={styles.getStartedButton} onPress={handleRegister}>
          <Text style={styles.getStartedText}>Get Started</Text>
        </TouchableOpacity>
  
        <TouchableOpacity style={styles.socialButton}>
          <View style={styles.socialButtonContent}>
            <Image
              source={require('../../assets/icons/google.jpeg')}
              style={styles.socialIcon}
            />
            <Text style={styles.socialButtonText}>Sign up with Google</Text>
          </View>
        </TouchableOpacity>
  
        <TouchableOpacity style={styles.socialButton} onPress={handleAppleSignIn}>
  <View style={styles.socialButtonContent}>
    <Image
      source={require('../../assets/icons/apple.jpeg')}
      style={styles.socialIcon}
    />
    <Text style={styles.socialButtonText}>Sign up with Apple</Text>
  </View>
</TouchableOpacity>
  
        <View style={styles.loginTextContainer}>
          <Text style={styles.alreadyText}>Already have an account? </Text>
          <TouchableOpacity onPress={() => navigation.replace('(auth)/login')}>
            <Text style={styles.loginText}>Log in</Text>
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </TouchableWithoutFeedback>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: 'white',
    alignItems: 'center',
    padding: 20,
  },
  icon: {
    width: 150,
    height: 150,
  },
  headerText: {
    alignSelf: 'flex-start',
    fontSize: 25,
    fontWeight: 'bold',
    color: '#2196f3',
    paddingLeft: 10,
    marginBottom: 10,
  },
  inputContainer: {
    width: '100%',
    marginBottom: 0,
  },
  subText: {
    alignSelf: 'flex-start',
    fontSize: 14,
    color: '#000',
    paddingLeft: 10,
    marginBottom: 20,
  },
  labelText: {
    alignSelf: 'flex-start',
    fontSize: 14,
    fontWeight: 'bold',
    color: '#000',
    paddingLeft: 10,
    marginBottom: 5,
  },
  input: {
    width: '100%',
    borderWidth: 1,
    borderColor: '#dcdcdc',
    borderRadius: 10,
    padding: 15,
    backgroundColor: 'transparent',
    marginBottom: 20,
  },
  passwordInputContainer: {
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#dcdcdc',
    borderRadius: 10,
    marginBottom: 20,
  },
  passwordInput: {
    flex: 1,
    padding: 15,
    backgroundColor: 'transparent',
  },
  eyeIconContainer: {
    paddingRight: 15,
  },
  getStartedButton: {
    width: '100%',
    backgroundColor: '#2196f3',
    borderRadius: 10,
    paddingVertical: 15,
    alignItems: 'center',
    marginBottom: 10,
  },
  getStartedText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  socialButton: {
    width: '100%',
    borderRadius: 10,
    paddingVertical: 15,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#2196f3',
    marginBottom: 10,
    backgroundColor: 'transparent',
  },
  socialButtonContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  socialIcon: {
    width: 20,
    height: 20,
    marginRight: 10,
  },
  socialButtonText: {
    color: 'black',
    fontSize: 16,
    fontWeight: 'bold',
  },
  loginTextContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 20,
  },
  alreadyText: {
    fontSize: 14,
    color: '#9698a0',
  },
  loginText: {
    fontSize: 14,
    color: '#2196f3',
  },
});
