import React, { useState } from 'react';
import { SafeAreaView, Text, TextInput, TouchableOpacity, Image, StyleSheet, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons'; 
import { getAuth, sendPasswordResetEmail } from 'firebase/auth';

const PasswordResetScreen = ({ navigation }) => {
  const [email, setEmail] = useState('');
  const [emailSent, setEmailSent] = useState(false);

  const handlePasswordReset = () => {
    if (!email) {
      alert('Please enter your email address.');
      return;
    }
  
    const auth = getAuth();
    sendPasswordResetEmail(auth, email)
      .then(() => {
        setEmailSent(true);
      })
      .catch((error) => {
        console.error('Error sending password reset email:', error);
        switch (error.code) {
          case 'auth/invalid-email':
            alert('Invalid email address format.');
            break;
          case 'auth/user-not-found':
            alert('No user found with this email.');
            break;
          default:
            alert('An error occurred. Please try again.');
        }
      });
  };  

  return (
    <SafeAreaView style={styles.container}>
      {/* Back Button */}
      <TouchableOpacity
        style={styles.backButton}
        onPress={() => navigation.goBack()}
      >
        <Ionicons name="arrow-back" size={24} color="#000" />
      </TouchableOpacity>

      {/* Logo */}
      <Image
        source={require('../../assets/images/taskorbit.png')}
        style={styles.logo}
        resizeMode="contain"
      />

      {/* Title */}
      <Text style={styles.title}>Reset Password</Text>

      {/* Instruction */}
      <Text style={styles.instruction}>
        This reset option is designed for business owners only. If you are an employee, please contact your business admin to assist with resetting your password.
      </Text>

      {/* Email Input */}
      <TextInput
  placeholder="Enter your e-mail"
  placeholderTextColor="#9698a0"
  style={[styles.input, emailSent && styles.inputDisabled]}
  value={email}
  onChangeText={setEmail}
  keyboardType="email-address"
  importantForAutofill="no"
  autoComplete="off"
  autoCorrect={false}
  autoCapitalize="none"
  editable={!emailSent}
/>

{emailSent && (
  <Text style={styles.successMessage}>
    A password reset email has been sent to {email}. Please check your inbox and follow the instructions to reset your password.
  </Text>
)}

{/* Reset Password Button */}
{!emailSent && (
  <TouchableOpacity style={styles.getStartedButton} onPress={handlePasswordReset}>
    <Text style={styles.getStartedText}>Reset Password</Text>
  </TouchableOpacity>
)}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    padding: 20,
  },
  backButton: {
    position: 'absolute',
    top: 50, 
    left: 25,
    zIndex: 10,
  },
  logo: {
    width: 150,
    height: 150,
    alignSelf: 'center',
    marginTop: 40,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginTop: 20,
    color: '#333',
  },
  instruction: {
    fontSize: 16,
    textAlign: 'center',
    color: '#555',
    marginVertical: 20,
    paddingHorizontal: 10,
  },
  input: {
    width: '95%',
    borderWidth: 1,
    borderColor: '#dcdcdc',
    borderRadius: 10,
    padding: 15,
    backgroundColor: 'transparent',
    marginBottom: 20,
  },
  getStartedButton: {
    width: '95%',
    backgroundColor: '#2196f3',
    borderRadius: 10,
    paddingVertical: 15,
    alignItems: 'center',
    marginBottom: 10,
  },
  getStartedText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  inputDisabled: {
    backgroundColor: '#f0f0f0',
    color: '#999',
  },
  successMessage: {
    color: 'green',
    fontSize: 14,
    marginTop: 10,
    textAlign: 'center',
  },
});

export default PasswordResetScreen;
