import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Modal,
  Image,
  KeyboardAvoidingView,
  Platform,
  StatusBar
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { auth, firestore } from '../(api)/firebase';

export default function RoleSetup({ route }) {
  const navigation = useNavigation();
  const { name, email, password, businessName, businessDBAName, businessIndustry, businessAddress } = route.params;
  const [roles, setRoles] = useState([{ name: 'Admin', color: '#dcdcdc' }]);
  const [isColorPickerVisible, setIsColorPickerVisible] = useState(false);
  const [selectedRoleIndex, setSelectedRoleIndex] = useState(null);
  const colors = ['#ff0000', '#00ff00', '#0000ff', '#ff00ff', '#00ffff', '#ffff00'];

  const addRole = () => {
    setRoles([...roles, { name: 'New role', color: '#dcdcdc' }]);
  };

  const handleRoleChange = (index, value) => {
    const updatedRoles = [...roles];
    updatedRoles[index].name = value;
    setRoles(updatedRoles);
  };

  const openColorPicker = (index) => {
    setSelectedRoleIndex(index);
    setIsColorPickerVisible(true);
  };

  const selectColor = (color) => {
    if (selectedRoleIndex !== null) {
      const updatedRoles = [...roles];
      updatedRoles[selectedRoleIndex].color = color;
      setRoles(updatedRoles);
      setIsColorPickerVisible(false);
    }
  };

  const confirmRoleCreation = () => {
    navigation.replace('(auth)/task_setup', {
      name,
      email,
      password,
      roles,
      businessName,
      businessDBAName,
      businessIndustry,
      businessAddress,
    });
  };

  const confirmBusinessCreation = async () => {
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;
      const userId = user.uid;

      const businessId = userId;

      const businessData = {
        name: businessName,
        dbaName: businessDBAName || '',
        businessIndustry: businessIndustry,
        businessAddress: businessAddress,
        owner: userId,
        createdAt: serverTimestamp(),
        roles: roles.map((role) => ({ name: role.name, color: role.color })),
      };

      console.log('Business Data:', businessData);
      await setDoc(doc(firestore, 'Businesses', businessId), businessData);

      const userData = {
        email: user.email,
        associatedSince: serverTimestamp(),
        fullName: name,
        assignedRoles: roles.map((role) => role.name),
        hasSuperAdmin: true,
    };

      await setDoc(doc(firestore, 'Businesses', businessId, 'Users', userId), userData);

      await setDoc(doc(firestore, 'Users', userId), {
          ...userData,
          businessId: businessId,
      });
      navigation.replace('BottomTabs');
      console.log('Business setup complete!');
  } catch (error) {
      console.error("Error creating user or setting up business: ", error);
  }
};

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <StatusBar barStyle="dark-content" backgroundColor="#ffffff" />
      <Image
        source={require('../../assets/images/taskorbit.png')}
        style={styles.logo}
        resizeMode="contain"
      />

      <Text style={styles.headerText}>
        <Text style={styles.blueText}>Let’s get your business setup!</Text>
        {"\n\n"}
        <Text style={styles.blackText}>Tell us what roles your business usually uses.</Text>
      </Text>

      <ScrollView style={styles.scrollView} contentContainerStyle={styles.scrollContent}>
        {roles.map((role, index) => (
          <View key={index} style={[styles.roleContainer, { borderColor: role.color }]}>
            <TouchableOpacity
              style={[styles.colorButton, { borderColor: role.color }]}
              onPress={() => openColorPicker(index)}
            >
              <MaterialIcons name="color-lens" size={20} color={role.color} />
            </TouchableOpacity>
            <TextInput
              style={styles.roleInput}
              value={role.name}
              onChangeText={(value) => handleRoleChange(index, value)}
            />
          </View>
        ))}
        <TouchableOpacity style={styles.addButton} onPress={addRole}>
          <Text style={styles.addButtonText}>Add new role</Text>
        </TouchableOpacity>
      </ScrollView>

      <View style={styles.buttonRow}>
        <TouchableOpacity style={styles.skipButton}>
          <Text style={styles.skipButtonText} onPress={confirmBusinessCreation}>Skip for now</Text>
        </TouchableOpacity>

        <LinearGradient
          colors={['#2196f3', '#21cbf3']}
          start={{ x: 1, y: 0 }}
          end={{ x: 0, y: 0 }}
          style={styles.confirmButton}
        >
          <TouchableOpacity onPress={confirmRoleCreation}>
            <Text style={styles.confirmButtonText}>Confirm role creation</Text>
          </TouchableOpacity>
        </LinearGradient>
      </View>

      <Modal visible={isColorPickerVisible} transparent={true} animationType="slide">
        <View style={styles.modalContainer}>
          <View style={styles.colorPickerContainer}>
            {colors.map((color, idx) => (
              <TouchableOpacity
                key={idx}
                style={[styles.colorOption, { backgroundColor: color }]}
                onPress={() => selectColor(color)}
              />
            ))}
          </View>
        </View>
      </Modal>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    justifyContent: 'flex-start',
  },
  logo: {
    width: '100%',
    marginTop: 20,
    height: 150,
  },
  headerText: {
    fontWeight: 'bold',
    marginBottom: 20,
  },
  blueText: {
    fontSize: 25,
    color: '#2196f3',
  },
  blackText: {
    fontSize: 20,
    color: 'black',
  },
  scrollView: {
    flex: 1,
    marginBottom: 20,
  },
  scrollContent: {
    paddingBottom: 20,
  },
  roleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f0f0f0',
    borderRadius: 10,
    marginVertical: 5,
    padding: 10,
    borderWidth: 2,
  },
  roleInput: {
    flex: 1,
    fontSize: 16,
    height: 50,
    color: 'black',
    marginLeft: 10,
  },
  addButton: {
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: '#dcdcdc',
    borderRadius: 10,
    padding: 15,
    alignItems: 'center',
    marginVertical: 10,
    width: '100%',
  },
  addButtonText: {
    color: 'black',
    fontWeight: 'bold',
  },

  buttonRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },

  skipButton: {
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: '#dcdcdc',
    borderRadius: 10,
    padding: 15,
    alignItems: 'center',
    flex: 1,
    marginRight: 10,
  },
  skipButtonText: {
    color: '#2196f3',
    fontWeight: 'bold',
  },
  confirmButton: {
    borderRadius: 10,
    padding: 15,
    flex: 2,
  },
  confirmButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    textAlign: 'center',
  },

  colorButton: {
    width: 30,
    height: 30,
    borderRadius: 15,
    borderWidth: 2,
    justifyContent: 'center',
    alignItems: 'center',
  },

  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  colorPickerContainer: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 10,
    flexDirection: 'row',
    justifyContent: 'space-around',
    flexWrap: 'wrap',
  },
  colorOption: {
    width: 50,
    height: 50,
    borderRadius: 25,
    margin: 10,
  },
});
