import React, { useState, useEffect } from 'react';
import { SafeAreaView, View, Text, TextInput, StyleSheet, TouchableOpacity, Alert, Image, ScrollView, Modal, Platform } from 'react-native';
import DropDownPicker from 'react-native-dropdown-picker';
import { doc, getDoc, setDoc, query, collection, where, getDocs, deleteDoc } from 'firebase/firestore';
import { auth, firestore } from '../(api)/firebase';
import { useNavigation } from '@react-navigation/native';
import { LinearGradient } from 'expo-linear-gradient';
import { createUserWithEmailAndPassword, deleteUser, getAuth } from 'firebase/auth'; 
import moment from 'moment'; 
import MaterialIcons from 'react-native-vector-icons/MaterialIcons'
import Constants from 'expo-constants';
import CryptoJS from 'crypto-js';
import PermissionChecker from '../(api)/perm_check';

let CheckBox;
if (Platform.OS === 'web') {
  CheckBox = require('react-native-web').CheckBox;
} else {
  CheckBox = require('@react-native-community/checkbox').default;
}

const secretKey = Constants.expoConfig.extra.firebase.pinEncryptionKey; 

const CreateUserScreen = ( ) => {
  const userId = auth.currentUser.uid;
  const [isManagingEmployees, setIsManagingEmployees] = useState(true);
  const [employees, setEmployees] = useState([]); 
  const [email, setEmail] = useState('');
  const [fullName, setFullName] = useState('');
  const [pin, setPin] = useState('');
  const [employeeNumber, setEmployeeNumber] = useState(''); 
  const [roles, setRoles] = useState([]);
  const [selectedRoles, setSelectedRoles] = useState([]);
  const [businessId, setBusinessId] = useState(null);
  const [openRolePicker, setOpenRolePicker] = useState(false);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [isRemoveEmployeePopupVisible, setIsRemoveEmployeePopupVisible] = useState(false);
const [selectedEmployee, setSelectedEmployee] = useState(null);
const [isEditEmployeeInfoModalVisible, setIsEditEmployeeInfoModalVisible] = useState(false);
  const permissionEditEmployeesId = "edit_employee";
  const hasManageEmployeesPermission = PermissionChecker({
    permissionId: permissionEditEmployeesId,
  });

  const permissionAddEmployeesId = "add_employee";
  const hasAddEmployeesPermission = PermissionChecker({
    permissionId: permissionAddEmployeesId,
  });

  
  const [pushNotifications, setPushNotifications] = useState(false);
  const [emailNotifications, setEmailNotifications] = useState(false);

  const associatedSince = moment().format('YYYY-MM-DD');
  const navigation = useNavigation();

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const userDoc = await getDoc(doc(firestore, 'Users', userId));
        if (userDoc.exists()) {
          setBusinessId(userDoc.data().businessId);
        } else {
          console.log('No such document!');
        }
      } catch (error) {
        console.error('Error fetching user data: ', error);
      }
    };

    fetchUserData();
  }, [userId]);

  const handleEditEmployee = async () => {
    if (selectedEmployee) {
      try {
        await setDoc(doc(firestore, 'Users', selectedEmployee.id), {
          ...selectedEmployee,
          assignedRoles: selectedRoles,
          allowPushNotifications: pushNotifications,
          allowEmailNotifications: emailNotifications,
        });
        setSelectedRoles([]);
        setPushNotifications(false);
        setEmailNotifications(false);
        Alert.alert('Success', 'Employee information updated successfully!');
        setIsModalVisible(false); 
      } catch (error) {
        console.error('Error updating employee: ', error);
        Alert.alert('Error', 'There was an issue updating the employee.');
      }
    }
  };

  const handleRemoveEmployee = async () => {
    if (selectedEmployee) {
      try {
        const userDocRef = doc(firestore, 'Users', selectedEmployee.id);
        const userDoc = await getDoc(userDocRef);
  
        if (userDoc.exists()) {
          const userData = userDoc.data();
  
          if (userData.hasSuperAdmin === true) {
            
            Alert.alert('Error', 'This user is a Superadmin and cannot be deleted.');
            setIsRemoveEmployeePopupVisible(false);
            return;
          }
  
          
          await deleteDoc(userDocRef);
          setEmployees((prevEmployees) =>
            prevEmployees.filter((employee) => employee.id !== selectedEmployee.id)
          );
  
          
          const auth = getAuth();
          if (selectedEmployee.id === auth.currentUser?.uid) {
            await deleteUser(auth.currentUser);
          }
  
          Alert.alert('Success', `${selectedEmployee.fullName} has been removed.`);
          setIsRemoveEmployeePopupVisible(false);
          setIsModalVisible(false);
        }
  
      } catch (error) {
        console.error('Error removing employee: ', error);
        Alert.alert('Error', 'There was an issue removing the employee.');
      }
    }
  };

  const handleEditEmployeeInformation = async () => {
    if (selectedEmployee) {
      
      const updatedFields = {
        ...(email && { email }),
        ...(fullName && { fullName }),
        ...(employeeNumber && { employeeNumber }),
      };
  
      
      if (Object.keys(updatedFields).length > 0) {
        try {
          await setDoc(doc(firestore, 'Users', selectedEmployee.id), {
            ...selectedEmployee,
            ...updatedFields,
          });
  
          
          setEmail('');
          setFullName('');
          setEmployeeNumber('');
          Alert.alert('Success', 'Employee information updated successfully!');
          setIsEditEmployeeInfoModalVisible(false); 
        } catch (error) {
          console.error('Error updating employee: ', error);
          Alert.alert('Error', 'There was an issue updating the employee.');
        }
      } else {
        Alert.alert('No changes', 'Please enter values to update.');
      }
    }
  };  

  useEffect(() => {
    const fetchEmployees = async () => {
      if (isManagingEmployees && businessId) {
        try {
          const q = query(collection(firestore, 'Users'), where('businessId', '==', businessId));
          const querySnapshot = await getDocs(q);
          const employeeList = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
          
          
          employeeList.sort((a, b) => a.fullName.localeCompare(b.fullName));
    
          setEmployees(employeeList);
        } catch (error) {
          console.error('Error fetching employees: ', error);
        }
      }
    };    
  
    fetchEmployees();
  }, [isManagingEmployees, businessId]);

  useEffect(() => {
    const fetchRoles = async () => {
      if (businessId) {
        try {
          const businessDoc = await getDoc(doc(firestore, 'Businesses', businessId));
          if (businessDoc.exists()) {
            const businessRoles = businessDoc.data().roles;
            setRoles(businessRoles.map(role => ({
              label: role.name,  
              value: role.name   
            })));
          } else {
            console.log('No roles found for this business!');
          }
        } catch (error) {
          console.error('Error fetching roles: ', error);
        }
      }
    };

    fetchRoles();
  }, [businessId]);

  const handleCreateUser = async () => {
    if (!fullName || !pin || selectedRoles.length === 0) {
      Alert.alert('Error', 'Please fill out all fields and select at least one role.');
      return;
    }
  
    const employeeId = employeeNumber || `${Math.floor(100000000000 + Math.random() * 900000000000)}`;

    try {
      
      const randomPassword = Math.random().toString(36).slice(-8); 
      const encryptedRandomPass = CryptoJS.AES.encrypt(randomPassword, secretKey).toString();
      const usersId = `${Math.floor(100000000000 + Math.random() * 900000000000)}`;
      
      const userCredential = await createUserWithEmailAndPassword(auth, email, randomPassword);
      const user = userCredential.user;
      const userId = user.uid;      

      
      await setDoc(doc(firestore, 'Users', userId), {
        associatedSince: moment().format(),
        email: email || null,
        businessId: businessId,
        fullName: fullName,
        loginPin: pin, 
        employeeNumber: employeeNumber || null,
        assignedRoles: selectedRoles,
        allowPushNotifications: pushNotifications,
        allowEmailNotifications: emailNotifications,
        authenticationPass: encryptedRandomPass,
        id: userId
      });
  
      Alert.alert('Success', 'User created successfully!');
      navigation.goBack(); 
    } catch (error) {
      console.error('Error creating user: ', error);
      Alert.alert('Error', 'There was an issue creating the user.');
    }
  };

  return (
    <SafeAreaView style={styles.safeContainer}>
      <View style={styles.container}>
        {/* Logo */}
        <Image 
          source={require('../../assets/images/taskorbit.png')} 
          style={styles.logo} 
        />
  
        {/* Switch between pages */}
        <View style={styles.switchContainer}>
          {hasManageEmployeesPermission ?
          <TouchableOpacity
            onPress={() => setIsManagingEmployees(true)}
            style={[styles.switchOption, isManagingEmployees && styles.activeOption]}
          >
            <Text style={styles.switchText}>Manage employees</Text>
          </TouchableOpacity>
          : null}
          {hasAddEmployeesPermission ?
          <TouchableOpacity
            onPress={() => setIsManagingEmployees(false)}
            style={[styles.switchOption, !isManagingEmployees && styles.activeOption]}
          >
            <Text style={styles.switchText}>Add employee</Text>
          </TouchableOpacity>
          : null}
        </View>
  
        {isManagingEmployees ? (
          
<>
<ScrollView style={styles.employeeContainer}>
{employees.map((employee) => (
  <View key={employee.id} style={styles.employeeBox}>
    <Image 
      source={require('../../assets/images/taskorbit.png')}
      style={styles.employeeIcon} 
    />
    <View style={styles.employeeInfo}>
      <Text style={styles.employeeName}>{employee.fullName}</Text>
    </View>
    <TouchableOpacity onPress={() => {
    setSelectedEmployee(employee);
    setSelectedRoles(employee.assignedRoles || []); 
    setPushNotifications(employee.allowPushNotifications || false);
    setEmailNotifications(employee.allowEmailNotifications || false);
      setIsModalVisible(true);
    }}>
      <MaterialIcons name="more-vert" size={22} color="#333" style={styles.dotsIcon} />
    </TouchableOpacity>
  </View>
))}
  </ScrollView>
          <View style={styles.buttonRow}>
          <TouchableOpacity style={styles.skipButton} onPress={() => navigation.goBack()}>
            <Text style={styles.skipButtonText}>Go back</Text>
          </TouchableOpacity>
        </View>
        <Modal
  animationType="slide"
  transparent={true}
  visible={isModalVisible}
  onRequestClose={() => setIsModalVisible(false)}>
  <View style={styles.modalContainer}>
    <View style={styles.modalContent}>
      <Text style={styles.modalTitle}>{selectedEmployee?.fullName}</Text>

      <DropDownPicker
        open={openRolePicker}
        value={selectedRoles}
        items={roles}
        setOpen={setOpenRolePicker}
        setValue={setSelectedRoles}
        multiple={true}
        mode="BADGE"
        placeholder="Select Roles"
        style={styles.dropdown}
        badgeColors={['#2196f3']}
        badgeTextStyle={{ color: 'white' }}
      />

<LinearGradient
            colors={['#2196f3', '#21cbf3']}
            start={{ x: 1, y: 0 }}
            end={{ x: 0, y: 0 }}
            style={styles.editButton}
          >
<TouchableOpacity onPress={() => setIsModalVisible(false) & setIsEditEmployeeInfoModalVisible(true)}>
  <Text style={styles.editButtonText}>Edit Employee info</Text>
</TouchableOpacity>
          </LinearGradient>

      <View style={styles.checkboxContainer}>
        <View style={styles.checkboxRow}>
          <CheckBox
            value={pushNotifications}
            onValueChange={setPushNotifications}
            boxType='square'
            style={styles.checkbox}
          />
          <Text style={styles.checkboxLabel}>Allow Push Notifications</Text>
        </View>
        <View style={styles.checkboxRow}>
          <CheckBox
            value={emailNotifications}
            onValueChange={setEmailNotifications}
            boxType='square'
            style={styles.checkbox}
          />
          <Text style={styles.checkboxLabel}>Allow Email Notifications</Text>
        </View>
      </View>

      <LinearGradient
  colors={['#f44336', '#e57373']}
  start={{ x: 1, y: 0 }}
  end={{ x: 0, y: 0 }}
  style={styles.removeButton}>
  <TouchableOpacity onPress={() => setIsModalVisible(false) & setIsEditEmployeeInfoModalVisible(false) & setIsRemoveEmployeePopupVisible(true)}>
    <Text style={styles.removeButtonText}>Remove Employee</Text>
  </TouchableOpacity>
</LinearGradient>

          <View style={styles.buttonModalRow}>
  <TouchableOpacity onPress={() => setIsModalVisible(false)} style={styles.closeModalButton}>
    <Text style={styles.closeButtonText}>Close</Text>
  </TouchableOpacity>
  <TouchableOpacity onPress={handleEditEmployee} style={styles.confirmModalButton}>
    <Text style={styles.closeButtonText}>Confirm</Text>
  </TouchableOpacity>
</View>
    </View>
  </View>
</Modal>

<Modal
  animationType="slide"
  transparent={true}
  visible={isEditEmployeeInfoModalVisible}
  onRequestClose={() => setIsEditEmployeeInfoModalVisible(false)}
>
  <View style={styles.modalContainer}>
    <View style={styles.modalContent}>
    <Text style={styles.modalTitle}>{selectedEmployee?.fullName}</Text>

      {/* Full Name Input */}
      <TextInput
        style={styles.input}
        placeholder={selectedEmployee?.fullName || 'Full Name'}
        placeholderTextColor="#888"
        value={fullName}
        onChangeText={setFullName}
      />

      {/* Email Input */}
      <TextInput
        style={styles.input}
        placeholder={selectedEmployee?.email || 'email-address'}
        placeholderTextColor="#888"
        value={email}
        keyboardType="email-address"
        onChangeText={setEmail}
      />

<LinearGradient
            colors={['#2196f3', '#21cbf3']}
            start={{ x: 1, y: 0 }}
            end={{ x: 0, y: 0 }}
            style={styles.editButton}
          >
<TouchableOpacity onPress={() => setIsEditEmployeeInfoModalVisible(false) & navigation.navigate('(app)/updateUserPin', { userId: selectedEmployee?.id})}>
  <Text style={styles.editButtonText}>Edit Login PIN</Text>
</TouchableOpacity>
          </LinearGradient>

      {/* Employee Number Input */}
      <TextInput
        style={styles.input}
        placeholder={selectedEmployee?.employeeNumber || 'Employee Number (optional)'}
        placeholderTextColor="#888"
        value={employeeNumber}
        keyboardType="default"
        onChangeText={setEmployeeNumber}
      />

      <View style={styles.buttonModalRow}>
        <TouchableOpacity onPress={() => setIsEditEmployeeInfoModalVisible(false)} style={styles.closeModalButton}>
          <Text style={styles.closeButtonText}>Cancel</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={handleEditEmployeeInformation} style={styles.confirmModalButton}>
          <Text style={styles.closeButtonText}>Save Changes</Text>
        </TouchableOpacity>
      </View>
    </View>
  </View>
</Modal>

<Modal
  animationType="slide"
  transparent={true}
  visible={isRemoveEmployeePopupVisible}
  onRequestClose={() => setIsRemoveEmployeePopupVisible(false)}
>
  <View style={styles.modalContainer}>
    <View style={styles.modalContent}>
      {selectedEmployee && selectedEmployee.hasSuperAdmin === true ? (
        <>
          <Text style={styles.modalTitle}>Superadmin Alert</Text>
          <Text style={styles.modalText}>
            This user is a Superadmin and cannot be deleted.
          </Text>
          <View style={styles.buttonModalRow}>
        <TouchableOpacity
          onPress={() => setIsRemoveEmployeePopupVisible(false)}
          style={styles.closeModalButton}>
          <Text style={styles.closeButtonText}>Close</Text>
        </TouchableOpacity>
      </View>
        </>
      ) : (
        <>
          <Text style={styles.modalTitle}>
            Are you sure you want to remove {selectedEmployee?.fullName}?
          </Text>
          <View style={styles.buttonModalRow}>
        <TouchableOpacity
          onPress={() => setIsRemoveEmployeePopupVisible(false)}
          style={styles.closeModalButton}>
          <Text style={styles.closeButtonText}>Cancel</Text>
        </TouchableOpacity>
        <LinearGradient
  colors={['#f44336', '#e57373']}
  start={{ x: 1, y: 0 }}
  end={{ x: 0, y: 0 }}
  style={styles.confirmModalButton}>
        <TouchableOpacity
          onPress={handleRemoveEmployee}>
                <Text style={{color: 'white'}}>Remove</Text>
        </TouchableOpacity>
        </LinearGradient>
      </View>
        </>
      )}
    </View>
  </View>
</Modal>

</>
        ) : (
          <><TextInput
              style={styles.input}
              placeholder="Email (optional)"
              placeholderTextColor="#888"
              value={email}
              keyboardType="email-address"
              onChangeText={setEmail} /><TextInput
                style={styles.input}
                placeholder="Full Name"
                placeholderTextColor="#888"
                value={fullName}
                onChangeText={setFullName} /><TextInput
                style={styles.input}
                placeholder="Login PIN (4-digit)"
                placeholderTextColor="#888"
                value={pin}
                keyboardType="numeric"
                maxLength={4}
                onChangeText={setPin} />

        {/* Employee Number Input */}
        <TextInput
          style={styles.input}
          placeholder="Employee Number (optional)"
          placeholderTextColor="#888"
          value={employeeNumber}
          keyboardType="default"
          onChangeText={setEmployeeNumber}
        />

        <DropDownPicker
          open={openRolePicker}
          value={selectedRoles}
          items={roles}
          setOpen={setOpenRolePicker}
          setValue={setSelectedRoles}
          multiple={true}
          mode="BADGE"
          placeholder="Select Roles"
          style={styles.dropdown}
          badgeColors={['#2196f3']}
          badgeTextStyle={{ color: 'white' }}
        />

        {/* Notification Preferences */}
        <View style={styles.checkboxContainer}>
          <View style={styles.checkboxRow}>
            <CheckBox
              value={pushNotifications}
              onValueChange={setPushNotifications}
              boxType='square'
              style={styles.checkbox}
            />
            <Text style={styles.checkboxLabel}>Allow Push Notifications</Text>
          </View>

          <View style={styles.checkboxRow}>
            <CheckBox
              value={emailNotifications}
              onValueChange={setEmailNotifications}
              boxType='square'
              style={styles.checkbox}
            />
            <Text style={styles.checkboxLabel}>Allow Email Notifications</Text>
          </View>
        </View>

        <View style={styles.buttonRow}>
          <TouchableOpacity style={styles.skipButton} onPress={() => navigation.goBack()}>
            <Text style={styles.skipButtonText}>Go back</Text>
          </TouchableOpacity>

          <LinearGradient
            colors={['#2196f3', '#21cbf3']}
            start={{ x: 1, y: 0 }}
            end={{ x: 0, y: 0 }}
            style={styles.confirmButton}
          >
            <TouchableOpacity onPress={handleCreateUser}>
              <Text style={styles.confirmButtonText}>Create new employee</Text>
            </TouchableOpacity>
          </LinearGradient>
        </View>
        </>
        )}
      </View>
    </SafeAreaView>
  );
}  

const styles = StyleSheet.create({
  safeContainer: {
    flex: 1,
    backgroundColor: 'white',
  },
  container: {
    flex: 1,
    padding: 20,
  },
  logo: {
    width: 150,
    height: 150,
    alignSelf: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#333',
    textAlign: 'center',
  },
  input: {
    backgroundColor: 'transparent',
    padding: 10,
    marginBottom: 15,
    borderRadius: 8,
    borderColor: '#ccc',
    borderWidth: 1,
  },
  dropdown: {
    backgroundColor: 'transparent',
    marginBottom: 15,
    borderRadius: 8,
    borderColor: '#ccc',
    borderWidth: 1,
  },
  checkboxContainer: {
    marginVertical: 5,
  },
  checkboxRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  checkboxLabel: {
    marginLeft: 8,
    fontSize: 16,
  },
  buttonRow: {
    position: 'absolute',
    flexDirection: 'row',
    alignSelf: 'center',
    justifyContent: 'space-between',
    bottom: 0,
  },
  skipButton: {
    backgroundColor: 'white',
    borderWidth: 1,
    borderColor: '#dcdcdc',
    borderRadius: 10,
    padding: 15,
    alignItems: 'center',
    flex: 1,
    marginRight: 10,
  },
  skipButtonText: {
    color: '#2196f3',
    fontWeight: 'bold',
  },
  checkbox: {
    width: 20,
    height: 20,
    marginRight: 8,
  },
  confirmButton: {
    borderRadius: 10,
    padding: 15,
    flex: 2,
  },
  confirmButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  switchContainer: {
    backgroundColor: 'white',
    flexDirection: 'row',
    alignSelf: 'center',
    marginBottom: 20,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#ccc',
  },
  switchOption: {
    borderRadius: 15,
    paddingVertical: 10,
    paddingHorizontal: 20,
    marginVertical: 5,
    marginHorizontal: 5,
  },
  activeOption: {
    backgroundColor: '#eee',
  },
  switchText: {
    color: 'black',
  },
  employeeContainer: {
    flex: 1,
  },
  employeeBox: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
    justifyContent: 'space-between',
  },
  employeeIcon: {
    width: 40,
    height: 40,
    marginRight: 15,
    resizeMode: 'contain',
  },
  employeeInfo: {
    flex: 1,
    flexDirection: 'column',
  },
  employeeName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  employeeEmail: {
    fontSize: 14,
    color: '#666',
    marginTop: 4,
  },
  dotsIcon: {
    paddingHorizontal: 10,
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    width: '80%',
    backgroundColor: 'white',
    borderRadius: 10,
    padding: 20,
  },
  modalTitle: {
    fontSize: 20,
    marginBottom: 10,
    alignSelf: 'center',
    fontWeight: 'bold',
  },
  modalText: {
    fontSize: 16,
    marginVertical: 10,
  },
  editButton: {
    backgroundColor: 'white',
    borderColor: '#2196f3',
    borderWidth: 1,
    borderRadius: 8,
    padding: 10,
    marginBottom: 10,
    alignItems: 'center',
  },
  editButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  buttonModalRow: {
    flexDirection: 'row',
    justifyContent: 'space-between', 
    marginTop: 10, 
  },
  closeModalButton: {
    backgroundColor: 'white',
    borderWidth: 1,
    borderColor: '#dcdcdc',
    borderRadius: 10,
    padding: 10,
    alignItems: 'center',
    flex: 1,
    marginRight: 10,

  },
  confirmModalButton: {
    backgroundColor: 'white',
    borderWidth: 1,
    borderColor: '#dcdcdc',
    borderRadius: 10,
    padding: 10,
    alignItems: 'center',
    flex: 1,
  },
  removeButton: {
    marginVertical: 10,
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
  },
  removeButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
  modalDescription: {
    marginBottom: 15,
    textAlign: 'center',
    color: '#555',
  },
});

export default CreateUserScreen;
