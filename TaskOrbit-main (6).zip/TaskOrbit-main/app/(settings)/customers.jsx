import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, Image, StyleSheet, SafeAreaView, Alert, Modal, TextInput } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { doc, getDoc, updateDoc } from 'firebase/firestore';
import { firestore, auth } from '../(api)/firebase';
import Ionicons from 'react-native-vector-icons/Ionicons';

const CustomersScreen = ({ route }) => {
  const { businessId } = route.params;
  const userId = auth.currentUser.uid;
  const navigation = useNavigation();
  const [customers, setCustomers] = useState([]);
  const [isModalVisible, setModalVisible] = useState(false);
  const [isCustomerModalVisible, setIsCustomerModalVisible] = useState(false);
const [selectedCustomer, setSelectedCustomer] = useState(null);
const [updatedName, setUpdatedName] = useState('');
const [updatedPhone, setUpdatedPhone] = useState('');
const [searchText, setSearchText] = useState('');
const filteredCustomers = customers.filter((customer) =>
    customer.name.toLowerCase().includes(searchText.toLowerCase()) ||
    customer.phone.includes(searchText)
  );
    const [fullName, setFullName] = useState("Unidentified");
  const [newCustomerName, setNewCustomerName] = useState('');
const [newCustomerPhone, setNewCustomerPhone] = useState('');
const [isAddModalVisible, setAddModalVisible] = useState(false);

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const userDoc = await getDoc(doc(firestore, "Users", userId));
        if (userDoc.exists()) {
          const userData = userDoc.data();

          setFullName(userData.fullName);
        } else {
          console.log("No such document!");
        }
      } catch (error) {
        console.error("Error fetching user data: ", error);
      }
    };

    fetchUserData();
  }, [userId, navigation]);

  useEffect(() => {
    const fetchCustomers = async () => {
      const businessDoc = await getDoc(doc(firestore, "Businesses", businessId));
      if (businessDoc.exists()) {
        const customersObject = businessDoc.data().customers || {};
        const customersArray = Object.keys(customersObject).map((key) => ({
          id: key,
          ...customersObject[key],
        }));
        setCustomers(customersArray);
        console.log(`Customers: ${JSON.stringify(customersArray)}`);
      }
    };
    fetchCustomers();
  }, [businessId]);

  const handleCustomerClick = (customer) => {
    setSelectedCustomer(customer);
    setIsCustomerModalVisible(true);
  };

  const handleEditCustomer = (customer) => {
    setSelectedCustomer(customer);
    setUpdatedName(customer.name);
    setUpdatedPhone(customer.phone);
    setModalVisible(true);
  };

  const closeModal = () => {
    setModalVisible(false);
    setSelectedCustomer(null);
    setUpdatedName('');
    setUpdatedPhone('');
  };

  const closeCustomerModal = () => {
    setIsCustomerModalVisible(false);
    setSelectedCustomer(null);
    setUpdatedName('');
    setUpdatedPhone('');
  };

  const saveCustomerChanges = async () => {
    if (!selectedCustomer) return;

    try {
      const businessDocRef = doc(firestore, "Businesses", businessId);
      const businessDoc = await getDoc(businessDocRef);

      if (businessDoc.exists()) {
        const updatedCustomers = { ...businessDoc.data().customers };
        updatedCustomers[selectedCustomer.id] = {
          ...updatedCustomers[selectedCustomer.id],
          name: updatedName,
          phone: updatedPhone,
        };

        await updateDoc(businessDocRef, { customers: updatedCustomers });
        setCustomers(
          Object.keys(updatedCustomers).map((key) => ({
            id: key,
            ...updatedCustomers[key],
          }))
        );

        closeModal();
      }
    } catch (error) {
      console.error("Error saving customer changes:", error);
    }
  };

  const handleDeleteCustomer = async (customerId) => {
    Alert.alert(
      "Delete Customer",
      "Are you sure you want to delete this customer?",
      [
        {
          text: "Cancel",
          style: "cancel",
        },
        {
          text: "Delete",
          style: "destructive",
          onPress: async () => {
            try {
              const businessDocRef = doc(firestore, "Businesses", businessId);
              const businessDoc = await getDoc(businessDocRef);

              if (businessDoc.exists()) {
                const updatedCustomers = { ...businessDoc.data().customers };
                delete updatedCustomers[customerId];

                await updateDoc(businessDocRef, { customers: updatedCustomers });
                setCustomers(
                  Object.keys(updatedCustomers).map((key) => ({
                    id: key,
                    ...updatedCustomers[key],
                  }))
                );
              }
            } catch (error) {
              console.error("Error deleting customer:", error);
            }
          },
        },
      ]
    );
  };

  const handleProjectPress = async (projectId) => {
    try {
      const businessDocRef = doc(firestore, "Businesses", businessId);
      const businessDoc = await getDoc(businessDocRef);
  
      if (businessDoc.exists()) {
        const project = businessDoc.data().project[projectId].projectSettings;
        setIsCustomerModalVisible(false);
        if (project) {
          navigation.navigate("(app)/project_details", {
            project,
            businessId,
            fullName: fullName,
          });
        } else {
          Alert.alert("Error", "Project not found.");
        }
      }
    } catch (error) {
      Alert.alert("Woops!", "We are currently unable to fetch this project. Does it still exist?");
    }
  };  

  const addNewCustomer = async () => {
    if (!newCustomerName || !newCustomerPhone) {
      Alert.alert("Error", "Please fill out all fields.");
      return;
    }

    try {
      const businessDocRef = doc(firestore, "Businesses", businessId);
      const businessDoc = await getDoc(businessDocRef);

      if (businessDoc.exists()) {
        const customersObject = businessDoc.data().customers || {};
        const newCustomerId = `${newCustomerName}`;
        customersObject[newCustomerId] = {
          name: newCustomerName,
          phone: newCustomerPhone,
        };

        await updateDoc(businessDocRef, { customers: customersObject });
        setCustomers(
          Object.keys(customersObject).map((key) => ({
            id: key,
            ...customersObject[key],
          }))
        );

        setAddModalVisible(false);
        setNewCustomerName('');
        setNewCustomerPhone('');
      }
    } catch (error) {
      console.error("Error adding new customer:", error);
    }
  };

  const renderCustomer = ({ item }) => (
    <TouchableOpacity onPress={() => handleCustomerClick(item)}>
      <View style={styles.customerItem}>
        <View style={styles.customerInfo}>
          <Text style={styles.customerName}>{item.name}</Text>
          <Text style={styles.customerPhone}>{item.phone}</Text>
        </View>
        <View style={styles.actions}>
          <TouchableOpacity
            onPress={() => handleEditCustomer(item)}
            style={styles.actionButton}
          >
            <Ionicons name="pencil-outline" size={20} color="#2196f3" />
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => handleDeleteCustomer(item.id)}
            style={styles.actionButton}
          >
            <Ionicons name="trash-outline" size={20} color="#f44336" />
          </TouchableOpacity>
        </View>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
      <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
        <Ionicons name="arrow-back" size={24} color="#333" />
      </TouchableOpacity>
      <TouchableOpacity style={styles.backButton} onPress={() => setAddModalVisible(true)}>
  <Ionicons name="add" size={24} color="#333" />
</TouchableOpacity>
      </View>

        <Image
          source={require('../../assets/images/taskorbit.png')}
          style={styles.icon}
        />

      {/* Title */}
      <Text style={styles.title}>Customers</Text>

      <View style={styles.searchBarContainer}>
  <Ionicons name="search-outline" size={20} color="#555" style={styles.searchIcon} />
  <TextInput
    style={styles.searchInput}
    placeholderTextColor={'#ccc'}
    placeholder="Search by name or phone..."
    value={searchText}
    onChangeText={setSearchText}
  />
</View>

      {/* Customers List */}
      {filteredCustomers.length > 0 ? (
        <FlatList
        data={filteredCustomers}
        renderItem={renderCustomer}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.listContent}
        />
      ) : (
        <><Text style={styles.noCustomersText}>No customers found.</Text><FlatList
                      data={filteredCustomers}
                      renderItem={renderCustomer}
                      keyExtractor={(item) => item.id}
                      contentContainerStyle={styles.listContent} /></>
      )}

<Modal
  visible={isModalVisible}
  transparent={true}
  animationType="slide"
  onRequestClose={closeModal}
>
  <View style={styles.modalContainer}>
    <View style={styles.modalContent}>
      <Text style={styles.modalTitle}>Edit Customer</Text>
      <TextInput
        style={styles.input}
        placeholder="Name"
        value={updatedName}
        onChangeText={setUpdatedName}
      />
      <TextInput
        style={styles.input}
        placeholder="Phone Number"
        value={updatedPhone}
        onChangeText={setUpdatedPhone}
        keyboardType="phone-pad"
      />
      <View style={styles.modalButtons}>
                <TouchableOpacity onPress={closeModal} style={styles.closeModalButton}>
                  <Text style={styles.closeButtonText}>Cancel</Text>
                </TouchableOpacity>
                <TouchableOpacity onPress={saveCustomerChanges} style={styles.confirmModalButton}>
                  <Text style={styles.closeButtonText}>Save Changes</Text>
                </TouchableOpacity>
      </View>
    </View>
  </View>
</Modal>

<Modal
  visible={isAddModalVisible}
  transparent={true}
  animationType="slide"
  onRequestClose={() => setAddModalVisible(false)}
>
  <View style={styles.modalContainer}>
    <View style={styles.modalContent}>
      <Text style={styles.modalTitle}>Add Customer</Text>
      <TextInput
        style={styles.input}
        placeholder="Full Name"
        value={newCustomerName}
        placeholderTextColor={'#ccc'}
        onChangeText={setNewCustomerName}
      />
      <TextInput
        style={styles.input}
        placeholder="Phone Number"
        placeholderTextColor={'#ccc'}
        value={newCustomerPhone}
        onChangeText={setNewCustomerPhone}
        keyboardType="phone-pad"
      />
      <View style={styles.modalButtons}>
        <TouchableOpacity
          onPress={() => setAddModalVisible(false)}
          style={styles.closeModalButton}
        >
          <Text style={styles.closeButtonText}>Cancel</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={addNewCustomer}
          style={styles.confirmModalButton}
        >
          <Text style={styles.closeButtonText}>Add Customer</Text>
        </TouchableOpacity>
      </View>
    </View>
  </View>
</Modal>

<Modal
  visible={isCustomerModalVisible}
  transparent={true}
  animationType="slide"
  onRequestClose={closeCustomerModal}
>
  <View style={styles.modalContainer}>
    <View style={styles.modalContent}>
      <Text style={styles.modalTitle}>{selectedCustomer?.name}</Text>
      <FlatList
  data={(selectedCustomer?.projects || []).sort(
    (a, b) => b.dueDate.toDate() - a.dueDate.toDate()
  )}
  keyExtractor={(item, index) => index.toString()}
  renderItem={({ item }) => (
    <View style={styles.projectContainer}>
      <TouchableOpacity
        style={styles.projectHeader}
        onPress={() => {
          item.expanded = !item.expanded;
          setCustomers([...customers]);
        }}
      >
        <Text style={styles.projectTitle}>{item.reportTitle}</Text>
        <Ionicons
          name={item.expanded ? "chevron-up" : "chevron-down"}
          size={20}
          color="#2196f3"
        />
      </TouchableOpacity>
      {item.expanded && (
        <TouchableOpacity onPress={() => handleProjectPress(item.reportTitle)} style={styles.projectDetails}>
          <Text style={styles.projectDescription}>
            {item.reportDescription}
          </Text>
          <Text style={styles.projectDueDate}>
            Completed: {item.dueDate.toDate().toLocaleString()}
          </Text>
        </TouchableOpacity>
      )}
    </View>
  )}
/>
            <View style={styles.modalButtons}>
      <TouchableOpacity onPress={closeCustomerModal} style={styles.closeModalButton}>
        <Text style={styles.closeButtonText}>Close</Text>
      </TouchableOpacity>
      </View>
    </View>
  </View>
</Modal>

    </View>
  );
};

export default CustomersScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
    paddingHorizontal: 20,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 10,
  },
  backButton: {
    paddingVertical: 10,
    paddingHorizontal: 15,
  },
  backIcon: {
    fontSize: 18,
    color: '#2196f3',
  },
  icon: {
    alignSelf: 'center',
    width: 150,
    height: 150,
    resizeMode: 'contain',
  },
  title: {
    fontSize: 24,
    fontWeight: '600',
    marginBottom: 10,
    textAlign: 'center',
    color: '#333',
  },
  listContent: {
    paddingVertical: 10,
  },
  customerItem: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    padding: 15,
    marginHorizontal: 10,
    marginBottom: 10,
    borderRadius: 8,
    borderColor: '#ddd',
    borderWidth: 1,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 5,
    elevation: 3,
  },
  customerName: {
    fontSize: 18,
    fontWeight: '500',
    color: '#333',
  },
  customerPhone: {
    fontSize: 14,
    color: '#555',
    marginTop: 5,
  },
  actions: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  actionButton: {
    marginLeft: 10,
  },
  customerInfo: {
    flex: 1,
  },
  noCustomersText: {
    textAlign: 'center',
    marginTop: 20,
    fontSize: 16,
    color: '#777',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    width: '90%',
    padding: 20,
    backgroundColor: '#fff',
    borderRadius: 10,
    elevation: 5,
  },
  modalTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
  },
  projectContainer: {
    marginBottom: 15,
  },
  projectHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 10,
    backgroundColor: '#f4f4f4',
    borderRadius: 5,
  },
  projectTitle: {
    fontSize: 18,
    fontWeight: '600',
  },
  projectDetails: {
    padding: 10,
    backgroundColor: '#e9ecef',
    borderRadius: 5,
    marginTop: 5,
  },
  projectDescription: {
    fontSize: 16,
    color: '#555',
  },
  projectDueDate: {
    fontSize: 14,
    color: '#777',
    marginTop: 5,
  },
  closeModalButton: {
    backgroundColor: 'white',
    borderWidth: 1,
    borderColor: '#dcdcdc',
    borderRadius: 10,
    padding: 10,
    alignItems: 'center',
    flex: 1,
    marginRight: 10,
  },
  closeButtonText: {
    color: 'black',
    fontSize: 16,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    padding: 10,
    marginBottom: 15,
    fontSize: 16,
  },
  modalButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  confirmModalButton: {
    backgroundColor: 'white',
    borderWidth: 1,
    borderColor: '#dcdcdc',
    borderRadius: 10,
    padding: 10,
    alignItems: 'center',
    flex: 1,
  },
  searchBarContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 8,
    marginHorizontal: 10,
    padding: 10,
    borderWidth: 1,
    borderColor: '#ddd',
  },
  searchIcon: {
    marginRight: 10,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: '#333',
  },
});
