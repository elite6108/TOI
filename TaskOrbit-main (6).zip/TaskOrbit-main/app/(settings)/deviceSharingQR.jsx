import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Image, ActivityIndicator, TouchableOpacity, SafeAreaView } from 'react-native';
import QRCode from 'react-native-qrcode-svg';
import { doc, getDoc } from 'firebase/firestore';
import { firestore, auth } from '../(api)/firebase';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { useNavigation } from '@react-navigation/native';

const AdminQRCodeScreen = () => {
  const [businessId, setBusinessId] = useState(null);
  const navigation = useNavigation();

  useEffect(() => {
    const fetchBusinessId = async () => {
      const userId = auth.currentUser.uid;
      try {
        const userDoc = await getDoc(doc(firestore, 'Users', userId));
        if (userDoc.exists()) {
          setBusinessId(userDoc.data().businessId);
        } else {
          console.log('No business ID found');
        }
      } catch (error) {
        console.error('Error fetching business ID:', error);
      }
    };

    fetchBusinessId();
  }, []);

  return (
    <View style={styles.container}>
      {/* Back Button */}
      <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
        <Ionicons name="arrow-back" size={24} color="#333" />
      </TouchableOpacity>

      {/* App Logo at the Top */}
      <Image
        source={require('../../assets/images/taskorbit.png')}
        style={styles.logo}
        resizeMode="contain"
      />

      {/* Title */}
      <Text style={styles.title}>Scan to add a device</Text>

      {/* QR Code */}
      <View style={styles.qrContainer}>
        {businessId ? (
          <QRCode
            value={businessId}
            size={250}
            logo={require('../../assets/images/taskorbit.png')}
            logoSize={60}
            logoBackgroundColor='transparent'
            enableLinearGradient={true}
            logoMargin={0}
            logoBorderRadius={10}
            backgroundColor='#FFFFFF'
          />
        ) : (
          <ActivityIndicator size="large" color="#2196f3" />
        )}
      </View>

      {/* Instructions */}
      <Text style={styles.instructions}>Scan this QR code within TaskOrbit.</Text>

    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'flex-start',
    paddingTop: 40,
  },
  backButton: {
    position: 'absolute',
    top: 50,
    left: 25,
    zIndex: 1,
  },
  logo: {
    width: 150,
    height: 150,
    marginBottom: 10,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 20,
  },
  qrContainer: {
    padding: 20,
    backgroundColor: '#fff',
    borderRadius: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.3,
    shadowRadius: 10,
    elevation: 5,
    alignItems: 'center',
  },
  instructions: {
    fontSize: 16,
    color: '#666',
    marginTop: 20,
    textAlign: 'center',
  },
  navigationWrapper: {
    position: 'absolute',
    bottom: 35,
    width: '100%',
    backgroundColor: '#fff',
    borderTopColor: '#ccc',
  },
});

export default AdminQRCodeScreen;
