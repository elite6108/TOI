import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  ActivityIndicator,
  SafeAreaView,
  Image,
  TouchableOpacity,
} from "react-native";
import Icon from "react-native-vector-icons/MaterialIcons";
import { launchImageLibrary } from "react-native-image-picker";
import { auth, firestore, storage } from "../(api)/firebase";
import { doc, getDoc, updateDoc } from "firebase/firestore";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { useNavigation } from "@react-navigation/native";
import { LinearGradient } from "expo-linear-gradient";
import { useFocusEffect } from "@react-navigation/native";

const GeneralSettings = () => {
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [employeeNumber, setEmployeeNumber] = useState("");
  const [loginPin, setLoginPin] = useState("");
  const [assignedRoles, setAssignedRoles] = useState([]);
  const [associatedSince, setAssociatedSince] = useState(null);
  const [loading, setLoading] = useState(true);
  const [profileImage, setProfileImage] = useState(null);
  const navigation = useNavigation();

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const userId = auth.currentUser.uid;
        const userDoc = await getDoc(doc(firestore, "Users", userId));
        if (userDoc.exists()) {
          const userData = userDoc.data();
          setFullName(userData.fullName || "");
          setEmail(userData.email || "");
          setEmployeeNumber(userData.employeeNumber || "");
          setLoginPin(userData.loginPin || "");
          setAssignedRoles(userData.assignedRoles || []);
          setAssociatedSince(userData.associatedSince || null);
          setProfileImage(userData.profileImage || null);
          if (!userData.loginPin) {
            navigation.replace("(app)/pinCreation", { userDocId: userId });
          }
        } else {
          console.log("No such document!");
        }
        setLoading(false);
      } catch (error) {
        console.error("Error fetching user data: ", error);
        setLoading(false);
      }
    };

    fetchUserData();
  }, [navigation]);

  const handleImagePicker = () => {
    launchImageLibrary({ mediaType: "photo", quality: 0.3 }, (response) => {
      if (
        response.didCancel ||
        response.errorCode ||
        !response.assets ||
        !response.assets[0]?.uri
      ) {
        console.warn("Image selection canceled or failed");
        return;
      }
      setProfileImage({ uri: response.assets[0].uri });
    });
  };

  const handleUpdateUserInfo = async () => {
    try {
      const userId = auth.currentUser.uid;
      const userDocRef = doc(firestore, "Users", userId);

      await updateDoc(userDocRef, {
        fullName,
        email,
      });

      if (profileImage?.uri) {
        const storageRef = ref(storage, `profileImages/${userId}`);
        const img = await fetch(profileImage.uri);
        const bytes = await img.blob();
        await uploadBytes(storageRef, bytes);

        const downloadURL = await getDownloadURL(storageRef);
        await updateDoc(userDocRef, { profileImage: downloadURL });
      }

      navigation.goBack();
    } catch (error) {
      console.error("Error updating user information: ", error);
    }
  };

  if (loading) {
    return (
      <ActivityIndicator size="large" color="#2196f3" style={styles.loading} />
    );
  }

  return (
    <View style={styles.safeArea}>
      <View style={styles.container}>
        <Text style={styles.heading}>General Settings</Text>

        <View style={styles.userInfoContainer}>
          <TouchableOpacity onPress={handleImagePicker}>
            <Image
              source={
                profileImage
                  ? { uri: profileImage.uri || profileImage }
                  : require("../../assets/images/taskorbit.png")
              }
              style={styles.profileImage}
            />
          </TouchableOpacity>
          <Text style={styles.userName}>{fullName}</Text>
        </View>

        <View style={styles.inputEditableContainer}>
          <TextInput
            style={styles.input}
            value={fullName}
            onChangeText={setFullName}
            placeholder="Full Name"
          />
          <Icon name="person" size={20} color="#888" style={styles.icon} />
        </View>

        <View style={styles.inputEditableContainer}>
          <TextInput
            style={styles.input}
            value={email}
            onChangeText={setEmail}
            placeholder="Email"
            keyboardType="email-address"
          />
          <Icon name="email" size={20} color="#888" style={styles.icon} />
        </View>

        {employeeNumber && (
          <View style={styles.inputContainer}>
            <TextInput
              style={styles.input}
              value={employeeNumber}
              editable={false}
              placeholder="Employee Number"
            />
            <Icon name="badge" size={20} color="#888" style={styles.icon} />
          </View>
        )}

        <View style={styles.inputContainer}>
          <TextInput
            style={styles.input}
            value={loginPin}
            editable={false}
            placeholder="Login PIN"
          />
          <Icon name="lock" size={20} color="#888" style={styles.icon} />
        </View>

        <View style={styles.inputContainer}>
          <TextInput
            style={styles.input}
            value={assignedRoles.join(", ")}
            editable={false}
            placeholder="Assigned Roles"
          />
          <Icon name="group" size={20} color="#888" style={styles.icon} />
        </View>

        <View style={styles.inputContainer}>
          <TextInput
            style={styles.input}
            value={
              associatedSince
                ? associatedSince.toDate().toLocaleDateString("en-US")
                : ""
            }
            editable={false}
            placeholder="Associated Since"
          />
          <Icon
            name="calendar-today"
            size={20}
            color="#888"
            style={styles.icon}
          />
        </View>
      </View>

      <View style={styles.footerContainer}>
        <View style={styles.buttonRow}>
          <TouchableOpacity
            style={styles.skipButton}
            onPress={() => navigation.goBack()}
          >
            <Text style={styles.skipButtonText}>Cancel</Text>
          </TouchableOpacity>

          <LinearGradient
            colors={["#2196f3", "#21cbf3"]}
            start={{ x: 1, y: 0 }}
            end={{ x: 0, y: 0 }}
            style={styles.confirmButton}
          >
            <TouchableOpacity onPress={handleUpdateUserInfo}>
              <Text style={styles.confirmButtonText}>Confirm changes</Text>
            </TouchableOpacity>
          </LinearGradient>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: "#fff",
  },
  container: {
    flex: 1,
    padding: 20,
  },
  userInfoContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "white",
    borderColor: "#ccc",
    borderWidth: 1,
    borderRadius: 10,
    padding: 10,
    marginBottom: 20,
  },
  profileImage: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginRight: 15,
  },
  userName: {
    fontSize: 18,
    fontWeight: "bold",
    color: "black",
  },
  heading: {
    color: "black",
    fontSize: 20,
    fontWeight: "bold",
    marginBottom: 20,
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    borderColor: "#d3d3d3",
    borderWidth: 1,
    borderRadius: 8,
    marginBottom: 15,
    backgroundColor: "#f0f0f0",
  },
  inputEditableContainer: {
    flexDirection: "row",
    alignItems: "center",
    borderColor: "#d3d3d3",
    borderWidth: 1,
    borderRadius: 8,
    marginBottom: 15,
    backgroundColor: "white",
  },
  input: {
    flex: 1,
    height: 50,
    paddingHorizontal: 10,
    color: "#777",
  },
  icon: {
    marginRight: 10,
  },
  loading: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  footerContainer: {
    paddingHorizontal: 20,
  },
  buttonRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 20,
  },
  skipButton: {
    backgroundColor: "transparent",
    borderWidth: 1,
    borderColor: "#dcdcdc",
    borderRadius: 10,
    padding: 15,
    alignItems: "center",
    flex: 1,
    marginRight: 10,
  },
  skipButtonText: {
    color: "#2196f3",
    fontWeight: "bold",
  },
  confirmButton: {
    borderRadius: 10,
    padding: 15,
    flex: 2,
  },
  confirmButtonText: {
    color: "#fff",
    fontWeight: "bold",
    textAlign: "center",
  },
});

export default GeneralSettings;
