import React, { useState, useEffect } from 'react';
import { SafeAreaView, View, Text, StyleSheet, TouchableOpacity, Image, ScrollView, TextInput, Modal, Animated, ActivityIndicator, PanResponder } from 'react-native';
import { doc, getDoc, updateDoc} from 'firebase/firestore';
import { LinearGradient } from 'expo-linear-gradient';
import { auth, firestore } from '../(api)/firebase';
import { MaterialIcons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';

const CreateUserScreen = ( ) => {
  const userId = auth.currentUser.uid;
  const [isManagingRoles, setIsManagingRoles] = useState(true);
  const [roles, setRoles] = useState([]);
  const [businessRoles, setBusinessRoles] = useState([]);
  const [businessId, setBusinessId] = useState(null);
  const navigation = useNavigation();
  const [isColorPickerVisible, setIsColorPickerVisible] = useState(false);
  const [isLoadingRoles, setIsLoadingRoles] = useState(true);
  const [selectedRoleIndex, setSelectedRoleIndex] = useState(null);
  const [fadeAnim] = useState(new Animated.Value(0));
  const templatePermissions = [
    {
      id: 'manage_task_list_roles',
      name: 'Manage Task List Roles',
      subPermissions: [
        { id: 'edit_task_list_roles', name: 'Edit Task List Roles' },
        { id: 'create_task_lists', name: 'Create Task Lists' },
        { id: 'remove_task_lists', name: 'Remove Task Lists' },
      ]
    },
    {
      id: 'manage_employees',
      name: 'Manage Employees',
      subPermissions: [
        { id: 'add_employee', name: 'Add Employee' },
        { id: 'remove_employee', name: 'Remove Employee' },
        { id: 'edit_employee', name: 'Edit Employee' },
      ]
    },
    {
      id: 'task_list_actions',
      name: 'Task List Actions',
      subPermissions: [
        { id: 'generate_task_lists', name: 'Generate Task Lists' },
        { id: 'submit_task_lists', name: 'Submit Task Lists' },
        { id: 'complete_task_lists', name: 'Complete Task Lists' },
        { id: 'reopen_task_lists', name: 'Reopen Task Lists' },
      ]
    },
    {
      id: 'project_management',
      name: 'Project Management',
      subPermissions: [
        { id: 'create_project', name: 'Create Projects' },
        { id: 'edit_project', name: 'Edit Project' },
        { id: 'complete_project', name: 'Complete Project' },
      ]
    },
    {
      id: 'business_settings',
      name: 'Business Settings',
      subPermissions: [
        { id: 'edit_roles', name: 'Edit Business Roles' },
        { id: 'edit_billing_settings', name: 'Edit Billing Settings' },
      ]
    },
    {
      id: 'report_management',
      name: 'Report Management',
      subPermissions: [
        { id: 'view_completion_reports', name: 'View Completion Reports' },
      ]
    },
    {
      id: 'user_settings',
      name: 'User Settings',
      subPermissions: [
        { id: 'edit_login_pin', name: 'Edit Login PIN' },
      ]
    },
    {
      id: 'task_assignment',
      name: 'Task Assignment',
      subPermissions: [
        { id: 'assign_tasks', name: 'Assign Tasks to Other Roles' },
      ]
    },
  ];
  const [isPermissionsModalVisible, setIsPermissionsModalVisible] = useState(false);
  const [selectedPermissions, setSelectedPermissions] = useState({});
  const colors = ['#ff0000', '#00ff00', '#0000ff', '#ff00ff', '#00ffff', '#ffff00'];

  const openColorPicker = (index) => {
    setSelectedRoleIndex(index);
    setIsColorPickerVisible(true);
  };

  const openPermissionsModal = (index) => {
    setSelectedRoleIndex(index);
    setIsPermissionsModalVisible(true);


    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 500,
      useNativeDriver: true,
    }).start();
  };

  const closePermissionsModal = () => {
    Animated.timing(fadeAnim, {
      toValue: 0,
      duration: 500,
      useNativeDriver: true,
    }).start(() => setIsPermissionsModalVisible(false));
  };

  const selectColor = (color) => {
    if (selectedRoleIndex !== null) {
      const updatedRoles = [...businessRoles];
      updatedRoles[selectedRoleIndex].color = color;
      setBusinessRoles(updatedRoles);
      setIsColorPickerVisible(false);
    }
  };

  const handleRoleChange = (index, value) => {
    const updatedRoles = [...businessRoles];
    updatedRoles[index].name = value;
    setBusinessRoles(updatedRoles);
  };

  const addRole = () => {
    setBusinessRoles([...businessRoles, { name: 'New role', color: '#dcdcdc' }]);
  };

  const handleDeleteRole = (index) => {
    const updatedRoles = businessRoles.filter((_, i) => i !== index);
    setBusinessRoles(updatedRoles);
  };

  const handleConfirmChanges = async () => {
    if (!businessId) {
      console.error('No business ID found!');
      return;
    }


    const updatedRoles = businessRoles.map((role, index) => ({
      ...role,
      permissions: Object.keys(selectedPermissions[index] || {}).filter(
        permissionId => selectedPermissions[index][permissionId]
      ),
    }));

    try {
      const businessRef = doc(firestore, 'Businesses', businessId);
      await updateDoc(businessRef, { roles: updatedRoles });
      console.log('Roles updated successfully');
      navigation.goBack();
    } catch (error) {
      console.error('Error updating roles: ', error);
    }
  };

  const togglePermission = (roleIndex, permissionId) => {
    setSelectedPermissions(prev => ({
      ...prev,
      [roleIndex]: {
        ...prev[roleIndex],
        [permissionId]: !prev[roleIndex]?.[permissionId],
      },
    }));
  };


  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const userDoc = await getDoc(doc(firestore, 'Users', userId));
        if (userDoc.exists()) {
          setBusinessId(userDoc.data().businessId);
        } else {
          console.log('No such document!');
        }
      } catch (error) {
        console.error('Error fetching user data: ', error);
      }
    };

    fetchUserData();
  }, [userId]);

  useEffect(() => {
    const fetchRoles = async () => {
      if (businessId) {
        try {
          setIsLoadingRoles(true);
          const businessDoc = await getDoc(doc(firestore, 'Businesses', businessId));
          if (businessDoc.exists()) {
            const rolesArray = businessDoc.data().roles || [];
            setBusinessRoles(rolesArray);
            setRoles(
              rolesArray.map(role => ({
                label: role.name,
                value: role.name,
              }))
            );

            const permissionsState = {};
            rolesArray.forEach((role, index) => {
              permissionsState[index] = {};
              role.permissions.forEach(permissionId => {
                permissionsState[index][permissionId] = true;
              });
            });
            setSelectedPermissions(permissionsState);
          } else {
            console.log('No roles found for this business!');
          }
        } catch (error) {
          console.error('Error fetching roles: ', error);
        } finally {
          setIsLoadingRoles(false);
        }
      }
    };

    fetchRoles();
  }, [businessId]);

  return (
    <View style={styles.safeContainer}>
      <View style={styles.container}>
        {/* Logo */}
        <Image
          source={require('../../assets/images/taskorbit.png')}
          style={styles.logo}
        />

        {/* Switch between pages */}
        <View style={styles.switchContainer}>
          <TouchableOpacity
            onPress={() => setIsManagingRoles(true)}
            style={[styles.switchOption, isManagingRoles && styles.activeOption]}
          >
            <Text style={styles.switchText}>Manage roles</Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => setIsManagingRoles(false)}
            style={[styles.switchOption, !isManagingRoles && styles.activeOption]}
          >
            <Text style={styles.switchText}>Role permissions</Text>
          </TouchableOpacity>
        </View>

        {isLoadingRoles ? (
  <View style={styles.loaderContainer}>
    <ActivityIndicator size="large" color="#2196f3" />
  </View>
) : (
        isManagingRoles ? (
  <ScrollView style={styles.rolesContainer}>
        {businessRoles.map((role, index) => (
          <View key={index} style={[styles.roleContainer, { borderColor: role.color }]}>
  <TouchableOpacity
    style={[styles.colorButton, { borderColor: role.color }]}
    onPress={() => openColorPicker(index)}
  >
    <MaterialIcons name="color-lens" size={20} color={role.color} />
  </TouchableOpacity>
  <TextInput
    style={styles.roleInput}
    value={role.name}
    onChangeText={(value) => handleRoleChange(index, value)}
  />
  <TouchableOpacity onPress={() => handleDeleteRole(index)}>
    <MaterialIcons name="delete" size={24} color={role.color} style={styles.trashIcon} />
  </TouchableOpacity>
</View>
        ))}
                <TouchableOpacity style={styles.addButton} onPress={addRole}>
          <Text style={styles.addButtonText}>Add new role</Text>
        </TouchableOpacity>
  </ScrollView>
) : (
<ScrollView style={styles.rolesContainer}>
  {businessRoles.map((role, index) => (
    <View key={index} style={[styles.rolePermissionContainer, { borderColor: role.color }]}>
      <Text style={styles.roleName}>{role.name}</Text>
      <TouchableOpacity
  onPress={() => openPermissionsModal(index)}
  style={styles.permissionsIconContainer}
>
  <MaterialIcons name="security" size={24} color={role.color} />
</TouchableOpacity>
    </View>
  ))}
</ScrollView>
  )
)}
      </View>

      <Modal visible={isColorPickerVisible} transparent={true} animationType="slide">
        <View style={styles.modalContainer}>
          <View style={styles.colorPickerContainer}>
            {colors.map((color, idx) => (
              <TouchableOpacity
                key={idx}
                style={[styles.colorOption, { backgroundColor: color }]}
                onPress={() => selectColor(color)}
              />
            ))}
          </View>
        </View>
      </Modal>

      <Modal visible={isPermissionsModalVisible} transparent={true} animationType="none">
  <View style={styles.modalContainer}>
    <Animated.View style={[styles.permissionsModalContent, { opacity: fadeAnim }]}>
      <ScrollView style={styles.permissionsList}>
        {templatePermissions.map((permission, idx) => (
          <View key={idx} style={styles.permissionCategory}>
            <Text style={styles.permissionCategoryText}>{permission.name}</Text>
            {permission.subPermissions.map((subPermission, subIdx) => (
              <View key={subIdx} style={styles.permissionItem}>
                <Text>{subPermission.name}</Text>
                <TouchableOpacity
                  onPress={() => togglePermission(selectedRoleIndex, subPermission.id)}
                  style={styles.permissionToggle}
                >
                  <MaterialIcons
                    name={
                      selectedPermissions[selectedRoleIndex]?.[subPermission.id]
                        ? "check-box"
                        : "check-box-outline-blank"
                    }
                    size={24}
                    color="#2196f3"
                  />
                </TouchableOpacity>
              </View>
            ))}
          </View>
        ))}
      </ScrollView>
      <TouchableOpacity
        onPress={closePermissionsModal}
        style={styles.closeModalButton}
      >
        <Text style={styles.closeModalText}>Close</Text>
      </TouchableOpacity>
    </Animated.View>
  </View>
</Modal>

      <View style={styles.footerContainer}>
        <View style={styles.buttonRow}>
          <TouchableOpacity style={styles.skipButton} onPress={() => navigation.goBack()}>
            <Text style={styles.skipButtonText}>Cancel</Text>
          </TouchableOpacity>

          <LinearGradient
            colors={['#2196f3', '#21cbf3']}
            start={{ x: 1, y: 0 }}
            end={{ x: 0, y: 0 }}
            style={styles.confirmButton}
          >
<TouchableOpacity onPress={handleConfirmChanges}>
  <Text style={styles.confirmButtonText}>Confirm changes</Text>
</TouchableOpacity>
          </LinearGradient>
        </View>

        <View style={styles.navigationWrapper}>
      </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  safeContainer: {
    flex: 1,
    backgroundColor: 'white',
  },
  container: {
    flex: 1,
    padding: 20,
  },
  logo: {
    width: 150,
    height: 150,
    alignSelf: 'center',
  },
  loaderContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  switchContainer: {
    backgroundColor: 'white',
    flexDirection: 'row',
    alignSelf: 'center',
    marginBottom: 20,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#ccc',
  },
  switchOption: {
    borderRadius: 15,
    paddingVertical: 10,
    paddingHorizontal: 20,
    marginVertical: 5,
    marginHorizontal: 5,
  },
  activeOption: {
    backgroundColor: '#eee',
  },
  switchText: {
    color: 'black',
  },
  rolesContainer: {
    flex: 1,
  },
  roleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f0f0f0',
    borderRadius: 10,
    marginVertical: 5,
    padding: 10,
    borderWidth: 2,
  },
  roleInput: {
    flex: 1,
    fontSize: 16,
    height: 50,
    color: 'black',
    marginLeft: 10,
  },
  addButton: {
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: '#dcdcdc',
    borderRadius: 10,
    padding: 15,
    alignItems: 'center',
    marginVertical: 10,
    width: '100%',
  },
  addButtonText: {
    color: 'black',
    fontWeight: 'bold',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  colorPickerContainer: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 10,
    flexDirection: 'row',
    justifyContent: 'space-around',
    flexWrap: 'wrap',
  },
  colorOption: {
    width: 50,
    height: 50,
    borderRadius: 25,
    margin: 10,
  },

  footerContainer: {
    paddingHorizontal: 20,
  },
  buttonRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  skipButton: {
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: '#dcdcdc',
    borderRadius: 10,
    padding: 15,
    alignItems: 'center',
    flex: 1,
    marginRight: 10,
  },
  skipButtonText: {
    color: '#2196f3',
    fontWeight: 'bold',
  },
  confirmButton: {
    borderRadius: 10,
    padding: 15,
    flex: 2,
  },
  confirmButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  rolePermissionContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 10,
    borderWidth: 2,
    paddingHorizontal: 15,
    backgroundColor: '#f9f9f9',
    borderRadius: 10,
    marginVertical: 5,
  },
  roleName: {
    fontSize: 16,
    color: 'black',
  },
  dropdown: {
    zIndex: 100,
    marginTop: 5,
    borderColor: '#ccc',
  },
  permissionsIconContainer: {
    paddingLeft: 10,
    flexDirection: 'row',
    alignItems: 'center',
  },

  permissionsModalContent: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 20,
    width: '90%',
    maxHeight: '80%',
    alignSelf: 'center',
  },

  permissionsList: {
    marginBottom: 20,
  },
  permissionCategory: {
    marginVertical: 10,
    paddingLeft: 10,
  },
  permissionCategoryText: {
    fontWeight: 'bold',
    fontSize: 16,
    marginBottom: 5,
  },
  permissionItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
  },

  closeModalButton: {
    backgroundColor: '#2196f3',
    borderRadius: 5,
    padding: 10,
    alignItems: 'center',
    marginTop: 10,
  },

  closeModalText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  permissionToggle: {
    justifyContent: 'center',
    alignItems: 'center',
    paddingLeft: 10,
  },
});

export default CreateUserScreen;
