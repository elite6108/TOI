import * as React from "react";
import {createStackNavigator} from "@react-navigation/stack";
import { StatusBar} from "react-native";
import {NavigationContainer} from "@react-navigation/native";
import "react-native-get-random-values";
import checkLogin from "./(auth)/checkForLogin";
import Login from "./(auth)/login";
import ResetPassword from "./(auth)/reset_password";
import RegisterScreen from "./(auth)/register";
import BusinessSetup from "./(auth)/business_information";
import RoleSetup from "./(auth)/role_setup";
import TaskSetup from "./(auth)/task_setup";
import QRCodeScannerScreen from "./(auth)/(employee)/employeeScanner";
import EmployeeLogin from "./(auth)/(employee)/employeeLogin";
import PinEntryScreen from "./(auth)/(employee)/pinEntry";
import AccountRemoved from "./(auth)/account_not_exist";

import Dashboard from "./(app)/dashboard";
import TaskListScreen from "./(app)/taskListScreen";
import Settings from "./(app)/settings";
import TaskCreation from "./(app)/create_task";
import UpdateTask from "./(app)/update_task";
import UserCreation from "./(settings)/create_user";
import Search from "./(app)/search";
import AdminQRCodeScreen from "./(settings)/deviceSharingQR";
import PinCreation from "./(app)/pinCreation";
import UpdateUserPin from "./(settings)/updateUserPin";
import generateTaskList from "./(app)/generateTaskList";
import generateTaskListUsingAI from "./(app)/create_task_aiResults";
import generalSettings from "./(settings)/general";
import roles from "./(settings)/roles";
import createProject from "./(app)/create_project";
import projectDetails from "./(app)/project_details";
import TaskOverView from "./(app)/tasks_overview";
import ProjectOverview from "./(app)/project_overview";
import InformationLibrary from './(app)/information_library'
import Customers from './(settings)/customers'
import BottomTabs from "@/app/navigation/BottomTabs";
import {SafeAreaProvider,SafeAreaView} from "react-native-safe-area-context";
import AllTasks from "@/app/(app)/tasks/AllTasks";

const Stack = createStackNavigator();

function App() {
    return (
        <SafeAreaProvider>
            <StatusBar barStyle="dark-content" backgroundColor="#ffffff"/>
            <NavigationContainer independent={true}>
                <SafeAreaView style={{flex: 1,backgroundColor:'white'}}>
                    <Stack.Navigator initialRouteName="(auth)/checkForLogin">
                        <Stack.Screen
                            name="(auth)/checkForLogin"
                            component={checkLogin}
                            options={{headerShown: false, animationEnabled: false}}
                        />
                        <Stack.Screen
                            name="(auth)/login"
                            component={Login}
                            options={{headerShown: false, animationEnabled: false}}
                        />
                        <Stack.Screen
                            name="(auth)/register"
                            component={RegisterScreen}
                            options={{headerShown: false, animationEnabled: false}}
                        />
                        <Stack.Screen
                            name="(auth)/business_information"
                            component={BusinessSetup}
                            options={{headerShown: false, animationEnabled: false}}
                        />
                        <Stack.Screen
                            name="(auth)/role_setup"
                            component={RoleSetup}
                            options={{headerShown: false, animationEnabled: false}}
                        />
                        <Stack.Screen
                            name="(auth)/task_setup"
                            component={TaskSetup}
                            options={{headerShown: false, animationEnabled: false}}
                        />

                        <Stack.Screen
                            name="(app)/dashboard"
                            component={Dashboard}
                            options={{headerShown: false, animationEnabled: false}}
                        />

                        <Stack.Screen
                            name="BottomTabs"
                            component={BottomTabs}
                            options={{headerShown: false, animationEnabled: false}}
                        />

                        <Stack.Screen
                            name="(app)/taskListScreen"
                            component={TaskListScreen}
                            options={{headerShown: false, animationEnabled: false}}
                        />
                        <Stack.Screen
                            name="(app)/settings"
                            component={Settings}
                            options={{headerShown: false, animationEnabled: false}}
                        />
                        <Stack.Screen
                            name="(app)/create_task"
                            component={TaskCreation}
                            options={{headerShown: false, animationEnabled: false}}
                        />
                        <Stack.Screen
                            name="(app)/update_task"
                            component={UpdateTask}
                            options={{headerShown: false, animationEnabled: false}}
                        />
                        <Stack.Screen
                            name="(app)/create_user"
                            component={UserCreation}
                            options={{headerShown: false, animationEnabled: false}}
                        />
                        <Stack.Screen
                            name="(app)/search"
                            component={Search}
                            options={{headerShown: false, animationEnabled: false}}
                        />
                        <Stack.Screen
                            name="(app)/deviceSharingQR"
                            component={AdminQRCodeScreen}
                            options={{headerShown: false, animationEnabled: false}}
                        />
                        <Stack.Screen
                            name="(app)/employeeScanner"
                            component={QRCodeScannerScreen}
                            options={{headerShown: false, animationEnabled: false}}
                        />
                        <Stack.Screen
                            name="(app)/employeeLogin"
                            component={EmployeeLogin}
                            options={{headerShown: false, animationEnabled: false}}
                        />
                        <Stack.Screen
                            name="(auth)/pinEntry"
                            component={PinEntryScreen}
                            options={{headerShown: false, animationEnabled: false}}
                        />
                        <Stack.Screen
                            name="(app)/pinCreation"
                            component={PinCreation}
                            options={{headerShown: false, animationEnabled: false}}
                        />
                        <Stack.Screen
                            name="(app)/updateUserPin"
                            component={UpdateUserPin}
                            options={{headerShown: false, animationEnabled: false}}
                        />
                        <Stack.Screen
                            name="(app)/generateTaskList"
                            component={generateTaskList}
                            options={{headerShown: false, animationEnabled: false}}
                        />
                        <Stack.Screen
                            name="(app)/create_task_aiResults"
                            component={generateTaskListUsingAI}
                            options={{headerShown: false, animationEnabled: false}}
                        />
                        <Stack.Screen
                            name="(settings)/generalSettings"
                            component={generalSettings}
                            options={{headerShown: false, animationEnabled: false}}
                        />
                        <Stack.Screen
                            name="(settings)/roles"
                            component={roles}
                            options={{headerShown: false, animationEnabled: false}}
                        />
                        <Stack.Screen
                            name="(app)/create_project"
                            component={createProject}
                            options={{headerShown: false, animationEnabled: false}}
                        />
                        <Stack.Screen
                            name="(app)/project_details"
                            component={projectDetails}
                            options={{headerShown: false, animationEnabled: false}}
                        />
                        <Stack.Screen
                            name="(auth)/account_not_exist"
                            component={AccountRemoved}
                            options={{headerShown: false, animationEnabled: false}}
                        />
                        <Stack.Screen
                            name="(auth)/reset_password"
                            component={ResetPassword}
                            options={{headerShown: false, animationEnabled: false}}
                        />
                        <Stack.Screen
                            name="(app)/task_overview"
                            component={TaskOverView}
                            options={{headerShown: false, animationEnabled: false}}
                        />
                        <Stack.Screen
                            name="(app)/project_overview"
                            component={ProjectOverview}
                            options={{headerShown: false, animationEnabled: false}}
                        />
                        <Stack.Screen
                            name="(app)/information_library"
                            component={InformationLibrary}
                            options={{headerShown: false, animationEnabled: false}}
                        />
                        <Stack.Screen
                            name="(settings)/customers"
                            component={Customers}
                            options={{headerShown: false, animationEnabled: false}}
                        />

                        <Stack.Screen
                            name="allTasks"
                            component={AllTasks}
                            options={{headerShown: false, animationEnabled: false}}
                        />

                    </Stack.Navigator>
                </SafeAreaView>
            </NavigationContainer>
        </SafeAreaProvider>
    );
}

export default App;
