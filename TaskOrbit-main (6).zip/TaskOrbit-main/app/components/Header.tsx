import React, {useEffect, useMemo, useState} from "react";
import {StyleSheet, Text, TouchableOpacity, View, ViewStyle} from "react-native";
import {MaterialCommunityIcons} from "@expo/vector-icons";


interface RadioButtonProps {
    id: string;
    label?: string;
    value?: string;
    isSelected: boolean
}

interface HeaderProps {
    navigation: any;
    title?: string;
    titleStyle?:ViewStyle;
}

const Header = ({navigation,title,titleStyle}: HeaderProps) => {

    return (
        <View style={styles.header}>
            <TouchableOpacity onPress={() => navigation.goBack()}>
                <MaterialCommunityIcons name="arrow-left" size={24} color="black"/>
            </TouchableOpacity>
            <Text style={[styles.headerTitle,titleStyle]}>{title}</Text>
        </View>
    )
}


export default Header
const styles = StyleSheet.create({
    header: {
        flexDirection: "row",
        alignItems: "center",
        //padding: 16,
        //backgroundColor: "transparent",

    },
    headerTitle: {
        fontSize: 24,
        marginLeft: 16,
    },

});
