import React, {useEffect, useMemo, useState} from "react";
import {StyleSheet, Text, TouchableOpacity, View} from "react-native";


interface RadioButtonProps  {
    id: string;
    label?: string;
    value?: string;
    isSelected: boolean
}

  interface RadioGroupProps {
    onChange: (selectedId: string) => void;
    selectedId?: string;
    testID?: string;
    value?: string;
    isDisabled: boolean
}

const RadioButton = ({onChange, isDisabled, value}: RadioGroupProps) => {

    const radioButtons: RadioButtonProps[] = useMemo(() => ([
        {
            id: '1', // acts as primary key, should be unique and non-empty string
            label: 'Yes',
            value: 'Yes',
            isSelected: false
        },
        {
            id: '2',
            label: 'No',
            value: 'No',
            isSelected: false
        }
    ]), []);

    const [buttons, setButtons] = useState(radioButtons);

    useEffect(() => {
        if (value) {
            const items = radioButtons?.map((item) => ({...item, isSelected: value === item.value}))
            setButtons(items)
        }
    }, [value])

    const onPressItem = (e) => {
        const items = radioButtons?.map((item) => ({...item, isSelected: e.id === item.id}))
        onChange(e.value);
        setButtons(items)
    }

    return (<View style={styles.yesNoContainer}>
        {buttons?.map((item, index) => {
            return (
                <TouchableOpacity style={styles.checkboxContainer} key={index.toString()}
                                  onPress={() => onPressItem(item)} disabled={isDisabled}>
                    <View style={styles.checkbox}>
                        {item?.isSelected && <View style={styles.checkboxFilled}/>}
                    </View>
                    <Text style={styles.labelStyle}>{item.label}</Text>
                </TouchableOpacity>
            )
        })}
    </View>)
}


export default RadioButton
const styles = StyleSheet.create({

    labelStyle: {
        left: 6
    },
    checkbox: {
        width: 26,
        height: 26,
        borderRadius: 13,
        borderColor: '#AA90E7',
        borderWidth: 2,
        alignItems: 'center',
        justifyContent: 'center'
    },
    checkboxFilled: {
        width: 16,
        height: 16,
        borderRadius: 8,
        backgroundColor: '#AA90E7'
    },
    checkboxContainer: {
        flexDirection: "row",
        alignItems: "center",
        marginTop: 10,
    },
    yesNoContainer: {
        flexDirection: "column",
        alignItems: "flex-start",
        marginTop: 10,
    },


});
