import React from "react";
import {StyleSheet, Text, TouchableOpacity, View} from "react-native";
import {MaterialCommunityIcons} from "@expo/vector-icons";
import {formatDate, getStatusColor} from "@/app/utils/utils";
import {TaskData} from "@/app/models/TaskModal";


interface TaskItemData extends TaskData {
    name: string;
    completedCount: number;
    status: string;
}

interface TaskItemProps {
    index: number;
    navigation: any;
    businessId: any;
    roles: any;
    fullName:string;
    task: TaskItemData
}

const TaskItem = ({index, businessId,roles,fullName,task, navigation}: TaskItemProps) => {

    return (
        <TouchableOpacity
            key={index}
            style={[
                styles.reportItem,
                { borderColor: getStatusColor(task.status) },
            ]}
            onPress={() =>
                navigation.navigate("(app)/taskListScreen", {
                    task,
                    businessId: businessId,
                    taskListName: task.name,
                    roles:roles,
                    username: fullName,
                })
            }
        >
            <View style={styles.taskHeader}>
                <Text style={styles.reportTitle} numberOfLines={2}>{task.name}</Text>
                <View style={[styles.taskCountContainer,]}>
                    <View
                        style={[
                            styles.statusContainer,
                            { backgroundColor: getStatusColor(task.status) },
                        ]}
                    >
                        <Text style={styles.statusText}>{task.status}</Text>
                    </View>
                    <View style={[styles.completedContainer]}>
                        {task.completedCount < task.taskItems.length && (
                            <Text style={styles.taskCount}>
                                {task.completedCount}/{task.taskItems.length}
                            </Text>
                        )}
                        {task?.completedCount === task?.taskItems?.length && (
                            <MaterialCommunityIcons
                                name="check-circle"
                                size={18}
                                color="#4caf50"
                            />
                        )}
                    </View>
                </View>
            </View>
            <Text style={styles.reportDetails}>
                Complete by: {formatDate(task.taskListSettings.dateTime)}
            </Text>
            <Text style={styles.reportDetails}>
                Display till: {formatDate(task.taskListSettings.displayDateTime)}
            </Text>
        </TouchableOpacity>
    )
}


export default TaskItem
const styles = StyleSheet.create({
    reportItem: {
        backgroundColor: "#f9f9f9",
        padding: 15,
        marginBottom: 10,
        borderRadius: 10,
        borderWidth: 1,
        borderLeftWidth: 6,
        borderColor: "#ccc",
    },
    taskHeader: {
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
    },
    reportTitle: {
        fontSize: 18,
        color: "#161616",
        fontWeight: "bold",
        marginBottom: 5,
        flex:2
    },
    statusText: {
        fontSize: 13,
        color: "black",
        fontWeight: "600",
        textAlign: "center",
        marginRight: 5,
    },

    taskCountContainer: {
        flexDirection: "row",
        alignItems: "center",
    },
    completedContainer: {
        flexDirection: "row",
        alignItems: "center",
    },



    statusContainer: {
        paddingHorizontal: 10,
        paddingVertical: 4,
        borderRadius: 15,
        marginRight: 5,
        marginBottom: 0,
    },

    reportDetails: {
        fontSize: 14,
        color: "#adacb2",
        marginBottom: 5,
    },

    taskCount: {
        fontSize: 16,
        fontWeight: "400",
        color: "#2196f3",
    },


});
