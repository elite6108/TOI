/*
import React, {useEffect, useMemo, useState} from "react";
import {Button, Image, Modal, StyleSheet, Text, TextInput, TouchableOpacity, View} from "react-native";
import CheckBox from "@react-native-community/checkbox";
import {CameraView} from "expo-camera";
import SignatureScreen from "react-native-signature-canvas";
import RadioButton from "@/app/components/RadioButton";
import DateTimePicker from "@react-native-community/datetimepicker";
import DropDownPicker from "react-native-dropdown-picker";


interface TaskItem  {
    id: string;
    label?: string;
    value?: string;
    isSelected: boolean

    type: string;
    name: string;
}

interface TaskItemProps {
    onChange: (selectedId: string) => void;
    selectedId?: string;
    testID?: string;
    value?: string;
    isDisabled: boolean
    item:TaskItem
    task: any
}

const TaskListModal = ({onChange, task, value,item}: TaskItemProps) => {

    return (
        <Modal
            animationType="slide"
            transparent={true}
            visible={TaskmodalVisible}
            onRequestClose={() => setTaskModalVisible(false)}
        >
            <View style={styles.modalContainer}>
                <View style={styles.modalContent}>
                    <Text style={styles.modalTitle}>Task list settings</Text>

                    {/!* New input for Task List Name *!/}
                    <Text style={styles.modalHeader}>Task List Name</Text>
                    <TextInput
                        style={styles.input}
                        placeholder="Enter task list name"
                        placeholderTextColor={'black'}
                        value={taskListName}
                        onChangeText={setTaskListName}
                    />

                    <Text style={styles.modalHeader}>Select Completion Date/Time</Text>
                    <TouchableOpacity
                        style={styles.datePickerButton}
                        onPress={() => setShowDatePicker(true)}
                    >
                        <Text style={styles.datePickerButtonText}>
                            {selectedDate ? selectedDate.toLocaleString() : 'Pick a start date/time'}
                        </Text>
                    </TouchableOpacity>

                    {showDatePicker && (
                        <DateTimePicker
                            value={selectedDate}
                            mode="datetime"
                            display="default"
                            onChange={(event, date) => {
                                if (date) setSelectedDate(date);
                            }}
                        />
                    )}

                    { roles ?
                        <><Text style={styles.modalHeader}>Roles attached to list</Text><DropDownPicker
                            zIndex={10}
                            open={open}
                            value={selectedRoles}
                            items={roleOptions}
                            setOpen={() => handleOpen('roles')}
                            setValue={setSelectedRoles}
                            placeholder="Select roles"
                            multiple={true}
                            min={0}
                            max={5} /><Text style={styles.modalHeader}>Notification roles on task completion</Text><DropDownPicker
                            zIndex={9}
                            open={open1}
                            value={selectedNotificationRoles}
                            items={roleOptions}
                            setOpen={() => handleOpen('roles1')}
                            setValue={setSelectedNotificationRoles}
                            placeholder="Select roles"
                            multiple={true}
                            min={0}
                            max={5} /></>
                        : null }
                    <Text style={styles.modalHeader}>Task Frequency</Text>
                    <DropDownPicker
                        zIndex={8}
                        open={frequencyOpen}
                        value={selectedFrequency}
                        items={frequencyOptions}
                        setOpen={() => handleOpen('frequency')}
                        setValue={setSelectedFrequency}
                        placeholder="Select frequency"
                    />
                    <View style={styles.modalButtonRow}>
                        <TouchableOpacity
                            style={styles.cancelButton}
                            onPress={() => setTaskModalVisible(false)}
                        >
                            <Text style={styles.cancelButtonText}>Cancel</Text>
                        </TouchableOpacity>
                        <TouchableOpacity
                            style={styles.confirmTaskButton}
                            onPress={confirmTaskListSettings}
                        >
                            <Text style={styles.confirmTaskButtonText}>Confirm</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </View>
        </Modal>
    )
}


export default TaskListModal
const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 20,
        justifyContent: 'flex-start',
    },
    logo: {
        width: '100%',
        marginTop: 20,
        height: 150,
    },
    headerText: {
        fontWeight: 'bold',
        marginBottom: 20,
    },
    blueText: {
        fontSize: 25,
        color: '#2196f3',
    },
    blackText: {
        fontSize: 20,
        color: 'black',
    },
    scrollView: {
        flex: 1,
        marginBottom: 20,
    },
    scrollContent: {
        paddingBottom: 20,
    },
    taskContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#f0f0f0',
        borderRadius: 10,
        marginVertical: 5,
        padding: 10,
        borderWidth: 2,
    },
    taskInput: {
        flex: 1,
        fontSize: 16,
        height: 50,
        color: 'black',
        marginLeft: 10,
    },
    editButton: {
        padding: 5,
        alignItems: 'center',
    },
    changeTypeText: {
        fontSize: 12,
        color: '#2196f3',
    },
    removeTaskText: {
        fontSize: 12,
        color: 'red',
    },
    addButton: {
        backgroundColor: 'transparent',
        borderWidth: 1,
        borderColor: '#dcdcdc',
        borderRadius: 10,
        padding: 15,
        alignItems: 'center',
        marginVertical: 5,
        width: '100%',
    },
    addButtonText: {
        color: 'black',
        fontWeight: 'bold',
    },
    buttonRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginBottom: 20,
    },
    skipButton: {
        backgroundColor: 'transparent',
        borderWidth: 1,
        borderColor: '#dcdcdc',
        borderRadius: 10,
        padding: 15,
        alignItems: 'center',
        flex: 1,
        marginRight: 10,
    },
    skipButtonText: {
        color: '#2196f3',
        fontWeight: 'bold',
    },
    confirmButton: {
        borderRadius: 10,
        padding: 15,
        flex: 2,
    },
    confirmButtonText: {
        color: '#fff',
        fontWeight: 'bold',
        textAlign: 'center',
    },
    taskAiCreation: {
        padding: 12,
        borderRadius: 8,
        alignItems: 'center',
        flexDirection: 'row',
        justifyContent: 'center',
        top: 5,
    },
    confirmAIButton: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    icon: {
        marginRight: 8,
    },
    confirmAIButtonText: {
        color: '#fff',
        fontSize: 16,
        fontWeight: 'bold',
    },
    modalContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
    },
    modalContent: {
        backgroundColor: '#fff',
        padding: 20,
        borderRadius: 10,
        width: '80%',
    },
    modalTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        marginBottom: 0,
        textAlign: 'center',
    },
    modalHeader: {
        fontSize: 14,
        fontWeight: 'bold',
        marginTop: 20,
        marginBottom: 5,
        textAlign: 'left',
    },
    typeButton: {
        flexDirection: 'row',
        alignItems: 'center',
        padding: 10,
        borderWidth: 1,
        borderColor: '#dcdcdc',
        borderRadius: 10,
        marginVertical: 5,
    },
    selectedType: {
        backgroundColor: '#e0f7fa',
    },
    typeButtonText: {
        marginLeft: 10,
    },
    modalButtonRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginTop: 15,
    },
    confirmTaskButton: {
        backgroundColor: '#2196f3',
        borderRadius: 10,
        padding: 10,
        flex: 1,
        marginLeft: 5,
    },
    cancelButton: {
        backgroundColor: '#f44336',
        borderRadius: 10,
        padding: 10,
        flex: 1,
        marginRight: 5,
    },
    confirmTaskButtonText: {
        color: '#fff',
        textAlign: 'center',
    },
    cancelButtonText: {
        color: '#fff',
        textAlign: 'center',
    },
    input: {
        borderColor: 'black',
        color: 'black',
        borderWidth: 1,
        borderRadius: 5,
        padding: 12,
        fontSize: 16,
    },
    datePickerButton: {
        padding: 10,
        borderWidth: 1,
        borderColor: 'black',
        borderRadius: 10,
    },
    datePickerButtonText: {
        color: 'black',
    },
});
*/
