import React, {useCallback, useMemo, useState} from "react";
import {StyleSheet} from "react-native";
import {Dropdown} from "react-native-element-dropdown";
import i18n from "@/app/localization";

interface TaskOrbitDropDownDataProps  {
    label: string;
    value: string;
}

interface TaskOrbitDropDownProps {
    onChange: (dropDownValue: string) => void;
    data?: [];
    value: string ;
}

const TaskOrbitDropDown = ({onChange, value}: TaskOrbitDropDownProps) => {
    const [dropdownValue, setDropdownValue] = useState<string>(value);

    const data: TaskOrbitDropDownDataProps[] = useMemo(() => {
        return i18n.t('common.dropdownArr') as TaskOrbitDropDownDataProps[] || [];
    }, []);

    const onDropDownChanges= useCallback((item)=>{
        onChange?.(item.value);
        setDropdownValue(item.value)
    },[]);


    return (
        <Dropdown
            style={styles.dropdown}
            data={data}
            labelField="label"
            valueField="value"
            placeholder="Select"
            value={dropdownValue}
            onChange={(item) => onDropDownChanges(item)}
        />
    )
}


export default React.memo(TaskOrbitDropDown);

const styles = StyleSheet.create({
    dropdown: {
        width: 130,
        backgroundColor: "transparent",
        borderWidth: 1,
        borderColor: "grey",
        borderRadius: 10,
        padding: 7,
    },

});
