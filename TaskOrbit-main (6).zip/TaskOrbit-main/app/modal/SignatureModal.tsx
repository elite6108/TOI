import React from "react";
import {Button, StyleSheet} from "react-native";
import SignatureScreen from "react-native-signature-canvas";


interface SignatureModalProps {
    onOK?: (signature: string) => void;
    onClose: () => void;
    descriptionText?:string;
    clearText:string;
    confirmText:string;
    isClose?: boolean
}

const SignatureModal = ({onOK, onClose,descriptionText,confirmText="Save",clearText="Clear",isClose}: SignatureModalProps) => {

    return (
        <>
            <SignatureScreen
                style={{paddingVertical:10}}
                onOK={(signature) => {
                    onOK?.(signature)
                }}
                onEmpty={() => console.log("No signature")}
                onClear={() => {
                    //setSignature("")
                    onClose?.();
                }}
                descriptionText={descriptionText|| " "}
                clearText={clearText}
                confirmText={confirmText}
                autoClear={false}
            />
            {isClose && <Button
                title="Close"
                onPress={() => {
                    onClose?.()
                }}
            />}
        </>
     )
}


export default React.memo(SignatureModal)
const styles = StyleSheet.create({

    modalContainer: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
        backgroundColor: "rgba(0, 0, 0, 0.5)",
    },


});
