export  interface TaskListSettings {
    roles: string[]; // Array of selected roles
    notificationRoles: string[]; // Array of notification roles
    frequency: string; // Frequency of the task
    dateTime: string; // ISO string for the task date-time
    displayDateTime: string; // ISO string for display date-time
    assignedBy: string; // Username of the person assigning the task
}

export  interface TaskItem {
    id: string; // Unique identifier for the task
    name: string; // Name of the task
    type: string; // Type of the task
    status: 'Open' | 'Closed' | 'Completed'; // Status of the task
}

export interface TaskData {
    taskListSettings: TaskListSettings; // Task list settings object
    taskItems: TaskItem[]; // Array of task items
}
