import React, { useState, useEffect } from "react";
import { View, StyleSheet,Text, TouchableOpacity } from "react-native";
import { Feather } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import HomeScreen from "@/app/navigation/HomeScreen";
import DashboardScreen from "@/app/(app)/dashboard";
import Search from "@/app/(app)/search";
import TaskOverView from "@/app/(app)/tasks_overview";
import ProjectOverview from "@/app/(app)/project_overview";
import Settings from "@/app/(app)/settings";
import DashboardStackScreen from "@/app/navigation/DashboardStackScreen";
import ScreenNames from "@/app/utils/screenNames";
import SearchStackScreen from "@/app/navigation/SearchStackScreen";
const Tab = createBottomTabNavigator();

const BottomTabs = () => {

    function MyTabBar({ state, descriptors, navigation }) {
        return (
            <View style={styles.navContainer}>
                {state.routes.map((route, index) => {
                    const { options } = descriptors[route.key];
                    const label =
                        options.tabBarLabel !== undefined
                            ? options.tabBarLabel
                            : options.title !== undefined
                                ? options.title
                                : route.name;

                    const isFocused = state.index === index;
                    const pages = [
                        { name: "(app)/dashboard", icon: "home" },
                        { name: "(app)/search", icon: "search" },
                        { name: "(app)/task_overview", icon: "trello" },
                        { name: "(app)/project_overview", icon: "file" },
                        { name: "(app)/settings", icon: "user" },
                    ];

                    const onPress = () => {
                        const event = navigation.emit({
                            type: 'tabPress',
                            target: route.key,
                        });

                        if (!isFocused && !event.defaultPrevented) {
                            navigation.navigate(route.name);
                        }
                    };

                    const onLongPress = () => {
                        navigation.emit({
                            type: 'tabLongPress',
                            target: route.key,
                        });
                    };

                    return (
                        <TouchableOpacity
                            key={index.toString()}
                            accessibilityRole="button"
                            accessibilityState={isFocused ? { selected: true } : {}}
                            accessibilityLabel={options.tabBarAccessibilityLabel}
                            testID={options.tabBarTestID}
                            onPress={onPress}
                            onLongPress={onLongPress}
                            style={[
                                styles.navButton,
                                isFocused && styles.selectedButton,
                            ]}
                        >
                            <Feather
                                name={pages[index].icon}
                                size={24}
                                color={isFocused ? "#AA90E7" : "#898A94"}
                            />
                        </TouchableOpacity>
                    );
                })}
            </View>
        );
    }

    return (
        <Tab.Navigator tabBar={(props) => <MyTabBar {...props} />}>
            <Tab.Screen name="dashboard" component={DashboardStackScreen}  options={{headerShown:false}}/>
            <Tab.Screen name="search" component={SearchStackScreen} options={{headerShown:false}} />
            <Tab.Screen name="(app)/task_overview" component={TaskOverView} options={{headerShown:false}} />
            <Tab.Screen name="(app)/project_overview" component={ProjectOverview} options={{headerShown:false}} />
            <Tab.Screen name="(app)/settings" component={Settings} options={{headerShown:false}} />
        </Tab.Navigator>
    );
};

const styles = StyleSheet.create({
    navContainer: {
        flexDirection: "row",
        justifyContent: "space-around",
        alignItems: "center",
        height: 60,
        borderTopWidth: 1,
        borderTopColor: "#ccc",
        backgroundColor:'white'
    },
    navButton: {
        width: 50,
        height: 50,
        borderRadius: 25,
        alignItems: "center",
        justifyContent: "center",
    },
    selectedButton: {
        backgroundColor: "rgba(243, 238, 251, 1)",
    },
});

export default BottomTabs;
