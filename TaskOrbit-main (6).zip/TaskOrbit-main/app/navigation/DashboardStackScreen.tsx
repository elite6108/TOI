import React from 'react';
import {View, Text, StyleSheet, StatusBar} from 'react-native';
import {createStackNavigator, StackNavigationProp} from '@react-navigation/stack';
import {RouteProp} from '@react-navigation/native';

import TaskListScreen from "@/app/(app)/taskListScreen";
import DashboardScreen from "@/app/(app)/dashboard";
import Project_overview from "@/app/(app)/project_overview";
import TaskCreation from "@/app/(app)/create_task";
import UpdateTask from "@/app/(app)/update_task";
import projectDetails from "@/app/(app)/project_details";

// 1. Define the Types for Navigation
type DashboardStackParamList = {
    "(app)/dashboard": undefined; // No parameters required for Dashboard
    "(app)/taskListScreen": { taskId: string }; // Example: taskListScreen accepts a 'taskId' parameter
};

const DashboardStack = createStackNavigator<DashboardStackParamList>();

// 3. Define Props Interface for the Component (optional)
interface DashboardStackScreenProps {
    navigation: StackNavigationProp<DashboardStackParamList>; // Navigation props
    route: RouteProp<DashboardStackParamList>; // Route props
}

const DashboardStackScreen: React.FC = () => {
    return (
        <DashboardStack.Navigator
            screenOptions={{
                headerShown: false, // Hide headers globally
                animationEnabled: false // Disable animations globally
            }}>
            <DashboardStack.Screen
                name="(app)/dashboard"
                component={DashboardScreen}
            />

           {/* <DashboardStack.Screen
                name="(app)/taskListScreen"
                component={TaskListScreen}
            />*/}

           {/* <DashboardStack.Screen
                name="(app)/project_overview"
                component={Project_overview}
            />
            <DashboardStack.Screen
                name="(app)/create_task"
                component={TaskCreation}
            />

            <DashboardStack.Screen
                name="(app)/update_task"
                component={UpdateTask}
            />

            <DashboardStack.Screen
                name="(app)/project_details"
                component={projectDetails}
            />*/}


        </DashboardStack.Navigator>
    );
};

export default DashboardStackScreen;
