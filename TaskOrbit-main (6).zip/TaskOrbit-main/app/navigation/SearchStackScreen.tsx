import React from 'react';
import {View, Text, StyleSheet, StatusBar} from 'react-native';
import {createStackNavigator, StackNavigationProp} from '@react-navigation/stack';
import {RouteProp} from '@react-navigation/native';

import TaskListScreen from "@/app/(app)/taskListScreen";
import DashboardScreen from "@/app/(app)/dashboard";
import Project_overview from "@/app/(app)/project_overview";
import Search from "@/app/(app)/search";
import UpdateTask from "@/app/(app)/update_task";

// 1. Define the Types for Navigation
type SearchStackParamList = {
    "(app)/dashboard": undefined; // No parameters required for Dashboard
    "(app)/taskListScreen": { taskId: string }; // Example: taskListScreen accepts a 'taskId' parameter
};

const SearchStack = createStackNavigator<SearchStackParamList>();

// 3. Define Props Interface for the Component (optional)
interface SearchStackScreenProps {
    navigation: StackNavigationProp<SearchStackParamList>; // Navigation props
    route: RouteProp<SearchStackParamList>; // Route props
}

const SearchStackScreen: React.FC = () => {
    return (
        <SearchStack.Navigator
            screenOptions={{
                headerShown: false, // Hide headers globally
                animationEnabled: false // Disable animations globally
            }}>
            <SearchStack.Screen
                name="(app)/search"
                component={Search}
            />

           {/* <SearchStack.Screen
                name="(app)/taskListScreen"
                component={TaskListScreen}
            />

            <SearchStack.Screen
                name="(app)/update_task"
                component={UpdateTask}
            />*/}

        </SearchStack.Navigator>
    );
};

export default SearchStackScreen;
