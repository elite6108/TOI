 const ScreenNames = {
    Dashboard: "dashboard",
    TaskListScreen: "TaskListScreen",

    // Add more screen names as needed
} as const;

export default ScreenNames;
