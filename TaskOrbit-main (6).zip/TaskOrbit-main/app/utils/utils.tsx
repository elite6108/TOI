export const getStatusColor = (status:string):string => {
    switch (status) {
        case "Overdue":
            return "#ffcccc";
        case "Due soon":
            return "#ffeb99";
        case "Upcoming":
            return "#b3e0e8";
        case "Future task":
            return "lightgreen";
        default:
            return "#b3e0e8";
    }
};

export const formatDate = (isoDateString:string): string => {
    const date = new Date(isoDateString);
    const day = String(date.getDate()).padStart(2, "0");
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const year = date.getFullYear();

    return `${month}-${day}-${year}`;
};


export  const calculateStatus = (taskList) => {
    const { taskListSettings, taskItems } = taskList;
    const now = new Date();
    const dueDate = new Date(taskListSettings.dateTime);
    const daysDiff = Math.floor((dueDate - now) / (1000 * 60 * 60 * 24));

    const hasOpenTasks = taskItems.some((task) => task.status === "Open");

    if (hasOpenTasks) {
        if (daysDiff < 0) {
            return "Overdue";
        } else if (daysDiff === 0) {
            return "Due soon";
        } else if (daysDiff <= 2) {
            return "Due soon";
        } else if (daysDiff > 7) {
            return "Future task";
        } else if (daysDiff > 2 < 7) {
            return "Upcoming";
        }
    }
    return taskListSettings?.taskListStatus?taskListSettings?.taskListStatus:"Open"
};
