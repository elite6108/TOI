

export  const convertStrToDate=(dateString:string):Date=>{
    const [month, day, year] = dateString.split('-').map(Number);
    const date = new Date(year, month - 1, day); // Month is 0-indexed
    console.log(date); // Output: Sun Dec 22 2024 ...
    return date;
}
